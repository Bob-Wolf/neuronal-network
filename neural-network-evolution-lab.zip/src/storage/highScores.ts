import { CreatureBlueprint, HighScoreEntry, MapId } from '../types/simulation';
import { MAP_CONFIGS } from '../simulation/terrain';

const STORAGE_KEY = 'evolab_highscores_v1';

const SEED_SCORES: HighScoreEntry[] = [
  {
    id: 'seed_1',
    creatureName: 'Quad-Strider Mk.II',
    mapId: 'flat',
    distanceM: 37.4,
    score: 4620,
    generations: 4,
    bonesCount: 7,
    musclesCount: 5,
    timestamp: Date.now() - 86400000 * 2,
  },
  {
    id: 'seed_2',
    creatureName: 'Tri-Hopper Prime',
    mapId: 'dunes',
    distanceM: 33.2,
    score: 5180,
    generations: 5,
    bonesCount: 6,
    musclesCount: 4,
    timestamp: Date.now() - 86400000 * 3,
  },
  {
    id: 'seed_3',
    creatureName: 'Mantis Vault X',
    mapId: 'steps',
    distanceM: 36.6,
    score: 6490,
    generations: 6,
    bonesCount: 7,
    musclesCount: 5,
    timestamp: Date.now() - 86400000 * 4,
  },
];

export function calculateEvolutionScore(params: {
  distanceM: number;
  peakSpeedMps: number;
  generation: number;
  mapId: MapId;
  blueprint: CreatureBlueprint;
}): number {
  const { distanceM, peakSpeedMps, generation, mapId, blueprint } = params;
  const mapCfg = MAP_CONFIGS[mapId];
  const clampedDist = Math.max(0, distanceM);
  if (clampedDist < 0.2) return 0;

  const basePoints = clampedDist * 100 * mapCfg.scoreMultiplier;
  const speedBonus = Math.min(900, peakSpeedMps * 85);
  const partsCount = blueprint.edges.length;
  // Slight structural efficiency bonus for lean designs under 16 parts
  const economyBonus = Math.max(0, (18 - partsCount) * 22);
  // Early-generation mastery bonus
  const fastGenBonus = Math.max(0, (9 - generation) * 45);
  const targetBonus = clampedDist >= mapCfg.targetMeters ? 500 : 0;

  return Math.round(basePoints + speedBonus + economyBonus + fastGenBonus + targetBonus);
}

export function loadHighScores(): HighScoreEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(SEED_SCORES));
      return [...SEED_SCORES];
    }
    const parsed = JSON.parse(raw) as HighScoreEntry[];
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return [...SEED_SCORES];
    }
    return parsed.sort((a, b) => b.score - a.score);
  } catch {
    return [...SEED_SCORES];
  }
}

export function saveHighScore(entry: Omit<HighScoreEntry, 'id' | 'timestamp'>): {
  entryId: string;
  updated: HighScoreEntry[];
  isNewRecord: boolean;
  rank: number;
} {
  const current = loadHighScores();
  const prevBestForMap = current
    .filter((s) => s.mapId === entry.mapId)
    .reduce((max, s) => Math.max(max, s.score), 0);

  const fullEntry: HighScoreEntry = {
    ...entry,
    id: `hs_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp: Date.now(),
  };

  const merged = [...current, fullEntry]
    .sort((a, b) => b.score - a.score)
    .slice(0, 18);

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
  } catch {
    // ignore quota issues
  }

  const rank = merged.findIndex((x) => x.id === fullEntry.id) + 1;
  return {
    entryId: fullEntry.id,
    updated: merged,
    isNewRecord: fullEntry.score > prevBestForMap,
    rank: rank > 0 ? rank : merged.length,
  };
}

export function renameHighScoreEntry(
  entryId: string,
  newName: string
): HighScoreEntry[] {
  const current = loadHighScores();
  const updated = current.map((item) =>
    item.id === entryId
      ? { ...item, creatureName: newName.trim() || 'Custom Specimen' }
      : item
  );
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // ignore quota issues
  }
  return updated;
}
