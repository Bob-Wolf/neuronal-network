export type MapId = 'flat' | 'dunes' | 'steps';

export type EditorTool = 'bone' | 'muscle' | 'move' | 'erase';

export type GameScreen = 'start' | 'build' | 'evolve';

export type RunEndReason = 'target_reached' | 'generations_complete' | 'manual_finish' | null;

export interface MapConfig {
  id: MapId;
  name: string;
  subtitle: string;
  difficulty: 'I · CALIBRATION' | 'II · TORQUE' | 'III · AGILITY';
  targetMeters: number;
  accentColor: string;
  topCapColor: string;
  soilColor: string;
  subSoilColor: string;
  scoreMultiplier: number;
}

export interface JointBlueprint {
  id: string;
  /** World space in build coordinates around origin (0, 0), where y = 0 is ground surface and negative y is UP */
  x: number;
  y: number;
}

export type EdgeKind = 'bone' | 'muscle';

export interface EdgeBlueprint {
  id: string;
  a: string;
  b: string;
  kind: EdgeKind;
}

export interface CreatureBlueprint {
  name: string;
  joints: JointBlueprint[];
  edges: EdgeBlueprint[];
}

export interface NeuralGenome {
  id: string;
  /** Base oscillation frequency in Hz (~1.2 to 3.0 Hz) */
  baseFreq: number;
  /** Input -> Hidden weights: shape [HIDDEN_SIZE * INPUT_SIZE] */
  w1: number[];
  /** Hidden biases: shape [HIDDEN_SIZE] */
  b1: number[];
  /** Hidden -> Muscle Output weights: shape [numMuscles * HIDDEN_SIZE] */
  w2: number[];
  /** Output biases: shape [numMuscles] */
  b2: number[];
  /** Muscle contraction amplitude scale per muscle (~0.22 to 0.44) */
  muscleStrength: number[];
  fitness: number;
  maxDistanceM: number;
  isElite?: boolean;
}

export interface RuntimeJoint {
  x: number;
  y: number;
  prevX: number;
  prevY: number;
  radius: number;
  onGround: boolean;
  impactForce: number;
}

export interface RuntimeEdge {
  aIdx: number;
  bIdx: number;
  kind: EdgeKind;
  restLength: number;
  currentTarget: number;
  /** Normalized activation in [-1, 1]: -1 = full contraction, +1 = full extension */
  activation: number;
  stress: number;
}

export interface TelemetrySample {
  t: number;
  sinClock: number;
  cosClock: number;
  groundSensor: number;
  tiltSensor: number;
  muscles: number[];
}

export interface CreatureInstance {
  index: number;
  genome: NeuralGenome;
  joints: RuntimeJoint[];
  edges: RuntimeEdge[];
  muscleIndices: number[];
  /** Pre-activation sums z1 = W1*x + b1 for live math inspection */
  lastHiddenRaw: number[];
  /** Pre-activation sums z2 = W2*h + b2 for live math inspection */
  lastOutputsRaw: number[];
  /** Last neural layer activations for live HUD visualization */
  lastInputs: number[];
  lastHidden: number[];
  lastOutputs: number[];
  /** Rolling waveform buffer for live oscilloscope & phase portrait */
  telemetry: TelemetrySample[];
  telemetryTick: number;
  startX: number;
  currentX: number;
  maxX: number;
  distanceM: number;
  maxDistanceM: number;
  peakSpeedMps: number;
  airTime: number;
  alive: boolean;
  rank: number;
  colorHue: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  decay: number;
  color: string;
  kind: 'dust' | 'spark' | 'confetti' | 'ring';
}

export interface FloatingPopup {
  x: number;
  y: number;
  vy: number;
  text: string;
  subtext?: string;
  color: string;
  alpha: number;
  scale: number;
}

export interface HighScoreEntry {
  id: string;
  creatureName: string;
  mapId: MapId;
  distanceM: number;
  score: number;
  generations: number;
  bonesCount: number;
  musclesCount: number;
  timestamp: number;
}

export interface GenerationSummary {
  generation: number;
  bestDistanceM: number;
  avgDistanceM: number;
  score: number;
}
