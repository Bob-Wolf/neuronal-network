import { CreatureBlueprint } from '../types/simulation';

export const CREATURE_PRESETS: CreatureBlueprint[] = [
  {
    name: 'Tri-Hopper',
    joints: [
      { id: 'j1', x: -38, y: -64 }, // Rear hip
      { id: 'j2', x: 34, y: -74 },  // Front chest
      { id: 'j3', x: -2, y: -112 }, // Dorsal crest
      { id: 'j4', x: -58, y: -28 }, // Rear knee
      { id: 'j5', x: -24, y: -8 },  // Rear foot
      { id: 'j6', x: 48, y: -10 },  // Front foot
    ],
    edges: [
      // Rigid core triangle
      { id: 'e1', a: 'j1', b: 'j2', kind: 'bone' },
      { id: 'e2', a: 'j2', b: 'j3', kind: 'bone' },
      { id: 'e3', a: 'j3', b: 'j1', kind: 'bone' },
      // Articulated hind leg
      { id: 'e4', a: 'j1', b: 'j4', kind: 'bone' },
      { id: 'e5', a: 'j4', b: 'j5', kind: 'bone' },
      // Front strut leg
      { id: 'e6', a: 'j2', b: 'j6', kind: 'bone' },
      // Actuating muscles
      { id: 'm1', a: 'j1', b: 'j5', kind: 'muscle' }, // Hind leg extension
      { id: 'm2', a: 'j3', b: 'j4', kind: 'muscle' }, // Hip swing
      { id: 'm3', a: 'j1', b: 'j6', kind: 'muscle' }, // Front stride sweep
      { id: 'm4', a: 'j3', b: 'j6', kind: 'muscle' }, // Front lift muscle
    ],
  },
  {
    name: 'Quad-Strider',
    joints: [
      { id: 'j1', x: -46, y: -68 }, // Pelvis
      { id: 'j2', x: 46, y: -68 },  // Shoulder
      { id: 'j3', x: 0, y: -106 },  // Spine ridge
      { id: 'j4', x: -64, y: -34 }, // Rear knee
      { id: 'j5', x: -42, y: -8 },  // Rear paw
      { id: 'j6', x: 28, y: -34 },  // Front elbow
      { id: 'j7', x: 54, y: -8 },   // Front paw
    ],
    edges: [
      // Core spine truss
      { id: 'e1', a: 'j1', b: 'j2', kind: 'bone' },
      { id: 'e2', a: 'j1', b: 'j3', kind: 'bone' },
      { id: 'e3', a: 'j2', b: 'j3', kind: 'bone' },
      // Rear leg
      { id: 'e4', a: 'j1', b: 'j4', kind: 'bone' },
      { id: 'e5', a: 'j4', b: 'j5', kind: 'bone' },
      // Front leg
      { id: 'e6', a: 'j2', b: 'j6', kind: 'bone' },
      { id: 'e7', a: 'j6', b: 'j7', kind: 'bone' },
      // Muscles
      { id: 'm1', a: 'j1', b: 'j5', kind: 'muscle' },
      { id: 'm2', a: 'j3', b: 'j4', kind: 'muscle' },
      { id: 'm3', a: 'j2', b: 'j7', kind: 'muscle' },
      { id: 'm4', a: 'j1', b: 'j6', kind: 'muscle' },
      { id: 'm5', a: 'j5', b: 'j6', kind: 'muscle' },
    ],
  },
  {
    name: 'Mantis Vault',
    joints: [
      { id: 'j1', x: -34, y: -86 }, // Rear hip
      { id: 'j2', x: 34, y: -92 },  // High thorax
      { id: 'j3', x: 0, y: -132 },  // Apex spire
      { id: 'j4', x: -58, y: -44 }, // Rear joint
      { id: 'j5', x: -36, y: -8 },  // Rear tarsus
      { id: 'j6', x: 64, y: -52 },  // Forearm hook
      { id: 'j7', x: 46, y: -8 },   // Front claw
    ],
    edges: [
      { id: 'e1', a: 'j1', b: 'j2', kind: 'bone' },
      { id: 'e2', a: 'j2', b: 'j3', kind: 'bone' },
      { id: 'e3', a: 'j3', b: 'j1', kind: 'bone' },
      { id: 'e4', a: 'j1', b: 'j4', kind: 'bone' },
      { id: 'e5', a: 'j4', b: 'j5', kind: 'bone' },
      { id: 'e6', a: 'j2', b: 'j6', kind: 'bone' },
      { id: 'e7', a: 'j6', b: 'j7', kind: 'bone' },
      { id: 'm1', a: 'j1', b: 'j5', kind: 'muscle' },
      { id: 'm2', a: 'j2', b: 'j4', kind: 'muscle' },
      { id: 'm3', a: 'j2', b: 'j7', kind: 'muscle' },
      { id: 'm4', a: 'j3', b: 'j6', kind: 'muscle' },
      { id: 'm5', a: 'j1', b: 'j7', kind: 'muscle' },
    ],
  },
  {
    name: 'Inch-Crawler',
    joints: [
      { id: 'j1', x: -72, y: -10 }, // Tail foot
      { id: 'j2', x: -36, y: -56 }, // Rear arch
      { id: 'j3', x: 0, y: -12 },   // Mid belly foot
      { id: 'j4', x: 36, y: -58 },  // Front arch
      { id: 'j5', x: 74, y: -10 },  // Head foot
      { id: 'j6', x: 0, y: -86 },   // Dorsal bridge
    ],
    edges: [
      { id: 'e1', a: 'j1', b: 'j2', kind: 'bone' },
      { id: 'e2', a: 'j2', b: 'j3', kind: 'bone' },
      { id: 'e3', a: 'j3', b: 'j4', kind: 'bone' },
      { id: 'e4', a: 'j4', b: 'j5', kind: 'bone' },
      { id: 'e5', a: 'j2', b: 'j6', kind: 'bone' },
      { id: 'e6', a: 'j4', b: 'j6', kind: 'bone' },
      { id: 'm1', a: 'j1', b: 'j3', kind: 'muscle' },
      { id: 'm2', a: 'j3', b: 'j5', kind: 'muscle' },
      { id: 'm3', a: 'j2', b: 'j4', kind: 'muscle' },
      { id: 'm4', a: 'j6', b: 'j3', kind: 'muscle' },
    ],
  },
];

export function cloneBlueprint(bp: CreatureBlueprint): CreatureBlueprint {
  return {
    name: bp.name,
    joints: bp.joints.map((j) => ({ ...j })),
    edges: bp.edges.map((e) => ({ ...e })),
  };
}
