import { NeuralGenome } from '../types/simulation';

export const INPUT_SIZE = 6;
export const HIDDEN_SIZE = 6;
export const POPULATION_SIZE = 16;

export const INPUT_LABELS = [
  'OSC·SIN',
  'OSC·COS',
  'HARMONIC',
  'GROUND',
  'TILT',
  'VERT·VEL',
];

export interface InputNeuronSpec {
  index: number;
  shortLabel: string;
  titleDe: string;
  formula: string;
  category: 'CPG Taktgeber' | 'Sensorik';
  roleDe: string;
}

export const INPUT_SPECS: InputNeuronSpec[] = [
  {
    index: 0,
    shortLabel: 'OSC·SIN',
    titleDe: 'CPG Grundtakt (Sinus)',
    formula: 'sin(2π · f · t)',
    category: 'CPG Taktgeber',
    roleDe:
      'Erzeugt den rhythmischen Hauptimpuls mit Gen-Frequenz f (in Hz). Ohne Taktgeber müsste das Netz ein Gedächtnis (RNN) besitzen.',
  },
  {
    index: 1,
    shortLabel: 'OSC·COS',
    titleDe: 'CPG Phasen-Takt (Kosinus)',
    formula: 'cos(2π · f · t)',
    category: 'CPG Taktgeber',
    roleDe:
      'Um 90° phasenverschoben zu sin(). Zusammen bilden (sin, cos) einen 2D-Einheitskreis — erst dadurch entsteht eine Vorwärts-Schwing- vs. Abstoßphase!',
  },
  {
    index: 2,
    shortLabel: 'HARMONIC',
    titleDe: '2. Harmonische (Oberwelle)',
    formula: 'sin(4π · f · t)',
    category: 'CPG Taktgeber',
    roleDe:
      'Doppelte Taktfrequenz für asymmetrische Kurvenformen (z.B. schnelles Anheben des Fußes, langsames kraftvolles Abdrücken).',
  },
  {
    index: 3,
    shortLabel: 'GROUND',
    titleDe: 'Bodenkontakt-Verhältnis',
    formula: '(n_ground / N) · 2 − 1',
    category: 'Sensorik',
    roleDe:
      'Propriozeption in [−1, +1]: −1 = komplett in der Luft, +1 = alle Gelenke am Boden. Erlaubt reaktives Abdrücken genau beim Aufkommen.',
  },
  {
    index: 4,
    shortLabel: 'TILT',
    titleDe: 'Körperneigung (Pitch)',
    formula: 'sin(θ) = Δy / ‖Δp‖',
    category: 'Sensorik',
    roleDe:
      'Vestibulärer Gleichgewichtssensor zwischen Rumpfgelenken. Verhindert Überschläge auf steilen Dünen und Stufen.',
  },
  {
    index: 5,
    shortLabel: 'VERT·VEL',
    titleDe: 'Vertikal-Geschwindigkeit',
    formula: 'clamp(v_y / 350, −1, +1)',
    category: 'Sensorik',
    roleDe:
      'Misst Steigflug (< 0) vs. Fallgeschwindigkeit (> 0), damit Muskeln vor der Landung vorspannen (Dämpfung & Feder-Effekt).',
  },
];

function randRange(min: number, max: number): number {
  return min + Math.random() * (max - min);
}

function gaussianRandom(): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

let genomeCounter = 1;

export function createRandomGenome(numMuscles: number): NeuralGenome {
  const safeMuscles = Math.max(1, numMuscles);
  const w1: number[] = [];
  for (let i = 0; i < HIDDEN_SIZE * INPUT_SIZE; i++) {
    // Slightly stronger weights on oscillatory CPG inputs (indices 0,1,2) so Gen 1 creatures move immediately
    const inIdx = i % INPUT_SIZE;
    const scale = inIdx < 3 ? 1.15 : 0.7;
    w1.push(gaussianRandom() * scale);
  }

  const b1: number[] = [];
  for (let i = 0; i < HIDDEN_SIZE; i++) {
    b1.push(gaussianRandom() * 0.25);
  }

  const w2: number[] = [];
  for (let i = 0; i < safeMuscles * HIDDEN_SIZE; i++) {
    w2.push(gaussianRandom() * 0.95);
  }

  const b2: number[] = [];
  const muscleStrength: number[] = [];
  for (let m = 0; m < safeMuscles; m++) {
    b2.push(gaussianRandom() * 0.18);
    muscleStrength.push(randRange(0.28, 0.42));
  }

  return {
    id: `g_${genomeCounter++}`,
    baseFreq: randRange(1.45, 2.75),
    w1,
    b1,
    w2,
    b2,
    muscleStrength,
    fitness: 0,
    maxDistanceM: 0,
    isElite: false,
  };
}

export function createInitialPopulation(
  numMuscles: number,
  size: number = POPULATION_SIZE
): NeuralGenome[] {
  const pop: NeuralGenome[] = [];
  for (let i = 0; i < size; i++) {
    pop.push(createRandomGenome(numMuscles));
  }
  return pop;
}

/**
 * Evaluates feedforward neural network in-place with zero allocations.
 */
export function evaluateGenome(
  genome: NeuralGenome,
  inputs: number[],
  hiddenOut: number[],
  muscleOut: number[],
  hiddenRawOut?: number[],
  muscleRawOut?: number[]
): void {
  const { w1, b1, w2, b2 } = genome;
  const numMuscles = muscleOut.length;

  for (let h = 0; h < HIDDEN_SIZE; h++) {
    let sum = b1[h] ?? 0;
    const rowOffset = h * INPUT_SIZE;
    for (let i = 0; i < INPUT_SIZE; i++) {
      sum += (w1[rowOffset + i] ?? 0) * inputs[i];
    }
    if (hiddenRawOut) hiddenRawOut[h] = sum;
    hiddenOut[h] = Math.tanh(sum);
  }

  for (let m = 0; m < numMuscles; m++) {
    let sum = b2[m] ?? 0;
    const rowOffset = m * HIDDEN_SIZE;
    for (let h = 0; h < HIDDEN_SIZE; h++) {
      sum += (w2[rowOffset + h] ?? 0) * hiddenOut[h];
    }
    if (muscleRawOut) muscleRawOut[m] = sum;
    muscleOut[m] = Math.tanh(sum);
  }
}

function cloneGenome(g: NeuralGenome, isElite = false): NeuralGenome {
  return {
    id: isElite ? g.id : `g_${genomeCounter++}`,
    baseFreq: g.baseFreq,
    w1: [...g.w1],
    b1: [...g.b1],
    w2: [...g.w2],
    b2: [...g.b2],
    muscleStrength: [...g.muscleStrength],
    fitness: 0,
    maxDistanceM: 0,
    isElite,
  };
}

function tournamentPick(sortedPop: NeuralGenome[]): NeuralGenome {
  const poolSize = Math.max(2, Math.ceil(sortedPop.length * 0.55));
  const a = sortedPop[Math.floor(Math.random() * poolSize)];
  const b = sortedPop[Math.floor(Math.random() * poolSize)];
  return a.fitness >= b.fitness ? a : b;
}

function crossoverAndMutate(
  parentA: NeuralGenome,
  parentB: NeuralGenome,
  rate: number,
  sigma: number
): NeuralGenome {
  const child = cloneGenome(parentA, false);

  child.baseFreq =
    (Math.random() < 0.5 ? parentA.baseFreq : parentB.baseFreq) +
    (Math.random() < rate ? gaussianRandom() * sigma * 0.45 : 0);
  child.baseFreq = Math.max(0.75, Math.min(3.8, child.baseFreq));

  for (let i = 0; i < child.w1.length; i++) {
    let val = Math.random() < 0.5 ? parentA.w1[i] : parentB.w1[i];
    if (Math.random() < rate) val += gaussianRandom() * sigma;
    child.w1[i] = Math.max(-3.5, Math.min(3.5, val));
  }

  for (let i = 0; i < child.b1.length; i++) {
    let val = Math.random() < 0.5 ? parentA.b1[i] : parentB.b1[i];
    if (Math.random() < rate) val += gaussianRandom() * sigma * 0.6;
    child.b1[i] = Math.max(-2.5, Math.min(2.5, val));
  }

  for (let i = 0; i < child.w2.length; i++) {
    let val = Math.random() < 0.5 ? parentA.w2[i] : parentB.w2[i];
    if (Math.random() < rate) val += gaussianRandom() * sigma;
    child.w2[i] = Math.max(-3.5, Math.min(3.5, val));
  }

  for (let i = 0; i < child.b2.length; i++) {
    let val = Math.random() < 0.5 ? parentA.b2[i] : parentB.b2[i];
    if (Math.random() < rate) val += gaussianRandom() * sigma * 0.6;
    child.b2[i] = Math.max(-2.5, Math.min(2.5, val));
  }

  for (let i = 0; i < child.muscleStrength.length; i++) {
    let val =
      Math.random() < 0.5 ? parentA.muscleStrength[i] : parentB.muscleStrength[i];
    if (Math.random() < rate) val += gaussianRandom() * sigma * 0.12;
    child.muscleStrength[i] = Math.max(0.18, Math.min(0.46, val));
  }

  return child;
}

export function evolvePopulation(
  evaluatedPop: NeuralGenome[],
  numMuscles: number,
  stagnationCount = 0
): NeuralGenome[] {
  const sorted = [...evaluatedPop].sort((a, b) => b.fitness - a.fitness);
  const nextPop: NeuralGenome[] = [];
  const targetSize = evaluatedPop.length;

  // Preserve #1 fitness champion + #1 peak-distance jumper verbatim so records never regress
  nextPop.push(cloneGenome(sorted[0], true));
  if (sorted.length > 1) {
    const peakDistChamp = [...evaluatedPop].sort(
      (a, b) => b.maxDistanceM - a.maxDistanceM
    )[0];
    const secondElite =
      peakDistChamp && peakDistChamp.id !== sorted[0].id
        ? peakDistChamp
        : sorted[1];
    nextPop.push(cloneGenome(secondElite, true));
  }

  const boostSigma = stagnationCount >= 2 ? 1.45 : 1.0;

  while (nextPop.length < targetSize) {
    const idx = nextPop.length;
    if (idx >= targetSize - 2) {
      // Fresh exploratory diversity slots
      nextPop.push(createRandomGenome(numMuscles));
    } else if (idx < Math.floor(targetSize * 0.62)) {
      // Fine-tuning children around top performers
      const pA = tournamentPick(sorted);
      const pB = tournamentPick(sorted);
      nextPop.push(crossoverAndMutate(pA, pB, 0.28, 0.24 * boostSigma));
    } else {
      // High-variance explorer children
      const pA = tournamentPick(sorted);
      const pB = sorted[0];
      nextPop.push(crossoverAndMutate(pA, pB, 0.5, 0.58 * boostSigma));
    }
  }

  return nextPop;
}
