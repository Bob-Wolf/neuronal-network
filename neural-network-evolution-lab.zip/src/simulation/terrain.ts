import { MapConfig, MapId } from '../types/simulation';

export const PIXELS_PER_METER = 60;

export const MAP_CONFIGS: Record<MapId, MapConfig> = {
  flat: {
    id: 'flat',
    name: 'Proving Grounds',
    subtitle: 'Calibration runway tuned for pure stride cadence',
    difficulty: 'I · CALIBRATION',
    targetMeters: 36,
    accentColor: '#34C759',
    topCapColor: '#34C759',
    soilColor: '#242426',
    subSoilColor: '#161618',
    scoreMultiplier: 1.0,
  },
  dunes: {
    id: 'dunes',
    name: 'Sine Dunes',
    subtitle: 'Rolling swells testing climb torque and balance',
    difficulty: 'II · TORQUE',
    targetMeters: 32,
    accentColor: '#FF9500',
    topCapColor: '#FF9500',
    soilColor: '#282523',
    subSoilColor: '#181615',
    scoreMultiplier: 1.35,
  },
  steps: {
    id: 'steps',
    name: 'Chasm Steps',
    subtitle: 'Terraced ledges demanding high-clearance vaults',
    difficulty: 'III · AGILITY',
    targetMeters: 35,
    accentColor: '#007AFF',
    topCapColor: '#007AFF',
    soilColor: '#1F232B',
    subSoilColor: '#12151A',
    scoreMultiplier: 1.75,
  },
};

export const MAP_LIST: MapConfig[] = [
  MAP_CONFIGS.flat,
  MAP_CONFIGS.dunes,
  MAP_CONFIGS.steps,
];

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

/**
 * Returns terrain ground Y coordinate in world pixels (y = 0 at spawn pad, negative Y = UP, positive Y = DOWN).
 */
export function getTerrainHeight(mapId: MapId, x: number): number {
  // Backstop slope behind -180px (-3m) so creatures never wander off left indefinitely
  if (x < -180) {
    const backDist = -180 - x;
    return -Math.min(420, backDist * 0.55);
  }

  // Flat starting pad around x in [-180, 150] with smooth blend into map features
  const ramp = smoothstep(140, 320, x);
  if (ramp <= 0.0001) return 0;

  if (mapId === 'flat') {
    // Ultra-clean calibration runway with subtle rolling speed-waves past 22m
    const farRamp = smoothstep(1300, 1900, x);
    const wave = Math.sin(x * 0.008) * 10 * farRamp + Math.sin(x * 0.021) * 4 * farRamp;
    return wave * ramp;
  }

  if (mapId === 'dunes') {
    // Progressive rolling hills: negative Y rises upward, positive Y dips into valleys
    const distScale = 1 + Math.min(1.6, Math.max(0, (x - 300) / 2800));
    const hill1 = Math.sin((x - 160) * 0.0068) * 44 * distScale;
    const hill2 = Math.sin((x - 160) * 0.0145 + 1.1) * 20 * distScale;
    const gradualClimb = -Math.min(260, Math.max(0, x - 300) * 0.025);
    return (hill1 + hill2 + gradualClimb) * ramp;
  }

  // 'steps': Chasm Steps — geometric terraced stairs, plateaus, and vault hurdles
  const relX = Math.max(0, x - 210);
  const period = 270;
  const segIndex = Math.floor(relX / period);
  const localX = relX - segIndex * period;

  // Deterministic pseudo-pattern per terrace index
  const pattern = segIndex % 4;
  const stepHeight = 24 + Math.min(24, segIndex * 2.5);

  let currentLevel = 0;
  let nextLevel = 0;

  // Compute cumulative base elevation with alternating climbs and drops
  const baseClimb = -segIndex * 14;
  if (pattern === 0) {
    // Raised plateau hurdle
    const up = smoothstep(30, 52, localX);
    const down = smoothstep(185, 210, localX);
    currentLevel = baseClimb - stepHeight * up + stepHeight * 0.65 * down;
  } else if (pattern === 1) {
    // Double stair ascent
    const s1 = smoothstep(25, 44, localX);
    const s2 = smoothstep(135, 155, localX);
    currentLevel = baseClimb - stepHeight * 0.55 * s1 - stepHeight * 0.6 * s2;
  } else if (pattern === 2) {
    // Drop trench + ramp out
    const dip = smoothstep(20, 42, localX);
    const climbOut = smoothstep(130, 220, localX);
    nextLevel = baseClimb + stepHeight * 0.75 * dip - stepHeight * 1.05 * climbOut;
    currentLevel = nextLevel;
  } else {
    // Sawtooth ramp launch + flat landing
    const rampUp = smoothstep(15, 150, localX);
    const drop = smoothstep(210, 232, localX);
    currentLevel = baseClimb - stepHeight * 1.1 * rampUp + stepHeight * 0.6 * drop;
  }

  return currentLevel * ramp;
}

/**
 * Computes unit upward normal (nx, ny) at world position x using central finite differences.
 */
export function getTerrainNormal(mapId: MapId, x: number): { nx: number; ny: number } {
  const eps = 3.0;
  const hL = getTerrainHeight(mapId, x - eps);
  const hR = getTerrainHeight(mapId, x + eps);
  const dx = 2 * eps;
  const dy = hR - hL;
  // Tangent is (dx, dy), upward normal (since negative Y is UP) is (dy, -dx) normalized
  const len = Math.hypot(dy, dx) || 1;
  return {
    nx: dy / len,
    ny: -dx / len,
  };
}
