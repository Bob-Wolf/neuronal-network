import {
  CreatureBlueprint,
  CreatureInstance,
  NeuralGenome,
  MapId,
  RuntimeEdge,
  RuntimeJoint,
} from '../types/simulation';
import { evaluateGenome, HIDDEN_SIZE, INPUT_SIZE } from './neuralNet';
import { getTerrainHeight, getTerrainNormal, PIXELS_PER_METER } from './terrain';

export const JOINT_RADIUS = 8.5;
const GRAVITY = 960;
const AIR_DAMPING = 0.994;
const CONSTRAINT_ITERS = 10;

export interface ImpactEvent {
  x: number;
  y: number;
  intensity: number; // 0..1
  isLeader: boolean;
}

export function spawnCreatureInstance(
  blueprint: CreatureBlueprint,
  genome: NeuralGenome,
  index: number,
  mapId: MapId
): CreatureInstance {
  const jointsSrc = blueprint.joints;
  // Center creature horizontally around x = 0 and lift/lower cleanly onto ground pad
  let sumX = 0;
  for (let i = 0; i < jointsSrc.length; i++) {
    sumX += jointsSrc[i].x;
  }
  const centerX = jointsSrc.length > 0 ? sumX / jointsSrc.length : 0;

  // Determine vertical offset so lowest joint just kisses terrain at spawn
  let maxPenetration = -Infinity;
  for (let i = 0; i < jointsSrc.length; i++) {
    const wx = jointsSrc[i].x - centerX;
    const terrainY = getTerrainHeight(mapId, wx);
    const diff = jointsSrc[i].y + JOINT_RADIUS - terrainY;
    if (diff > maxPenetration) {
      maxPenetration = diff;
    }
  }
  const yShift = Number.isFinite(maxPenetration) ? maxPenetration + 2 : 0;

  const jointIdToIdx = new Map<string, number>();
  const runtimeJoints: RuntimeJoint[] = jointsSrc.map((j, idx) => {
    jointIdToIdx.set(j.id, idx);
    const x = j.x - centerX;
    const y = j.y - yShift;
    return {
      x,
      y,
      prevX: x,
      prevY: y,
      radius: JOINT_RADIUS,
      onGround: false,
      impactForce: 0,
    };
  });

  const runtimeEdges: RuntimeEdge[] = [];
  const muscleIndices: number[] = [];

  for (const edge of blueprint.edges) {
    const aIdx = jointIdToIdx.get(edge.a);
    const bIdx = jointIdToIdx.get(edge.b);
    if (aIdx === undefined || bIdx === undefined || aIdx === bIdx) continue;
    const ja = runtimeJoints[aIdx];
    const jb = runtimeJoints[bIdx];
    const restLength = Math.max(16, Math.hypot(jb.x - ja.x, jb.y - ja.y));
    const edgeIdx = runtimeEdges.length;
    runtimeEdges.push({
      aIdx,
      bIdx,
      kind: edge.kind,
      restLength,
      currentTarget: restLength,
      activation: 0,
      stress: 0,
    });
    if (edge.kind === 'muscle') {
      muscleIndices.push(edgeIdx);
    }
  }

  return {
    index,
    genome,
    joints: runtimeJoints,
    edges: runtimeEdges,
    muscleIndices,
    lastHiddenRaw: new Array(HIDDEN_SIZE).fill(0),
    lastOutputsRaw: new Array(Math.max(1, muscleIndices.length)).fill(0),
    lastInputs: new Array(INPUT_SIZE).fill(0),
    lastHidden: new Array(HIDDEN_SIZE).fill(0),
    lastOutputs: new Array(Math.max(1, muscleIndices.length)).fill(0),
    telemetry: [],
    telemetryTick: 0,
    startX: 0,
    currentX: 0,
    maxX: 0,
    distanceM: 0,
    maxDistanceM: 0,
    peakSpeedMps: 0,
    airTime: 0,
    alive: true,
    rank: index,
    colorHue: (index * 37 + 160) % 360,
  };
}

export function spawnPopulation(
  blueprint: CreatureBlueprint,
  genomes: NeuralGenome[],
  mapId: MapId
): CreatureInstance[] {
  return genomes.map((g, idx) => spawnCreatureInstance(blueprint, g, idx, mapId));
}

export function stepCreaturePhysics(
  creature: CreatureInstance,
  simTime: number,
  dt: number,
  mapId: MapId,
  boostMultiplier: number,
  isLeader: boolean,
  outImpacts?: ImpactEvent[]
): void {
  const { joints, edges, muscleIndices, genome } = creature;
  const numJoints = joints.length;
  if (numJoints === 0) return;

  // 1. Gather sensory state from current body configuration
  let sumX = 0;
  let sumY = 0;
  let sumVy = 0;
  let sumVx = 0;
  let groundContacts = 0;

  for (let i = 0; i < numJoints; i++) {
    const j = joints[i];
    sumX += j.x;
    sumY += j.y;
    sumVx += (j.x - j.prevX) / dt;
    sumVy += (j.y - j.prevY) / dt;
    if (j.onGround) groundContacts++;
  }

  const comX = sumX / numJoints;
  const avgVx = sumVx / numJoints;
  const avgVy = sumVy / numJoints;

  // Estimate body pitch tilt using first two joints if available
  let tiltSin = 0;
  if (numJoints >= 2) {
    const j0 = joints[0];
    const j1 = joints[1];
    const dx = j1.x - j0.x;
    const dy = j1.y - j0.y;
    const len = Math.hypot(dx, dy) || 1;
    tiltSin = Math.max(-1, Math.min(1, dy / len));
  }

  const phase = 2 * Math.PI * genome.baseFreq * simTime;
  const inputs = creature.lastInputs;
  inputs[0] = Math.sin(phase);
  inputs[1] = Math.cos(phase);
  inputs[2] = Math.sin(phase * 2.0);
  inputs[3] = (groundContacts / numJoints) * 2 - 1;
  inputs[4] = tiltSin;
  inputs[5] = Math.max(-1, Math.min(1, avgVy / 350));

  // 2. Run neural network forward pass to drive muscles
  if (muscleIndices.length > 0) {
    evaluateGenome(
      genome,
      inputs,
      creature.lastHidden,
      creature.lastOutputs,
      creature.lastHiddenRaw,
      creature.lastOutputsRaw
    );
    for (let m = 0; m < muscleIndices.length; m++) {
      const edge = edges[muscleIndices[m]];
      const rawAct = creature.lastOutputs[m] ?? 0;
      edge.activation = rawAct;
      const strength = Math.min(0.49, (genome.muscleStrength[m] ?? 0.34) * boostMultiplier);
      const desired = edge.restLength * (1 + rawAct * strength);
      edge.currentTarget += (desired - edge.currentTarget) * 0.34;
    }
  }

  creature.telemetryTick += 1;
  if (creature.telemetryTick % 2 === 0) {
    creature.telemetry.push({
      t: simTime,
      sinClock: inputs[0],
      cosClock: inputs[1],
      groundSensor: inputs[3],
      tiltSensor: inputs[4],
      muscles: creature.lastOutputs.slice(0, 6),
    });
    if (creature.telemetry.length > 150) {
      creature.telemetry.shift();
    }
  }

  // 3. Verlet velocity integration + gravity
  const dtSq = dt * dt;
  const prevGroundFlags: boolean[] = new Array(numJoints);

  for (let i = 0; i < numJoints; i++) {
    const j = joints[i];
    prevGroundFlags[i] = j.onGround;
    j.onGround = false;
    j.impactForce = 0;

    let vx = (j.x - j.prevX) * AIR_DAMPING;
    let vy = (j.y - j.prevY) * AIR_DAMPING;

    // Velocity safety clamp to guarantee numerical stability at any speed
    const maxStep = 28;
    vx = Math.max(-maxStep, Math.min(maxStep, vx));
    vy = Math.max(-maxStep, Math.min(maxStep, vy));

    j.prevX = j.x;
    j.prevY = j.y;
    j.x += vx;
    j.y += vy + GRAVITY * dtSq;
  }

  // 4. Iterative constraint solver + ground contact projection
  for (let iter = 0; iter < CONSTRAINT_ITERS; iter++) {
    for (let e = 0; e < edges.length; e++) {
      const edge = edges[e];
      const ja = joints[edge.aIdx];
      const jb = joints[edge.bIdx];

      const dx = jb.x - ja.x;
      const dy = jb.y - ja.y;
      const dist = Math.hypot(dx, dy) || 0.0001;
      const target = edge.kind === 'bone' ? edge.restLength : edge.currentTarget;
      const diff = (dist - target) / dist;

      const stiffness = edge.kind === 'bone' ? 0.92 : 0.42;
      const corrX = dx * 0.5 * diff * stiffness;
      const corrY = dy * 0.5 * diff * stiffness;

      ja.x += corrX;
      ja.y += corrY;
      jb.x -= corrX;
      jb.y -= corrY;

      if (iter === CONSTRAINT_ITERS - 1) {
        edge.stress = Math.min(1, Math.abs(dist - target) / (target * 0.25));
      }
    }

    // Solve ground collision on the second half of constraint passes for accurate leverage
    if (iter >= CONSTRAINT_ITERS - 4) {
      for (let i = 0; i < numJoints; i++) {
        const j = joints[i];
        const groundY = getTerrainHeight(mapId, j.x);
        const pen = j.y + j.radius - groundY;

        if (pen > 0) {
          const { nx, ny } = getTerrainNormal(mapId, j.x);
          // Project along upward normal
          j.x += nx * pen * 0.85;
          j.y += ny * pen * 0.85;
          // Ensure vertical floor clearance never slips under steep bevels
          const exactGroundY = getTerrainHeight(mapId, j.x);
          if (j.y + j.radius > exactGroundY) {
            j.y = exactGroundY - j.radius;
          }

          j.onGround = true;

          // Apply tangential friction & impact damping on the final iteration
          if (iter === CONSTRAINT_ITERS - 1) {
            const vx = j.x - j.prevX;
            const vy = j.y - j.prevY;

            // Tangent vector (tx, ty) perpendicular to upward normal (nx, ny)
            const tx = -ny;
            const ty = nx;

            const vDotT = vx * tx + vy * ty;
            const vDotN = vx * nx + vy * ny;

            // Asymmetric high traction grip: strong grip on push-off so legs propel body cleanly
            const frictionGrip = vDotT < 0 ? 0.88 : 0.72;
            const dampedVT = vDotT * (1 - frictionGrip);
            const dampedVN = vDotN < 0 ? -vDotN * 0.06 : vDotN;

            j.prevX = j.x - (tx * dampedVT + nx * dampedVN);
            j.prevY = j.y - (ty * dampedVT + ny * dampedVN);

            const impactSpeed = Math.max(0, -vDotN) / dt;
            if (!prevGroundFlags[i] && impactSpeed > 85) {
              const intensity = Math.min(1, impactSpeed / 420);
              j.impactForce = intensity;
              if (outImpacts && (isLeader || intensity > 0.65)) {
                outImpacts.push({
                  x: j.x,
                  y: exactGroundY,
                  intensity,
                  isLeader,
                });
              }
            }
          }
        }
      }
    }
  }

  // 5. Update distance, speed, and fitness metrics
  let postSumX = 0;
  let anyGround = false;
  for (let i = 0; i < numJoints; i++) {
    postSumX += joints[i].x;
    if (joints[i].onGround) anyGround = true;
  }

  const newComX = postSumX / numJoints;
  const speedMps = Math.max(0, avgVx / PIXELS_PER_METER);
  if (speedMps > creature.peakSpeedMps) {
    creature.peakSpeedMps = speedMps;
  }

  creature.currentX = newComX;
  if (newComX > creature.maxX) {
    creature.maxX = newComX;
  }
  creature.distanceM = newComX / PIXELS_PER_METER;
  creature.maxDistanceM = creature.maxX / PIXELS_PER_METER;
  creature.airTime = anyGround ? 0 : creature.airTime + dt;

  // Fitness strongly rewards forward progress + sustained forward position + slight speed bonus
  const forwardScore = creature.distanceM * 0.72 + creature.maxDistanceM * 0.28;
  genome.fitness = forwardScore * 10 + creature.peakSpeedMps * 0.35;
  genome.maxDistanceM = creature.maxDistanceM;

  // Keep comX referenced cleanly
  void comX;
}

/**
 * Smart helper that automatically adds muscles across hinged bones for players who sketch bone-only skeletons!
 */
export function autoRigMuscles(bp: CreatureBlueprint): CreatureBlueprint {
  const existingPairs = new Set<string>();
  const makeKey = (a: string, b: string) => (a < b ? `${a}|${b}` : `${b}|${a}`);

  bp.edges.forEach((e) => existingPairs.add(makeKey(e.a, e.b)));

  // Build adjacency of bones
  const boneNeighbors = new Map<string, string[]>();
  for (const j of bp.joints) {
    boneNeighbors.set(j.id, []);
  }
  for (const e of bp.edges) {
    if (e.kind === 'bone') {
      boneNeighbors.get(e.a)?.push(e.b);
      boneNeighbors.get(e.b)?.push(e.a);
    }
  }

  const newEdges = [...bp.edges];
  let addedCount = 0;

  // For every hinge joint shared by two bones (u - hinge - v), bridge (u, v) with a contractile muscle!
  for (const [, neighbors] of boneNeighbors.entries()) {
    for (let i = 0; i < neighbors.length; i++) {
      for (let k = i + 1; k < neighbors.length; k++) {
        const u = neighbors[i];
        const v = neighbors[k];
        const key = makeKey(u, v);
        if (!existingPairs.has(key) && addedCount < 8) {
          existingPairs.add(key);
          newEdges.push({
            id: `m_auto_${Date.now()}_${addedCount++}`,
            a: u,
            b: v,
            kind: 'muscle',
          });
        }
      }
    }
  }

  // Fallback: if all joints already formed closed bone triangles, connect two non-adjacent joints with muscles
  if (addedCount === 0 && bp.joints.length >= 2) {
    for (let i = 0; i < bp.joints.length && addedCount < 3; i++) {
      for (let k = i + 1; k < bp.joints.length && addedCount < 3; k++) {
        const key = makeKey(bp.joints[i].id, bp.joints[k].id);
        if (!existingPairs.has(key)) {
          existingPairs.add(key);
          newEdges.push({
            id: `m_auto_${Date.now()}_${addedCount++}`,
            a: bp.joints[i].id,
            b: bp.joints[k].id,
            kind: 'muscle',
          });
        }
      }
    }
  }

  return {
    ...bp,
    edges: newEdges,
  };
}
