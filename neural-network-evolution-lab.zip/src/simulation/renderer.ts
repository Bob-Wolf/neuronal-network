import {
  CreatureBlueprint,
  CreatureInstance,
  EditorTool,
  FloatingPopup,
  GameScreen,
  JointBlueprint,
  MapId,
  Particle,
} from '../types/simulation';
import { HIDDEN_SIZE, INPUT_LABELS, INPUT_SIZE } from './neuralNet';
import { JOINT_RADIUS } from './physics';
import { getTerrainHeight, MAP_CONFIGS, PIXELS_PER_METER } from './terrain';

export interface CameraState {
  x: number;
  y: number;
  zoom: number;
  shakeX: number;
  shakeY: number;
}

export interface EditorInteractionPreview {
  tool: EditorTool;
  pointerWorldX: number;
  pointerWorldY: number;
  hoveredJointId: string | null;
  hoveredEdgeId: string | null;
  dragStartJointId: string | null;
  dragStartX: number;
  dragStartY: number;
  isDragging: boolean;
}

export interface RenderFrameParams {
  ctx: CanvasRenderingContext2D;
  width: number;
  height: number;
  screen: GameScreen;
  mapId: MapId;
  camera: CameraState;
  blueprint: CreatureBlueprint;
  editorPreview: EditorInteractionPreview | null;
  population: CreatureInstance[];
  leaderIndex: number;
  bestDistanceM: number;
  particles: Particle[];
  popups: FloatingPopup[];
  boostActive: boolean;
  simTime: number;
  showNeuralOverlay: boolean;
}

export function worldToScreen(
  wx: number,
  wy: number,
  camera: CameraState,
  width: number,
  height: number
): { sx: number; sy: number } {
  const sx = (wx - camera.x) * camera.zoom + width * 0.5 + camera.shakeX;
  const sy = (wy - camera.y) * camera.zoom + height * 0.62 + camera.shakeY;
  return { sx, sy };
}

export function screenToWorld(
  sx: number,
  sy: number,
  camera: CameraState,
  width: number,
  height: number
): { wx: number; wy: number } {
  const wx = (sx - width * 0.5 - camera.shakeX) / camera.zoom + camera.x;
  const wy = (sy - height * 0.62 - camera.shakeY) / camera.zoom + camera.y;
  return { wx, wy };
}

export function renderSimulationFrame(params: RenderFrameParams): void {
  const {
    ctx,
    width,
    height,
    screen,
    mapId,
    camera,
    blueprint,
    editorPreview,
    population,
    leaderIndex,
    bestDistanceM,
    particles,
    popups,
    boostActive,
    simTime,
    showNeuralOverlay,
  } = params;

  const mapCfg = MAP_CONFIGS[mapId];

  // 1. Apple Studio light background gradient
  const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
  bgGrad.addColorStop(0, '#F5F5F7');
  bgGrad.addColorStop(0.55, '#FAFAFC');
  bgGrad.addColorStop(1, '#FFFFFF');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // 2. Subtle Parallax Horizon Silhouette (0.22x speed)
  drawParallaxBackdrop(ctx, width, height, camera, mapId);

  // 3. World-space Blueprint Grid
  drawBlueprintGrid(ctx, width, height, camera);

  // Enter world transform
  ctx.save();
  ctx.translate(width * 0.5 + camera.shakeX, height * 0.62 + camera.shakeY);
  ctx.scale(camera.zoom, camera.zoom);
  ctx.translate(-camera.x, -camera.y);

  const worldLeft = camera.x - (width * 0.55) / camera.zoom - 60;
  const worldRight = camera.x + (width * 0.55) / camera.zoom + 60;
  const worldBottom = camera.y + (height * 0.45) / camera.zoom + 200;

  // 4. Build Pad Zone Highlight (visible strongly in Build mode, subtly in Evolve)
  drawBuildPadGuides(ctx, screen, mapCfg.accentColor, simTime);

  // 5. Distance Flags, Personal Record Beam & Target Finish Gate
  drawDistanceMarkers(
    ctx,
    mapId,
    worldLeft,
    worldRight,
    bestDistanceM,
    mapCfg.targetMeters,
    mapCfg.accentColor
  );

  // 6. Render Terrain Polygon + Geological Hatch + Top Cap
  drawTerrain(ctx, mapId, worldLeft, worldRight, worldBottom);

  // 7. Render Either Editor Blueprint OR Active Evolution Population
  if (screen === 'build') {
    drawBlueprintCreature(ctx, blueprint, editorPreview, simTime);
  } else {
    // Draw non-leader ghost population first
    for (let i = 0; i < population.length; i++) {
      if (i === leaderIndex) continue;
      drawRuntimeCreature(ctx, population[i], mapId, false, false);
    }
    // Draw champion leader creature crisply on top
    const leader = population[leaderIndex];
    if (leader) {
      drawRuntimeCreature(ctx, leader, mapId, true, boostActive);
    }
  }

  // 8. World Particles (dust puffs, bio-sparks, milestone confetti)
  drawParticles(ctx, particles);

  // 9. World Floating Popups (+10m!, NEW RECORD!, SURGE!)
  drawPopups(ctx, popups);

  ctx.restore();

  // 10. Screen-space Live Neural Network Visualizer Overlay
  if (screen === 'evolve' && showNeuralOverlay && population[leaderIndex]) {
    drawNeuralHUD(ctx, width, population[leaderIndex], boostActive);
  }
}

function drawParallaxBackdrop(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  camera: CameraState,
  mapId: MapId
): void {
  ctx.save();
  const baseY = height * 0.62 - camera.y * camera.zoom * 0.18;
  ctx.fillStyle =
    mapId === 'dunes'
      ? 'rgba(245, 158, 11, 0.055)'
      : mapId === 'steps'
      ? 'rgba(6, 182, 212, 0.055)'
      : 'rgba(15, 23, 42, 0.035)';

  ctx.beginPath();
  ctx.moveTo(0, height);
  const stepPx = 28;
  for (let sx = 0; sx <= width + stepPx; sx += stepPx) {
    const px = sx + camera.x * 0.22;
    let offset = 0;
    if (mapId === 'dunes') {
      offset = Math.sin(px * 0.0045) * 48 + Math.cos(px * 0.009) * 20 - 55;
    } else if (mapId === 'steps') {
      const block = Math.floor(px / 110);
      offset = -35 - ((block * 29) % 65);
    } else {
      offset = Math.sin(px * 0.0025) * 18 - 40;
    }
    ctx.lineTo(sx, baseY + offset);
  }
  ctx.lineTo(width, height);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawBlueprintGrid(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  camera: CameraState
): void {
  const minor = PIXELS_PER_METER / 3; // 20px
  const major = PIXELS_PER_METER; // 60px = 1m

  const left = camera.x - (width * 0.5) / camera.zoom;
  const right = camera.x + (width * 0.5) / camera.zoom;
  const top = camera.y - (height * 0.62) / camera.zoom;
  const bottom = camera.y + (height * 0.38) / camera.zoom;

  ctx.save();
  ctx.lineWidth = 1;

  // Whisper-light studio minor grid lines
  if (camera.zoom >= 0.72) {
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.032)';
    ctx.beginPath();
    const startX = Math.floor(left / minor) * minor;
    for (let x = startX; x <= right; x += minor) {
      const sx = (x - camera.x) * camera.zoom + width * 0.5;
      ctx.moveTo(sx, 0);
      ctx.lineTo(sx, height);
    }
    const startY = Math.floor(top / minor) * minor;
    for (let y = startY; y <= bottom; y += minor) {
      const sy = (y - camera.y) * camera.zoom + height * 0.62;
      ctx.moveTo(0, sy);
      ctx.lineTo(width, sy);
    }
    ctx.stroke();
  }

  // Crisp subtle 1-meter major lines
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.06)';
  ctx.beginPath();
  const startMajorX = Math.floor(left / major) * major;
  for (let x = startMajorX; x <= right; x += major) {
    const sx = (x - camera.x) * camera.zoom + width * 0.5;
    ctx.moveTo(sx, 0);
    ctx.lineTo(sx, height);
  }
  const startMajorY = Math.floor(top / major) * major;
  for (let y = startMajorY; y <= bottom; y += major) {
    const sy = (y - camera.y) * camera.zoom + height * 0.62;
    ctx.moveTo(0, sy);
    ctx.lineTo(width, sy);
  }
  ctx.stroke();
  ctx.restore();
}

function drawBuildPadGuides(
  ctx: CanvasRenderingContext2D,
  screen: GameScreen,
  accentColor: string,
  simTime: number
): void {
  if (screen !== 'build') return;

  ctx.save();
  // Clean frosted studio build frame
  ctx.fillStyle = 'rgba(255, 255, 255, 0.52)';
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.08)';
  ctx.lineWidth = 1.2;
  ctx.setLineDash([5, 5]);
  ctx.beginPath();
  ctx.roundRect(-145, -210, 290, 210, 20);
  ctx.fill();
  ctx.stroke();
  ctx.setLineDash([]);

  // Center alignment hairline
  ctx.strokeStyle = 'rgba(0, 122, 255, 0.18)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, -210);
  ctx.lineTo(0, 0);
  ctx.stroke();

  // Gentle forward motion label
  const pulseX = Math.sin(simTime * 2.8) * 3;
  ctx.fillStyle = accentColor;
  ctx.font = '600 11px -apple-system, BlinkMacSystemFont, "Inter", sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('Forward →', 162 + pulseX, -98);

  ctx.fillStyle = 'rgba(29, 29, 31, 0.45)';
  ctx.font = '500 10.5px -apple-system, BlinkMacSystemFont, "Inter", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Assembly Pad · 0.0 m', 0, -222);

  ctx.restore();
}

function drawDistanceMarkers(
  ctx: CanvasRenderingContext2D,
  mapId: MapId,
  worldLeft: number,
  worldRight: number,
  bestDistanceM: number,
  targetMeters: number,
  accentColor: string
): void {
  ctx.save();
  const minMeter = Math.max(-5, Math.floor(worldLeft / PIXELS_PER_METER / 5) * 5);
  const maxMeter = Math.ceil(worldRight / PIXELS_PER_METER / 5) * 5;

  for (let m = minMeter; m <= maxMeter; m += 5) {
    const wx = m * PIXELS_PER_METER;
    const gy = getTerrainHeight(mapId, wx);
    const isMajor = m % 10 === 0;
    const postH = isMajor ? 34 : 20;

    ctx.strokeStyle =
      m === 0 ? '#0F172A' : isMajor ? 'rgba(15, 23, 42, 0.42)' : 'rgba(100, 116, 139, 0.28)';
    ctx.lineWidth = isMajor ? 1.6 : 1;
    ctx.beginPath();
    ctx.moveTo(wx, gy);
    ctx.lineTo(wx, gy - postH);
    ctx.stroke();

    if (isMajor || m === 0) {
      ctx.fillStyle = m === 0 ? '#1D1D1F' : 'rgba(29, 29, 31, 0.55)';
      ctx.font = '600 10px -apple-system, BlinkMacSystemFont, "Inter", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(m === 0 ? 'Start' : `${m} m`, wx, gy - postH - 7);
    }
  }

  // Personal Best Record Marker
  if (bestDistanceM >= 0.5) {
    const bx = bestDistanceM * PIXELS_PER_METER;
    if (bx >= worldLeft - 80 && bx <= worldRight + 80) {
      const bgy = getTerrainHeight(mapId, bx);
      ctx.strokeStyle = 'rgba(255, 149, 0, 0.72)';
      ctx.lineWidth = 1.6;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(bx, bgy);
      ctx.lineTo(bx, bgy - 135);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = '#FF9500';
      ctx.beginPath();
      ctx.roundRect(bx - 42, bgy - 157, 84, 22, 11);
      ctx.fill();
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '600 10px -apple-system, BlinkMacSystemFont, "Inter", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(`Best · ${bestDistanceM.toFixed(1)}m`, bx, bgy - 142.5);
    }
  }

  // Map Target Finish Banner
  const tx = targetMeters * PIXELS_PER_METER;
  if (tx >= worldLeft - 100 && tx <= worldRight + 100) {
    const tgy = getTerrainHeight(mapId, tx);
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(tx, tgy);
    ctx.lineTo(tx, tgy - 175);
    ctx.stroke();

    ctx.fillStyle = '#1D1D1F';
    ctx.beginPath();
    ctx.roundRect(tx - 46, tgy - 203, 92, 26, 13);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = '600 10.5px -apple-system, BlinkMacSystemFont, "Inter", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`Goal · ${targetMeters}m`, tx, tgy - 186.5);
  }

  ctx.restore();
}

function drawTerrain(
  ctx: CanvasRenderingContext2D,
  mapId: MapId,
  worldLeft: number,
  worldRight: number,
  worldBottom: number
): void {
  const mapCfg = MAP_CONFIGS[mapId];
  const step = 4;

  ctx.save();
  ctx.beginPath();
  const startY = getTerrainHeight(mapId, worldLeft);
  ctx.moveTo(worldLeft, worldBottom);
  ctx.lineTo(worldLeft, startY);

  for (let x = worldLeft + step; x <= worldRight; x += step) {
    ctx.lineTo(x, getTerrainHeight(mapId, x));
  }
  ctx.lineTo(worldRight, getTerrainHeight(mapId, worldRight));
  ctx.lineTo(worldRight, worldBottom);
  ctx.closePath();

  const soilGrad = ctx.createLinearGradient(0, -80, 0, 260);
  soilGrad.addColorStop(0, mapCfg.soilColor);
  soilGrad.addColorStop(1, mapCfg.subSoilColor);
  ctx.fillStyle = soilGrad;
  ctx.fill();

  // Crisp top surface traction cap strip
  ctx.strokeStyle = mapCfg.topCapColor;
  ctx.lineWidth = 5;
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(worldLeft, startY);
  for (let x = worldLeft + step; x <= worldRight; x += step) {
    ctx.lineTo(x, getTerrainHeight(mapId, x));
  }
  ctx.stroke();

  // Subtle top highlight hairline
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(worldLeft, startY - 1.5);
  for (let x = worldLeft + step; x <= worldRight; x += step) {
    ctx.lineTo(x, getTerrainHeight(mapId, x) - 1.5);
  }
  ctx.stroke();

  ctx.restore();
}

function drawBlueprintCreature(
  ctx: CanvasRenderingContext2D,
  blueprint: CreatureBlueprint,
  preview: EditorInteractionPreview | null,
  simTime: number
): void {
  const jointMap = new Map<string, JointBlueprint>();
  blueprint.joints.forEach((j) => jointMap.set(j.id, j));

  ctx.save();

  // Draw muscles first
  for (const edge of blueprint.edges) {
    if (edge.kind !== 'muscle') continue;
    const ja = jointMap.get(edge.a);
    const jb = jointMap.get(edge.b);
    if (!ja || !jb) continue;
    const isHoveredErase =
      preview?.tool === 'erase' && preview.hoveredEdgeId === edge.id;
    drawMuscleSegment(
      ctx,
      ja.x,
      ja.y,
      jb.x,
      jb.y,
      Math.sin(simTime * 2.5) * 0.15,
      isHoveredErase ? '#EF4444' : undefined,
      1
    );
  }

  // Draw bones next
  for (const edge of blueprint.edges) {
    if (edge.kind !== 'bone') continue;
    const ja = jointMap.get(edge.a);
    const jb = jointMap.get(edge.b);
    if (!ja || !jb) continue;
    const isHoveredErase =
      preview?.tool === 'erase' && preview.hoveredEdgeId === edge.id;
    drawBoneSegment(ctx, ja.x, ja.y, jb.x, jb.y, isHoveredErase, 1);
  }

  // Interactive rubber-band drag preview for Bone or Muscle creation
  if (preview && preview.isDragging && (preview.tool === 'bone' || preview.tool === 'muscle')) {
    let targetX = preview.pointerWorldX;
    let targetY = preview.pointerWorldY;
    if (preview.hoveredJointId && preview.hoveredJointId !== preview.dragStartJointId) {
      const snapJ = jointMap.get(preview.hoveredJointId);
      if (snapJ) {
        targetX = snapJ.x;
        targetY = snapJ.y;
      }
    }

    ctx.save();
    ctx.setLineDash([6, 5]);
    ctx.lineWidth = 4;
    ctx.strokeStyle = preview.tool === 'bone' ? '#0F172A' : '#F43F5E';
    ctx.beginPath();
    ctx.moveTo(preview.dragStartX, preview.dragStartY);
    ctx.lineTo(targetX, targetY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Length label in meters
    const distM = Math.hypot(targetX - preview.dragStartX, targetY - preview.dragStartY) / PIXELS_PER_METER;
    if (distM > 0.12) {
      const mx = (preview.dragStartX + targetX) * 0.5;
      const my = (preview.dragStartY + targetY) * 0.5 - 12;
      ctx.fillStyle = '#0F172A';
      ctx.font = '700 10px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`${distM.toFixed(2)}m`, mx, my);
    }

    // Ghost target joint preview
    ctx.fillStyle = preview.tool === 'bone' ? 'rgba(16, 185, 129, 0.35)' : 'rgba(244, 63, 94, 0.35)';
    ctx.beginPath();
    ctx.arc(targetX, targetY, JOINT_RADIUS + 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Draw joints on top
  for (const j of blueprint.joints) {
    const isHovered = preview?.hoveredJointId === j.id;
    const isEraseTarget = preview?.tool === 'erase' && isHovered;

    if (isHovered) {
      ctx.beginPath();
      ctx.arc(j.x, j.y, JOINT_RADIUS + 8, 0, Math.PI * 2);
      ctx.fillStyle = isEraseTarget
        ? 'rgba(239, 68, 68, 0.25)'
        : 'rgba(16, 185, 129, 0.22)';
      ctx.fill();
    }

    ctx.beginPath();
    ctx.arc(j.x, j.y, JOINT_RADIUS, 0, Math.PI * 2);
    ctx.fillStyle = isEraseTarget ? '#EF4444' : '#0F172A';
    ctx.fill();

    ctx.beginPath();
    ctx.arc(j.x, j.y, JOINT_RADIUS - 3.4, 0, Math.PI * 2);
    ctx.fillStyle = '#FFFFFF';
    ctx.fill();
  }

  // Cursor preview circle when hovering empty space in Bone tool
  if (
    preview &&
    !preview.isDragging &&
    preview.tool === 'bone' &&
    !preview.hoveredJointId
  ) {
    ctx.beginPath();
    ctx.arc(preview.pointerWorldX, preview.pointerWorldY, JOINT_RADIUS, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.35)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }

  ctx.restore();
}

export function drawRuntimeCreature(
  ctx: CanvasRenderingContext2D,
  creature: CreatureInstance,
  mapId: MapId,
  isLeader: boolean,
  boostActive: boolean
): void {
  const { joints, edges } = creature;
  if (joints.length === 0) return;

  const alpha = isLeader ? 1.0 : 0.17;
  ctx.save();
  ctx.globalAlpha = alpha;

  // Ground drop shadow for leader creature so air height reads clearly
  if (isLeader) {
    let minX = Infinity;
    let maxX = -Infinity;
    for (const j of joints) {
      if (j.x < minX) minX = j.x;
      if (j.x > maxX) maxX = j.x;
    }
    const midX = (minX + maxX) * 0.5;
    const shadowY = getTerrainHeight(mapId, midX);
    ctx.fillStyle = 'rgba(15, 23, 42, 0.16)';
    ctx.beginPath();
    ctx.ellipse(
      midX,
      shadowY + 2,
      Math.max(20, (maxX - minX) * 0.52),
      5,
      0,
      0,
      Math.PI * 2
    );
    ctx.fill();
  }

  // Muscles
  for (let i = 0; i < edges.length; i++) {
    const e = edges[i];
    if (e.kind !== 'muscle') continue;
    const ja = joints[e.aIdx];
    const jb = joints[e.bIdx];
    drawMuscleSegment(
      ctx,
      ja.x,
      ja.y,
      jb.x,
      jb.y,
      e.activation,
      boostActive && isLeader ? '#F59E0B' : undefined,
      alpha
    );
  }

  // Bones
  for (let i = 0; i < edges.length; i++) {
    const e = edges[i];
    if (e.kind !== 'bone') continue;
    const ja = joints[e.aIdx];
    const jb = joints[e.bIdx];
    drawBoneSegment(ctx, ja.x, ja.y, jb.x, jb.y, false, alpha);
  }

  // Joints
  let topY = Infinity;
  let sumX = 0;
  for (let i = 0; i < joints.length; i++) {
    const j = joints[i];
    sumX += j.x;
    if (j.y < topY) topY = j.y;

    if (isLeader && j.onGround) {
      ctx.beginPath();
      ctx.arc(j.x, j.y, j.radius + 4.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(6, 182, 212, 0.35)';
      ctx.fill();
    }

    ctx.beginPath();
    ctx.arc(j.x, j.y, j.radius, 0, Math.PI * 2);
    ctx.fillStyle = '#0F172A';
    ctx.fill();

    ctx.beginPath();
    ctx.arc(j.x, j.y, j.radius - 3.3, 0, Math.PI * 2);
    ctx.fillStyle = j.onGround && isLeader ? '#06B6D4' : '#FFFFFF';
    ctx.fill();
  }

  // Floating Leader Distance Ribbon
  if (isLeader) {
    const cx = sumX / joints.length;
    const badgeY = topY - 26;
    const label = `${creature.distanceM >= 0 ? '+' : ''}${creature.distanceM.toFixed(1)}m`;

    ctx.fillStyle = boostActive ? '#D97706' : '#0F172A';
    ctx.beginPath();
    ctx.roundRect(cx - 32, badgeY - 14, 64, 20, 6);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = '700 10.5px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(label, cx, badgeY - 0.5);
  }

  ctx.restore();
}

function drawBoneSegment(
  ctx: CanvasRenderingContext2D,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  highlightErase: boolean,
  _alpha: number
): void {
  ctx.lineCap = 'round';
  ctx.strokeStyle = highlightErase ? '#EF4444' : '#1E293B';
  ctx.lineWidth = 8.2;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  ctx.strokeStyle = highlightErase ? '#FCA5A5' : '#F8FAFC';
  ctx.lineWidth = 3.8;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
}

function drawMuscleSegment(
  ctx: CanvasRenderingContext2D,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  activation: number,
  overrideColor?: string,
  _alpha = 1
): void {
  // activation < 0 => contracting (thick crimson), activation > 0 => extending (sleek sky-blue)
  const contractAmount = Math.max(0, -activation);
  const extendAmount = Math.max(0, activation);

  const thickness = 5.4 + contractAmount * 4.2 - extendAmount * 1.6;
  const mainColor =
    overrideColor ??
    (activation < -0.08
      ? '#F43F5E'
      : activation > 0.08
      ? '#0284C7'
      : '#FB7185');

  // Outer belly spindle curve for organic bio-muscle silhouette
  const mx = (x1 + x2) * 0.5;
  const my = (y1 + y2) * 0.5;
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  const bulge = 3.2 + contractAmount * 4.5;

  ctx.lineCap = 'round';
  ctx.strokeStyle = mainColor;
  ctx.lineWidth = thickness * 0.65;

  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.quadraticCurveTo(mx + nx * bulge, my + ny * bulge, x2, y2);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.quadraticCurveTo(mx - nx * bulge, my - ny * bulge, x2, y2);
  ctx.stroke();
}

function drawParticles(ctx: CanvasRenderingContext2D, particles: Particle[]): void {
  ctx.save();
  for (let i = 0; i < particles.length; i++) {
    const p = particles[i];
    if (p.alpha <= 0.01) continue;
    ctx.globalAlpha = Math.max(0, Math.min(1, p.alpha));
    ctx.fillStyle = p.color;

    if (p.kind === 'ring') {
      ctx.strokeStyle = p.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.stroke();
    } else if (p.kind === 'confetti') {
      ctx.fillRect(p.x - p.size * 0.5, p.y - p.size * 0.5, p.size, p.size * 0.7);
    } else {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
}

function drawPopups(ctx: CanvasRenderingContext2D, popups: FloatingPopup[]): void {
  ctx.save();
  for (let i = 0; i < popups.length; i++) {
    const pop = popups[i];
    ctx.globalAlpha = Math.max(0, Math.min(1, pop.alpha));
    ctx.font = `700 ${Math.round(13 * pop.scale)}px "JetBrains Mono", monospace`;
    ctx.textAlign = 'center';
    ctx.fillStyle = pop.color;
    ctx.fillText(pop.text, pop.x, pop.y);
    if (pop.subtext) {
      ctx.font = '600 10px "Space Grotesk", sans-serif';
      ctx.fillStyle = '#334155';
      ctx.fillText(pop.subtext, pop.x, pop.y + 14);
    }
  }
  ctx.restore();
}

export function getNeuralHudBounds(
  canvasWidth: number,
  numMuscles: number
): { x: number; y: number; w: number; h: number } {
  const isCompact = canvasWidth < 680;
  const x = 16;
  const y = isCompact ? 116 : 82;
  const w = isCompact ? 172 : 242;
  const numOutputs = Math.min(6, Math.max(1, numMuscles));
  const rows = Math.max(INPUT_SIZE, HIDDEN_SIZE, numOutputs);
  const h = 44 + rows * (isCompact ? 16 : 19);
  return { x, y, w, h };
}

function drawNeuralHUD(
  ctx: CanvasRenderingContext2D,
  canvasWidth: number,
  leader: CreatureInstance,
  boostActive: boolean
): void {
  const isCompact = canvasWidth < 680;
  const { x: cardX, y: cardY, w: cardW, h: cardH } = getNeuralHudBounds(
    canvasWidth,
    leader.muscleIndices.length
  );
  const numOutputs = Math.min(6, Math.max(1, leader.muscleIndices.length));

  ctx.save();

  // Frosted macOS-style floating widget shadow & card
  ctx.shadowColor = 'rgba(0, 0, 0, 0.08)';
  ctx.shadowBlur = 22;
  ctx.shadowOffsetY = 8;
  ctx.fillStyle = 'rgba(255, 255, 255, 0.84)';
  ctx.strokeStyle = boostActive ? 'rgba(255, 149, 0, 0.5)' : 'rgba(0, 0, 0, 0.065)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.roundRect(cardX, cardY, cardW, cardH, 18);
  ctx.fill();
  ctx.shadowColor = 'transparent';
  ctx.stroke();

  ctx.fillStyle = '#1D1D1F';
  ctx.font = '600 10.5px -apple-system, BlinkMacSystemFont, "Inter", sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(
    boostActive ? 'Surge Active ⚡' : `Neural Cortex · ${leader.genome.baseFreq.toFixed(1)} Hz`,
    cardX + 14,
    cardY + 19
  );

  ctx.fillStyle = '#007AFF';
  ctx.font = '600 10px -apple-system, BlinkMacSystemFont, "Inter", sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText('Inspect ↗', cardX + cardW - 13, cardY + 19);

  const col1X = cardX + (isCompact ? 22 : 66);
  const col2X = cardX + (isCompact ? 92 : 138);
  const col3X = cardX + cardW - 22;
  const topY = cardY + 34;
  const rowGap = isCompact ? 15.5 : 18.5;

  const inPositions: { x: number; y: number; val: number }[] = [];
  for (let i = 0; i < INPUT_SIZE; i++) {
    inPositions.push({
      x: col1X,
      y: topY + i * rowGap,
      val: leader.lastInputs[i] ?? 0,
    });
  }

  const hidPositions: { x: number; y: number; val: number }[] = [];
  for (let h = 0; h < HIDDEN_SIZE; h++) {
    hidPositions.push({
      x: col2X,
      y: topY + h * rowGap,
      val: leader.lastHidden[h] ?? 0,
    });
  }

  const outOffset = ((INPUT_SIZE - numOutputs) * rowGap) * 0.5;
  const outPositions: { x: number; y: number; val: number }[] = [];
  for (let m = 0; m < numOutputs; m++) {
    outPositions.push({
      x: col3X,
      y: topY + outOffset + m * rowGap,
      val: leader.lastOutputs[m] ?? 0,
    });
  }

  // Draw active synapses W1
  for (let h = 0; h < HIDDEN_SIZE; h++) {
    for (let i = 0; i < INPUT_SIZE; i++) {
      const w = leader.genome.w1[h * INPUT_SIZE + i] ?? 0;
      const signal = w * inPositions[i].val;
      const mag = Math.min(1, Math.abs(signal) * 0.55);
      if (mag < 0.08) continue;
      ctx.strokeStyle =
        signal >= 0
          ? `rgba(6, 182, 212, ${mag * 0.72})`
          : `rgba(244, 63, 94, ${mag * 0.72})`;
      ctx.lineWidth = 0.7 + mag * 1.4;
      ctx.beginPath();
      ctx.moveTo(inPositions[i].x, inPositions[i].y);
      ctx.lineTo(hidPositions[h].x, hidPositions[h].y);
      ctx.stroke();
    }
  }

  // Draw active synapses W2
  for (let m = 0; m < numOutputs; m++) {
    for (let h = 0; h < HIDDEN_SIZE; h++) {
      const w = leader.genome.w2[m * HIDDEN_SIZE + h] ?? 0;
      const signal = w * hidPositions[h].val;
      const mag = Math.min(1, Math.abs(signal) * 0.55);
      if (mag < 0.08) continue;
      ctx.strokeStyle =
        signal >= 0
          ? `rgba(6, 182, 212, ${mag * 0.8})`
          : `rgba(244, 63, 94, ${mag * 0.8})`;
      ctx.lineWidth = 0.7 + mag * 1.5;
      ctx.beginPath();
      ctx.moveTo(hidPositions[h].x, hidPositions[h].y);
      ctx.lineTo(outPositions[m].x, outPositions[m].y);
      ctx.stroke();
    }
  }

  // Draw input nodes + labels
  for (let i = 0; i < inPositions.length; i++) {
    const p = inPositions[i];
    if (!isCompact) {
      ctx.fillStyle = '#64748B';
      ctx.font = '600 8px "JetBrains Mono", monospace';
      ctx.textAlign = 'right';
      ctx.fillText(INPUT_LABELS[i], p.x - 8, p.y + 3);
    }
    drawNeuronCircle(ctx, p.x, p.y, p.val, 4.2);
  }

  // Draw hidden nodes
  for (let h = 0; h < hidPositions.length; h++) {
    const p = hidPositions[h];
    drawNeuronCircle(ctx, p.x, p.y, p.val, 4.2);
  }

  // Draw output muscle nodes
  for (let m = 0; m < outPositions.length; m++) {
    const p = outPositions[m];
    drawNeuronCircle(ctx, p.x, p.y, -p.val, 5.0);
  }

  ctx.restore();
}

function drawNeuronCircle(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  val: number,
  r: number
): void {
  const clamped = Math.max(-1, Math.min(1, val));
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle =
    clamped > 0.1
      ? '#06B6D4'
      : clamped < -0.1
      ? '#F43F5E'
      : '#CBD5E1';
  ctx.fill();
  ctx.strokeStyle = '#0F172A';
  ctx.lineWidth = 1;
  ctx.stroke();
}
