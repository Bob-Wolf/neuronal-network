import React from 'react';
import {
  Award,
  Home,
  Infinity as InfinityIcon,
  Play,
  RotateCcw,
  SlidersHorizontal,
  Trophy,
} from 'lucide-react';
import {
  GenerationSummary,
  HighScoreEntry,
  MapId,
  RunEndReason,
} from '../types/simulation';
import { MAP_CONFIGS, MAP_LIST } from '../simulation/terrain';

interface PauseAndGameOverModalProps {
  mode: 'paused' | 'gameover' | 'leaderboard';
  runEndReason: RunEndReason;
  mapId: MapId;
  creatureName: string;
  onRenameCreature: (name: string) => void;
  generation: number;
  bestDistanceM: number;
  finalScore: number;
  isNewRecord: boolean;
  history: GenerationSummary[];
  highScores: HighScoreEntry[];
  onResume: () => void;
  onInstantRestart: () => void;
  onContinueEndless: () => void;
  onEditCreature: () => void;
  onSwitchMap: (map: MapId) => void;
  onMainMenu: () => void;
}

export const PauseAndGameOverModal: React.FC<PauseAndGameOverModalProps> = ({
  mode,
  runEndReason,
  mapId,
  creatureName,
  onRenameCreature,
  generation,
  bestDistanceM,
  finalScore,
  isNewRecord,
  history,
  highScores,
  onResume,
  onInstantRestart,
  onContinueEndless,
  onEditCreature,
  onSwitchMap,
  onMainMenu,
}) => {
  const mapCfg = MAP_CONFIGS[mapId];

  if (mode === 'leaderboard') {
    return (
      <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/25 backdrop-blur-sm p-4">
        <div className="w-full max-w-md apple-sheet rounded-[28px] p-6 sm:p-7">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-[11px] bg-[#FF9500]/14 text-[#FF9500] flex items-center justify-center">
                <Trophy className="w-4 h-4" />
              </div>
              <h2 className="text-[18px] font-semibold text-[#1D1D1F]">
                Hall of Records
              </h2>
            </div>
            <button
              type="button"
              onClick={onResume}
              className="px-3 py-1.5 rounded-full bg-black/[0.05] hover:bg-black/[0.09] text-xs font-semibold text-[#1D1D1F] cursor-pointer"
            >
              Done
            </button>
          </div>

          <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1 mb-5">
            {highScores.slice(0, 10).map((entry, idx) => (
              <div
                key={entry.id}
                className="flex items-center justify-between text-[13px] py-2.5 px-3.5 rounded-2xl bg-white/90 border border-black/[0.04]"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span
                    className={`font-mono text-xs font-semibold w-5 ${
                      idx === 0 ? 'text-[#FF9500]' : 'text-[#86868B]'
                    }`}
                  >
                    {idx + 1}
                  </span>
                  <span className="font-medium text-[#1D1D1F] truncate">
                    {entry.creatureName}
                  </span>
                  <span className="text-[10.5px] font-medium px-2 py-0.5 rounded-full bg-black/[0.045] text-[#86868B] capitalize">
                    {entry.mapId}
                  </span>
                </div>
                <div className="flex items-center gap-3 font-mono text-xs shrink-0">
                  <span className="text-[#86868B]">{entry.distanceM.toFixed(1)}m</span>
                  <span className="font-semibold text-[#1D1D1F]">
                    {entry.score.toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={onResume}
            className="w-full py-3 rounded-full bg-[#007AFF] hover:bg-[#0066D6] text-white text-[13.5px] font-semibold transition cursor-pointer"
          >
            Back to Studio
          </button>
        </div>
      </div>
    );
  }

  if (mode === 'paused') {
    return (
      <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/25 backdrop-blur-sm p-4">
        <div className="w-full max-w-md apple-sheet rounded-[28px] p-6 sm:p-7">
          <div className="flex items-center justify-between mb-6">
            <div>
              <span className="text-[11.5px] font-semibold text-[#007AFF] block mb-0.5">
                Simulation Paused
              </span>
              <h2 className="text-[20px] font-semibold text-[#1D1D1F] leading-tight">
                {mapCfg.name}
              </h2>
            </div>
            <div className="text-right font-mono">
              <div className="text-[11px] text-[#86868B]">Gen {generation}</div>
              <div className="text-[15px] font-semibold text-[#1D1D1F]">
                {bestDistanceM.toFixed(1)} m
              </div>
            </div>
          </div>

          {/* Segmented Map Switcher */}
          <div className="mb-6">
            <div className="text-[11.5px] font-medium text-[#86868B] mb-2">
              Switch Environment
            </div>
            <div className="apple-segment-track rounded-full grid grid-cols-3 gap-1">
              {MAP_LIST.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onSwitchMap(m.id)}
                  className={`py-2 px-2 rounded-full text-[12px] font-medium transition-all cursor-pointer ${
                    m.id === mapId
                      ? 'apple-segment-active font-semibold'
                      : 'text-[#6E6E73] hover:text-[#1D1D1F]'
                  }`}
                >
                  {m.id === 'flat' ? 'Grounds' : m.id === 'dunes' ? 'Dunes' : 'Steps'}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2.5">
            <button
              type="button"
              onClick={onResume}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-full bg-[#007AFF] hover:bg-[#0066D6] active:scale-[0.98] text-white font-semibold text-[14px] transition-all cursor-pointer shadow-[0_8px_20px_-4px_rgba(0,122,255,0.4)]"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Resume</span>
            </button>

            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={onInstantRestart}
                className="flex items-center justify-center gap-1.5 py-2.5 rounded-full bg-black/[0.05] hover:bg-black/[0.085] text-[#1D1D1F] font-medium text-[12.5px] transition cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restart</span>
              </button>

              <button
                type="button"
                onClick={onEditCreature}
                className="flex items-center justify-center gap-1.5 py-2.5 rounded-full bg-black/[0.05] hover:bg-black/[0.085] text-[#1D1D1F] font-medium text-[12.5px] transition cursor-pointer"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Edit Studio</span>
              </button>
            </div>

            <button
              type="button"
              onClick={onMainMenu}
              className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-full text-[#86868B] hover:text-[#1D1D1F] hover:bg-black/[0.04] font-medium text-[12.5px] transition cursor-pointer"
            >
              <Home className="w-3.5 h-3.5" />
              <span>Main Menu</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const beatGoal = runEndReason === 'target_reached' || bestDistanceM >= mapCfg.targetMeters;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/25 backdrop-blur-sm p-3.5 sm:p-5">
      <div className="w-full max-w-[520px] apple-sheet rounded-[30px] p-6 sm:p-7 max-h-[90vh] overflow-y-auto">
        {/* Top Summary Header */}
        <div className="flex items-start justify-between gap-3 mb-5">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span
                className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full ${
                  beatGoal
                    ? 'bg-[#34C759]/14 text-[#248A3D]'
                    : 'bg-black/[0.06] text-[#6E6E73]'
                }`}
              >
                {beatGoal ? 'Goal Reached' : 'Run Summary'}
              </span>
              {isNewRecord && (
                <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-[#FF9500] text-white flex items-center gap-1">
                  <Award className="w-3 h-3" /> New Record
                </span>
              )}
            </div>
            <h2 className="text-[21px] font-semibold text-[#1D1D1F] leading-tight">
              {mapCfg.name}
            </h2>
          </div>

          <div className="text-right">
            <div className="text-[11px] font-medium text-[#86868B]">
              Score
            </div>
            <div className="font-mono text-[24px] font-semibold text-[#007AFF] leading-tight">
              {finalScore.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Stat Bento Cards */}
        <div className="grid grid-cols-3 gap-2.5 mb-5">
          <div className="p-3.5 rounded-2xl bg-black/[0.035] text-center">
            <div className="text-[11px] font-medium text-[#86868B]">
              Distance
            </div>
            <div className="font-mono text-[16px] font-semibold text-[#1D1D1F] mt-0.5">
              {bestDistanceM.toFixed(1)} m
            </div>
          </div>
          <div className="p-3.5 rounded-2xl bg-black/[0.035] text-center">
            <div className="text-[11px] font-medium text-[#86868B]">
              Generations
            </div>
            <div className="font-mono text-[16px] font-semibold text-[#1D1D1F] mt-0.5">
              {generation}
            </div>
          </div>
          <div className="p-3.5 rounded-2xl bg-black/[0.035] text-center">
            <div className="text-[11px] font-medium text-[#86868B]">
              Multiplier
            </div>
            <div className="font-mono text-[16px] font-semibold text-[#1D1D1F] mt-0.5">
              {mapCfg.scoreMultiplier.toFixed(2)}×
            </div>
          </div>
        </div>

        {/* Evolution Curve Sparkline */}
        {history.length > 0 && (
          <div className="mb-5 p-4 rounded-2xl bg-black/[0.03]">
            <div className="text-[11.5px] font-medium text-[#86868B] mb-2.5">
              Distance by Generation
            </div>
            <div className="flex items-end gap-2 h-12">
              {history.slice(-10).map((item) => {
                const maxH = Math.max(10, ...history.map((h) => h.bestDistanceM));
                const hPct = Math.max(14, (Math.max(0, item.bestDistanceM) / maxH) * 100);
                return (
                  <div
                    key={item.generation}
                    className="flex-1 flex flex-col items-center gap-1"
                  >
                    <div
                      className="w-full rounded-full bg-[#34C759] transition-all"
                      style={{ height: `${hPct * 0.36}px` }}
                      title={`Gen ${item.generation}: ${item.bestDistanceM.toFixed(1)}m`}
                    />
                    <span className="font-mono text-[9.5px] text-[#86868B]">
                      G{item.generation}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Editable Specimen Name */}
        <div className="mb-5 flex items-center gap-3 bg-black/[0.035] rounded-2xl px-3.5 py-2">
          <span className="text-[12px] font-medium text-[#86868B] shrink-0">
            Specimen
          </span>
          <input
            type="text"
            value={creatureName}
            maxLength={24}
            onChange={(e) => onRenameCreature(e.target.value)}
            className="w-full bg-transparent text-[13px] font-semibold text-[#1D1D1F] focus:outline-none"
          />
        </div>

        {/* Top Local Records */}
        <div className="mb-6">
          <div className="text-[11.5px] font-medium text-[#86868B] mb-2">
            Leaderboard
          </div>
          <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
            {highScores.slice(0, 5).map((entry, idx) => (
              <div
                key={entry.id}
                className="flex items-center justify-between text-[12.5px] py-2 px-3 rounded-2xl bg-white/90 border border-black/[0.04]"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="font-mono text-xs font-semibold text-[#86868B] w-4">
                    {idx + 1}
                  </span>
                  <span className="font-medium text-[#1D1D1F] truncate">
                    {entry.creatureName}
                  </span>
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-black/[0.045] text-[#86868B] capitalize">
                    {entry.mapId}
                  </span>
                </div>
                <div className="font-mono text-xs flex items-center gap-3 shrink-0">
                  <span className="text-[#86868B]">{entry.distanceM.toFixed(1)}m</span>
                  <span className="font-semibold text-[#1D1D1F]">
                    {entry.score.toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pill Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-2.5">
          <button
            type="button"
            onClick={onContinueEndless}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-full bg-[#007AFF] hover:bg-[#0066D6] active:scale-[0.98] text-white font-semibold text-[13px] transition-all cursor-pointer shadow-[0_6px_18px_-3px_rgba(0,122,255,0.4)]"
          >
            <InfinityIcon className="w-4 h-4" />
            <span>Continue Endless</span>
          </button>

          <button
            type="button"
            onClick={onInstantRestart}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-full bg-[#1D1D1F] hover:bg-[#323236] active:scale-[0.98] text-white font-semibold text-[13px] transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restart</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={onEditCreature}
            className="flex items-center justify-center gap-1.5 py-2.5 rounded-full bg-black/[0.05] hover:bg-black/[0.085] text-[#1D1D1F] font-medium text-[12.5px] transition cursor-pointer"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Edit Creature</span>
          </button>

          <button
            type="button"
            onClick={onMainMenu}
            className="flex items-center justify-center gap-1.5 py-2.5 rounded-full bg-black/[0.05] hover:bg-black/[0.085] text-[#1D1D1F] font-medium text-[12.5px] transition cursor-pointer"
          >
            <Home className="w-3.5 h-3.5" />
            <span>Main Menu</span>
          </button>
        </div>
      </div>
    </div>
  );
};
