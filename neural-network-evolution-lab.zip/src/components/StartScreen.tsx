import React, { useState } from 'react';
import {
  Cpu,
  Dna,
  Play,
  Trophy,
  Volume2,
  VolumeX,
  SlidersHorizontal,
} from 'lucide-react';
import { CreatureBlueprint, HighScoreEntry, MapId } from '../types/simulation';
import { MAP_LIST } from '../simulation/terrain';
import { CREATURE_PRESETS } from '../simulation/presets';

interface StartScreenProps {
  selectedMap: MapId;
  onSelectMap: (map: MapId) => void;
  selectedPresetIndex: number;
  onSelectPreset: (index: number) => void;
  highScores: HighScoreEntry[];
  muted: boolean;
  onToggleMute: () => void;
  onStartBuild: () => void;
  onQuickEvolve: () => void;
  onOpenNeuralDashboard: () => void;
  customBlueprint: CreatureBlueprint | null;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  selectedMap,
  onSelectMap,
  selectedPresetIndex,
  onSelectPreset,
  highScores,
  muted,
  onToggleMute,
  onStartBuild,
  onQuickEvolve,
  onOpenNeuralDashboard,
}) => {
  const [showLeaderboard, setShowLeaderboard] = useState(false);

  const getBestForMap = (mapId: MapId): number => {
    return highScores
      .filter((s) => s.mapId === mapId)
      .reduce((max, s) => Math.max(max, s.distanceM), 0);
  };

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center p-4 sm:p-6 pointer-events-none">
      <div className="pointer-events-auto w-full max-w-[660px] apple-sheet rounded-[30px] p-6 sm:p-8 max-h-[90vh] overflow-y-auto transition-all">
        {/* Clean Header */}
        <div className="flex items-center justify-between gap-3 mb-7">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-[14px] bg-gradient-to-b from-[#2C2C2E] to-[#1D1D1F] text-white flex items-center justify-center shadow-[0_6px_16px_rgba(0,0,0,0.16)]">
              <Dna className="w-5 h-5 text-[#34C759]" />
            </div>
            <div>
              <h1 className="text-[22px] sm:text-[25px] font-semibold tracking-[-0.025em] text-[#1D1D1F] leading-tight">
                EvoLab
              </h1>
              <p className="text-[13px] text-[#86868B] leading-snug">
                Skeletal mechanics &amp; neural locomotion studio
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenNeuralDashboard}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-full text-[12.5px] font-medium bg-[#007AFF]/10 hover:bg-[#007AFF]/16 text-[#007AFF] transition-all active:scale-[0.97] cursor-pointer"
              title="Open Neural Network Inspector (D)"
            >
              <Cpu className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Neural</span>
            </button>

            <button
              type="button"
              onClick={() => setShowLeaderboard((v) => !v)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full text-[12.5px] font-medium transition-all active:scale-[0.97] cursor-pointer ${
                showLeaderboard
                  ? 'bg-[#1D1D1F] text-white shadow-xs'
                  : 'bg-black/[0.045] hover:bg-black/[0.08] text-[#1D1D1F]'
              }`}
              title="Local Records"
            >
              <Trophy className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Records</span>
            </button>

            <button
              type="button"
              onClick={onToggleMute}
              className="w-9 h-9 rounded-full bg-black/[0.045] hover:bg-black/[0.08] text-[#1D1D1F] flex items-center justify-center transition-all active:scale-[0.95] cursor-pointer"
              title={muted ? 'Unmute Audio' : 'Mute Audio'}
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {showLeaderboard ? (
          <div className="mb-7 rounded-[22px] bg-black/[0.03] border border-black/[0.05] p-5">
            <div className="flex items-center justify-between mb-3.5">
              <span className="text-[13px] font-semibold text-[#1D1D1F]">
                Hall of Records
              </span>
              <button
                type="button"
                onClick={() => setShowLeaderboard(false)}
                className="text-[12px] font-medium text-[#007AFF] hover:opacity-80 cursor-pointer"
              >
                Done
              </button>
            </div>
            <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
              {highScores.slice(0, 8).map((entry, idx) => (
                <div
                  key={entry.id}
                  className="flex items-center justify-between text-[13px] py-2.5 px-3.5 rounded-2xl bg-white/90 border border-black/[0.04] shadow-[0_1px_2px_rgba(0,0,0,0.02)]"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span
                      className={`font-mono text-xs font-semibold w-5 text-center ${
                        idx === 0
                          ? 'text-[#FF9500]'
                          : idx === 1
                          ? 'text-[#86868B]'
                          : idx === 2
                          ? 'text-[#A2845E]'
                          : 'text-black/30'
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <span className="font-medium text-[#1D1D1F] truncate">
                      {entry.creatureName}
                    </span>
                    <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-black/[0.045] text-[#86868B] capitalize">
                      {entry.mapId}
                    </span>
                  </div>
                  <div className="flex items-center gap-3.5 shrink-0 font-mono text-xs">
                    <span className="text-[#86868B]">{entry.distanceM.toFixed(1)} m</span>
                    <span className="font-semibold text-[#1D1D1F]">
                      {entry.score.toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <>
            {/* Section 1: Environment Track */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2.5 px-0.5">
                <span className="text-[12px] font-medium text-[#86868B]">
                  Environment
                </span>
                <span className="text-[12px] text-[#86868B]">
                  Goal &amp; Score Multiplier
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {MAP_LIST.map((m) => {
                  const active = selectedMap === m.id;
                  const bestM = getBestForMap(m.id);
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => onSelectMap(m.id)}
                      className={`text-left p-4 rounded-[20px] transition-all duration-150 cursor-pointer relative ${
                        active
                          ? 'bg-white ring-2 ring-[#007AFF] shadow-[0_10px_28px_-6px_rgba(0,122,255,0.18)]'
                          : 'bg-white/60 hover:bg-white/90 border border-black/[0.06]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span
                          className="text-[11px] font-semibold px-2 py-0.5 rounded-full"
                          style={{
                            backgroundColor: `${m.accentColor}18`,
                            color: m.accentColor,
                          }}
                        >
                          {m.scoreMultiplier.toFixed(2)}×
                        </span>
                        <span className="font-mono text-[11px] text-[#86868B]">
                          {m.targetMeters} m
                        </span>
                      </div>

                      <div className="font-semibold text-[14.5px] text-[#1D1D1F] mb-2">
                        {m.name}
                      </div>

                      {/* Clean Minimal Elevation Profile */}
                      <svg
                        viewBox="0 0 120 24"
                        className="w-full h-5 mb-2 overflow-visible"
                      >
                        {m.id === 'flat' && (
                          <path
                            d="M 0 19 L 65 19 Q 85 15 100 19 T 120 18"
                            fill="none"
                            stroke={m.accentColor}
                            strokeWidth="2.2"
                            strokeLinecap="round"
                          />
                        )}
                        {m.id === 'dunes' && (
                          <path
                            d="M 0 20 Q 22 6 44 17 T 88 12 T 120 8"
                            fill="none"
                            stroke={m.accentColor}
                            strokeWidth="2.2"
                            strokeLinecap="round"
                          />
                        )}
                        {m.id === 'steps' && (
                          <path
                            d="M 0 21 L 26 21 L 30 13 L 58 13 L 62 19 L 86 19 L 90 7 L 120 7"
                            fill="none"
                            stroke={m.accentColor}
                            strokeWidth="2.2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        )}
                      </svg>

                      <div className="text-[11.5px] text-[#86868B] flex items-center justify-between">
                        <span>Best</span>
                        <span className="font-mono font-medium text-[#1D1D1F]">
                          {bestM.toFixed(1)} m
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Section 2: Apple Segmented Morphology Selector */}
            <div className="mb-7">
              <div className="flex items-center justify-between mb-2.5 px-0.5">
                <span className="text-[12px] font-medium text-[#86868B]">
                  Starter Morphology
                </span>
              </div>

              <div className="apple-segment-track rounded-2xl flex flex-wrap sm:flex-nowrap gap-1">
                {CREATURE_PRESETS.map((preset, idx) => {
                  const active = selectedPresetIndex === idx;
                  return (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => onSelectPreset(idx)}
                      className={`flex-1 py-2 px-3 rounded-[13px] text-[12.5px] font-medium transition-all cursor-pointer whitespace-nowrap ${
                        active
                          ? 'apple-segment-active font-semibold'
                          : 'text-[#6E6E73] hover:text-[#1D1D1F]'
                      }`}
                    >
                      {preset.name}
                    </button>
                  );
                })}
                <button
                  type="button"
                  onClick={() => onSelectPreset(-1)}
                  className={`flex-1 py-2 px-3 rounded-[13px] text-[12.5px] font-medium transition-all cursor-pointer whitespace-nowrap ${
                    selectedPresetIndex === -1
                      ? 'apple-segment-active font-semibold'
                      : 'text-[#6E6E73] hover:text-[#1D1D1F]'
                  }`}
                >
                  Blank
                </button>
              </div>
            </div>
          </>
        )}

        {/* Dual Pill Action Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            type="button"
            onClick={onStartBuild}
            className="flex items-center justify-center gap-2 py-3.5 px-5 rounded-full bg-black/[0.055] hover:bg-black/[0.09] active:scale-[0.98] text-[#1D1D1F] font-semibold text-[14px] transition-all cursor-pointer"
          >
            <SlidersHorizontal className="w-4 h-4 text-[#1D1D1F]" />
            <span>Open Creature Studio</span>
          </button>

          <button
            type="button"
            onClick={onQuickEvolve}
            className="flex items-center justify-center gap-2 py-3.5 px-5 rounded-full bg-[#007AFF] hover:bg-[#0066D6] active:scale-[0.98] text-white font-semibold text-[14px] transition-all cursor-pointer shadow-[0_8px_22px_-4px_rgba(0,122,255,0.45)]"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Start Evolution</span>
          </button>
        </div>
      </div>
    </div>
  );
};
