import React, { useState } from 'react';
import {
  Activity,
  Bone,
  Cpu,
  Eraser,
  Home,
  Move,
  Play,
  Sparkles,
  Trash2,
  Trophy,
  Undo2,
  Volume2,
  VolumeX,
  Layers,
} from 'lucide-react';
import { CreatureBlueprint, EditorTool, MapId } from '../types/simulation';
import { MAP_LIST } from '../simulation/terrain';
import { CREATURE_PRESETS } from '../simulation/presets';

interface EditorToolbarProps {
  tool: EditorTool;
  onSelectTool: (tool: EditorTool) => void;
  blueprint: CreatureBlueprint;
  mapId: MapId;
  onSelectMap: (map: MapId) => void;
  canUndo: boolean;
  onUndo: () => void;
  onClear: () => void;
  onAutoMuscle: () => void;
  onLoadPreset: (idx: number) => void;
  onStartEvolution: () => void;
  onOpenHome: () => void;
  onOpenLeaderboard: () => void;
  onOpenNeuralDashboard: () => void;
  muted: boolean;
  onToggleMute: () => void;
}

export const EditorToolbar: React.FC<EditorToolbarProps> = ({
  tool,
  onSelectTool,
  blueprint,
  mapId,
  onSelectMap,
  canUndo,
  onUndo,
  onClear,
  onAutoMuscle,
  onLoadPreset,
  onStartEvolution,
  onOpenHome,
  onOpenLeaderboard,
  onOpenNeuralDashboard,
  muted,
  onToggleMute,
}) => {
  const [presetsOpen, setPresetsOpen] = useState(false);

  const bonesCount = blueprint.edges.filter((e) => e.kind === 'bone').length;
  const musclesCount = blueprint.edges.filter((e) => e.kind === 'muscle').length;
  const jointsCount = blueprint.joints.length;

  const toolItems: {
    id: EditorTool;
    label: string;
    shortcut: string;
    icon: React.ReactNode;
    dotColor?: string;
  }[] = [
    {
      id: 'bone',
      label: 'Bone',
      shortcut: '1',
      icon: <Bone className="w-3.5 h-3.5" />,
    },
    {
      id: 'muscle',
      label: 'Muscle',
      shortcut: '2',
      icon: <Activity className="w-3.5 h-3.5 text-[#FF3B30]" />,
    },
    {
      id: 'move',
      label: 'Move',
      shortcut: '3',
      icon: <Move className="w-3.5 h-3.5 text-[#007AFF]" />,
    },
    {
      id: 'erase',
      label: 'Erase',
      shortcut: '4',
      icon: <Eraser className="w-3.5 h-3.5 text-[#FF3B30]" />,
    },
  ];

  return (
    <>
      {/* Clean Top Floating Header */}
      <div className="fixed top-4 left-4 right-4 z-20 flex flex-wrap items-center justify-between gap-2.5 pointer-events-none">
        {/* Left Capsule: Home + Segmented Map Selector */}
        <div className="pointer-events-auto flex items-center gap-2 apple-glass rounded-full p-1.5">
          <button
            type="button"
            onClick={onOpenHome}
            className="w-8 h-8 rounded-full hover:bg-black/[0.06] text-[#1D1D1F] flex items-center justify-center transition cursor-pointer"
            title="Start Menu"
          >
            <Home className="w-4 h-4" />
          </button>

          <div className="apple-segment-track rounded-full flex items-center">
            {MAP_LIST.map((m) => {
              const active = m.id === mapId;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onSelectMap(m.id)}
                  className={`px-3 py-1 rounded-full text-[12px] font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                    active
                      ? 'apple-segment-active font-semibold'
                      : 'text-[#6E6E73] hover:text-[#1D1D1F]'
                  }`}
                >
                  <span
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: m.accentColor }}
                  />
                  <span className="hidden md:inline">{m.name}</span>
                  <span className="md:hidden capitalize">{m.id}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Capsule: Anatomy Summary + Presets + Neural Inspector + Audio */}
        <div className="pointer-events-auto flex items-center gap-1.5 apple-glass rounded-full px-3 py-1.5">
          <div className="hidden sm:flex items-center gap-2.5 text-[12px] text-[#6E6E73] px-1">
            <span>
              <strong className="font-semibold text-[#1D1D1F] tabular-nums">{jointsCount}</strong> Joints
            </span>
            <span className="text-black/15">·</span>
            <span>
              <strong className="font-semibold text-[#1D1D1F] tabular-nums">{bonesCount}</strong> Bones
            </span>
            <span className="text-black/15">·</span>
            <span className={musclesCount === 0 ? 'text-[#FF3B30]' : ''}>
              <strong className="font-semibold text-[#FF3B30] tabular-nums">{musclesCount}</strong> Muscles
            </span>
          </div>

          <div className="hidden sm:block h-4 w-px bg-black/[0.08] mx-1" />

          {/* Presets Popover */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setPresetsOpen((v) => !v)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/[0.045] hover:bg-black/[0.08] text-[#1D1D1F] text-[12px] font-medium transition cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Presets</span>
            </button>

            {presetsOpen && (
              <div className="absolute right-0 mt-2.5 w-48 rounded-[20px] apple-sheet p-1.5 z-40">
                {CREATURE_PRESETS.map((p, idx) => (
                  <button
                    key={p.name}
                    type="button"
                    onClick={() => {
                      onLoadPreset(idx);
                      setPresetsOpen(false);
                    }}
                    className="w-full text-left px-3.5 py-2 rounded-[14px] text-[12.5px] font-medium text-[#1D1D1F] hover:bg-black/[0.05] transition cursor-pointer flex items-center justify-between"
                  >
                    <span>{p.name}</span>
                    <span className="font-mono text-[11px] text-[#86868B]">
                      {p.edges.filter((e) => e.kind === 'muscle').length}M
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={onOpenNeuralDashboard}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#007AFF]/12 hover:bg-[#007AFF]/20 text-[#007AFF] text-[12px] font-semibold transition cursor-pointer"
            title="Open Neural Network Dashboard (D)"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Neural</span>
          </button>

          <button
            type="button"
            onClick={onOpenLeaderboard}
            className="w-8 h-8 rounded-full hover:bg-black/[0.06] text-[#1D1D1F] flex items-center justify-center transition cursor-pointer"
            title="Records"
          >
            <Trophy className="w-4 h-4 text-[#FF9500]" />
          </button>

          <button
            type="button"
            onClick={onToggleMute}
            className="w-8 h-8 rounded-full hover:bg-black/[0.06] text-[#1D1D1F] flex items-center justify-center transition cursor-pointer"
            title={muted ? 'Unmute' : 'Mute'}
          >
            {muted ? <VolumeX className="w-4 h-4 text-[#86868B]" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Subtle Floating Tool Hint Pill */}
      <div className="fixed bottom-[86px] left-1/2 -translate-x-1/2 z-10 pointer-events-none hidden sm:block">
        <div className="px-4 py-1.5 rounded-full apple-glass text-[12px] font-medium text-[#6E6E73] whitespace-nowrap">
          {tool === 'bone' && 'Drag between joints or grid to build rigid bones · Right-click to erase'}
          {tool === 'muscle' && 'Drag between two joints to connect contracting muscle fibers'}
          {tool === 'move' && 'Drag any joint to adjust limb proportions · Drag empty space to pan'}
          {tool === 'erase' && 'Click or swipe across any joint, bone, or muscle to remove'}
        </div>
      </div>

      {/* Bottom Floating Apple Tool Dock */}
      <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-20 w-[calc(100%-1.5rem)] max-w-[660px] pointer-events-none">
        <div className="pointer-events-auto flex flex-wrap sm:flex-nowrap items-center justify-between gap-2 apple-glass rounded-[28px] sm:rounded-full p-2">
          {/* Segmented Drawing Tool Strip */}
          <div className="apple-segment-track rounded-full flex items-center gap-0.5 overflow-x-auto">
            {toolItems.map((item) => {
              const isSelected = tool === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectTool(item.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full text-[12.5px] font-medium transition-all cursor-pointer shrink-0 ${
                    isSelected
                      ? 'apple-segment-active font-semibold'
                      : 'text-[#6E6E73] hover:text-[#1D1D1F]'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Secondary Actions */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onAutoMuscle}
              className="flex items-center gap-1.5 px-3 py-2 rounded-full text-[12px] font-medium bg-[#FF3B30]/10 hover:bg-[#FF3B30]/16 text-[#FF3B30] transition cursor-pointer"
              title="Automatically rig muscles across hinged bones"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Auto-Rig</span>
            </button>

            <button
              type="button"
              onClick={onUndo}
              disabled={!canUndo}
              className="w-9 h-9 rounded-full text-[#1D1D1F] hover:bg-black/[0.06] disabled:opacity-30 flex items-center justify-center transition cursor-pointer"
              title="Undo (Ctrl+Z)"
            >
              <Undo2 className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onClear}
              className="w-9 h-9 rounded-full text-[#1D1D1F] hover:bg-[#FF3B30]/10 hover:text-[#FF3B30] flex items-center justify-center transition cursor-pointer"
              title="Clear Canvas"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>

          {/* Primary Evolve Pill Button */}
          <button
            type="button"
            onClick={onStartEvolution}
            disabled={jointsCount < 2}
            className="flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-full bg-[#007AFF] hover:bg-[#0066D6] disabled:opacity-35 active:scale-[0.97] text-white font-semibold text-[13px] transition-all cursor-pointer shadow-[0_6px_18px_-3px_rgba(0,122,255,0.45)] ml-auto sm:ml-0"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Evolve</span>
          </button>
        </div>
      </div>
    </>
  );
};
