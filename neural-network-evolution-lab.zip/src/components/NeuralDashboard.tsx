import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  BookOpen,
  Check,
  Copy,
  Cpu,
  Grid,
  Pause,
  Play,
  RefreshCw,
  SkipForward,
  Sliders,
  Sparkles,
  X,
} from 'lucide-react';
import { CreatureInstance, MapId, NeuralGenome } from '../types/simulation';
import {
  HIDDEN_SIZE,
  INPUT_LABELS,
  INPUT_SIZE,
  INPUT_SPECS,
} from '../simulation/neuralNet';
import { drawRuntimeCreature } from '../simulation/renderer';
import { MAP_CONFIGS } from '../simulation/terrain';

type DashboardTab = 'topology' | 'oscilloscope' | 'matrices' | 'guide';

interface SelectedNode {
  layer: 'input' | 'hidden' | 'output';
  index: number;
}

interface NeuralDashboardProps {
  populationRef: React.MutableRefObject<{
    population: CreatureInstance[];
    leaderIdx: number;
    generation: number;
    simTime: number;
    mapId: MapId;
  }>;
  isPaused: boolean;
  onTogglePause: () => void;
  onStepSingleFrame: () => void;
  onMutateCreatureLive: (creatureIdx: number, sigma: number) => void;
  onClose: () => void;
}

const MUSCLE_PALETTE = [
  '#FF3B30', // M0 Coral Red
  '#007AFF', // M1 System Blue
  '#FF9500', // M2 Warm Amber
  '#AF52DE', // M3 Purple
  '#34C759', // M4 Mint Green
  '#FF2D55', // M5 Pink
];

function weightColorBg(val: number): string {
  const clamped = Math.max(-2.5, Math.min(2.5, val));
  const norm = Math.abs(clamped) / 2.5;
  if (Math.abs(clamped) < 0.05) return 'rgba(0, 0, 0, 0.03)';
  if (clamped > 0) {
    return `rgba(0, 122, 255, ${(0.09 + norm * 0.55).toFixed(2)})`;
  }
  return `rgba(255, 59, 48, ${(0.09 + norm * 0.55).toFixed(2)})`;
}

export const NeuralDashboard: React.FC<NeuralDashboardProps> = ({
  populationRef,
  isPaused,
  onTogglePause,
  onStepSingleFrame,
  onMutateCreatureLive,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<DashboardTab>('topology');
  const [lockedCreatureIdx, setLockedCreatureIdx] = useState<number | 'leader'>('leader');
  const [selectedNode, setSelectedNode] = useState<SelectedNode>({
    layer: 'output',
    index: 0,
  });
  const [selectedWeightCell, setSelectedWeightCell] = useState<{
    matrix: 'w1' | 'w2';
    row: number;
    col: number;
  } | null>(null);
  const [copiedJson, setCopiedJson] = useState(false);

  const [renderTick, setRenderTick] = useState(0);

  const stageCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const oscCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const phaseCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const resolveCreature = (): CreatureInstance | undefined => {
    const { population, leaderIdx } = populationRef.current;
    if (population.length === 0) return undefined;
    if (lockedCreatureIdx === 'leader') {
      return population[leaderIdx] ?? population[0];
    }
    return population[lockedCreatureIdx] ?? population[0];
  };

  const activeCreature = resolveCreature();
  const numMuscles = Math.max(1, activeCreature?.muscleIndices.length ?? 1);

  useEffect(() => {
    if (selectedNode.layer === 'output' && selectedNode.index >= numMuscles) {
      setSelectedNode({ layer: 'output', index: 0 });
    }
  }, [numMuscles, selectedNode]);

  useEffect(() => {
    let raf = 0;
    let frameCounter = 0;

    const drawLoop = () => {
      raf = requestAnimationFrame(drawLoop);
      frameCounter++;
      if (frameCounter % 2 === 0) {
        setRenderTick((t) => (t + 1) % 100000);
      }

      const creature = resolveCreature();
      if (!creature) return;

      // 1. Live Creature Stage Canvas
      const stageCanvas = stageCanvasRef.current;
      if (stageCanvas) {
        const ctx = stageCanvas.getContext('2d');
        if (ctx) {
          const dpr = Math.min(2, window.devicePixelRatio || 1);
          const rect = stageCanvas.getBoundingClientRect();
          if (
            rect.width > 0 &&
            (stageCanvas.width !== Math.round(rect.width * dpr) ||
              stageCanvas.height !== Math.round(rect.height * dpr))
          ) {
            stageCanvas.width = Math.round(rect.width * dpr);
            stageCanvas.height = Math.round(rect.height * dpr);
          }

          const w = rect.width || 300;
          const h = rect.height || 200;

          ctx.save();
          ctx.scale(dpr, dpr);
          ctx.fillStyle = '#F5F5F7';
          ctx.fillRect(0, 0, w, h);

          ctx.strokeStyle = 'rgba(0, 0, 0, 0.04)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          for (let gx = 0; gx <= w; gx += 24) {
            ctx.moveTo(gx, 0);
            ctx.lineTo(gx, h);
          }
          for (let gy = 0; gy <= h; gy += 24) {
            ctx.moveTo(0, gy);
            ctx.lineTo(w, gy);
          }
          ctx.stroke();

          if (creature.joints.length > 0) {
            let minX = Infinity;
            let maxX = -Infinity;
            let minY = Infinity;
            let maxY = -Infinity;
            for (const j of creature.joints) {
              if (j.x < minX) minX = j.x;
              if (j.x > maxX) maxX = j.x;
              if (j.y < minY) minY = j.y;
              if (j.y > maxY) maxY = j.y;
            }
            const spanX = Math.max(120, maxX - minX + 70);
            const spanY = Math.max(110, maxY - minY + 70);
            const zoom = Math.min(1.35, Math.min(w / spanX, h / spanY));
            const cx = (minX + maxX) * 0.5;
            const cy = (minY + maxY) * 0.5;

            ctx.translate(w * 0.5, h * 0.54);
            ctx.scale(zoom, zoom);
            ctx.translate(-cx, -cy);

            drawRuntimeCreature(
              ctx,
              creature,
              populationRef.current.mapId,
              true,
              false
            );

            creature.muscleIndices.forEach((edgeIdx, mIdx) => {
              const edge = creature.edges[edgeIdx];
              if (!edge) return;
              const ja = creature.joints[edge.aIdx];
              const jb = creature.joints[edge.bIdx];
              const mx = (ja.x + jb.x) * 0.5;
              const my = (ja.y + jb.y) * 0.5;
              const isSelectedMuscle =
                selectedNode.layer === 'output' && selectedNode.index === mIdx;

              if (isSelectedMuscle) {
                ctx.save();
                ctx.strokeStyle = '#FF9500';
                ctx.lineWidth = 4;
                ctx.setLineDash([4, 3]);
                ctx.beginPath();
                ctx.moveTo(ja.x, ja.y);
                ctx.lineTo(jb.x, jb.y);
                ctx.stroke();
                ctx.restore();
              }

              const badgeColor =
                MUSCLE_PALETTE[mIdx % MUSCLE_PALETTE.length];
              ctx.fillStyle = isSelectedMuscle ? '#1D1D1F' : badgeColor;
              ctx.beginPath();
              ctx.roundRect(mx - 13, my - 9, 26, 18, 9);
              ctx.fill();
              if (isSelectedMuscle) {
                ctx.strokeStyle = '#FF9500';
                ctx.lineWidth = 1.8;
                ctx.stroke();
              }

              ctx.fillStyle = '#FFFFFF';
              ctx.font = '600 9px -apple-system, BlinkMacSystemFont, "Inter", sans-serif';
              ctx.textAlign = 'center';
              ctx.fillText(`M${mIdx}`, mx, my + 3);
            });
          }

          ctx.restore();
        }
      }

      // 2. Multi-Channel Oscilloscope
      const oscCanvas = oscCanvasRef.current;
      if (oscCanvas && activeTab === 'oscilloscope') {
        const ctx = oscCanvas.getContext('2d');
        if (ctx) {
          const dpr = Math.min(2, window.devicePixelRatio || 1);
          const rect = oscCanvas.getBoundingClientRect();
          if (
            rect.width > 0 &&
            (oscCanvas.width !== Math.round(rect.width * dpr) ||
              oscCanvas.height !== Math.round(rect.height * dpr))
          ) {
            oscCanvas.width = Math.round(rect.width * dpr);
            oscCanvas.height = Math.round(rect.height * dpr);
          }

          const w = rect.width || 520;
          const h = rect.height || 240;

          ctx.save();
          ctx.scale(dpr, dpr);
          ctx.fillStyle = '#161618';
          ctx.fillRect(0, 0, w, h);

          const padL = 46;
          const padR = 16;
          const padT = 22;
          const padB = 22;
          const plotW = w - padL - padR;
          const plotH = h - padT - padB;
          const midY = padT + plotH * 0.5;

          ctx.strokeStyle = 'rgba(255, 255, 255, 0.09)';
          ctx.lineWidth = 1;
          [0, 0.25, 0.5, 0.75, 1].forEach((frac) => {
            const y = padT + plotH * frac;
            ctx.beginPath();
            ctx.moveTo(padL, y);
            ctx.lineTo(w - padR, y);
            ctx.stroke();
          });

          ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
          ctx.font = '500 9.5px "JetBrains Mono", monospace';
          ctx.textAlign = 'right';
          ctx.fillText('+1.0', padL - 8, padT + 4);
          ctx.fillText('0.0', padL - 8, midY + 3);
          ctx.fillText('-1.0', padL - 8, padT + plotH + 3);

          const samples = creature.telemetry;
          if (samples.length > 1) {
            const maxSamples = 150;
            const xForIdx = (idx: number) =>
              padL + (idx / (maxSamples - 1)) * plotW;
            const yForVal = (v: number) =>
              midY - Math.max(-1, Math.min(1, v)) * (plotH * 0.46);

            ctx.save();
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.28)';
            ctx.setLineDash([4, 4]);
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            samples.forEach((s, i) => {
              const x = xForIdx(i);
              const y = yForVal(s.sinClock);
              if (i === 0) ctx.moveTo(x, y);
              else ctx.lineTo(x, y);
            });
            ctx.stroke();
            ctx.restore();

            const mCount = Math.min(
              6,
              samples[samples.length - 1].muscles.length
            );
            for (let m = 0; m < mCount; m++) {
              ctx.strokeStyle = MUSCLE_PALETTE[m % MUSCLE_PALETTE.length];
              ctx.lineWidth = 2.1;
              ctx.beginPath();
              samples.forEach((s, i) => {
                const val = s.muscles[m] ?? 0;
                const x = xForIdx(i);
                const y = yForVal(val);
                if (i === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
              });
              ctx.stroke();
            }
          }

          ctx.restore();
        }
      }

      // 3. 2D Phase-Space Limit Cycle
      const phaseCanvas = phaseCanvasRef.current;
      if (phaseCanvas && activeTab === 'oscilloscope') {
        const ctx = phaseCanvas.getContext('2d');
        if (ctx) {
          const dpr = Math.min(2, window.devicePixelRatio || 1);
          const rect = phaseCanvas.getBoundingClientRect();
          if (
            rect.width > 0 &&
            (phaseCanvas.width !== Math.round(rect.width * dpr) ||
              phaseCanvas.height !== Math.round(rect.height * dpr))
          ) {
            phaseCanvas.width = Math.round(rect.width * dpr);
            phaseCanvas.height = Math.round(rect.height * dpr);
          }

          const w = rect.width || 240;
          const h = rect.height || 240;
          const pad = 26;
          const size = Math.min(w, h) - pad * 2;
          const cx = w * 0.5;
          const cy = h * 0.5;

          ctx.save();
          ctx.scale(dpr, dpr);
          ctx.fillStyle = '#161618';
          ctx.fillRect(0, 0, w, h);

          ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
          ctx.lineWidth = 1;
          ctx.strokeRect(cx - size * 0.5, cy - size * 0.5, size, size);
          ctx.beginPath();
          ctx.moveTo(cx - size * 0.5, cy);
          ctx.lineTo(cx + size * 0.5, cy);
          ctx.moveTo(cx, cy - size * 0.5);
          ctx.lineTo(cx, cy + size * 0.5);
          ctx.stroke();

          ctx.fillStyle = 'rgba(255, 255, 255, 0.55)';
          ctx.font = '500 9.5px -apple-system, BlinkMacSystemFont, "Inter", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('M0 Activation →', cx, h - 8);
          ctx.fillText('↑ M1 Activation', cx, 15);

          const samples = creature.telemetry;
          if (samples.length > 2) {
            for (let i = 1; i < samples.length; i++) {
              const prev = samples[i - 1];
              const curr = samples[i];
              const alpha = i / samples.length;
              const x1 = cx + (prev.muscles[0] ?? 0) * (size * 0.46);
              const y1 = cy - (prev.muscles[1] ?? prev.cosClock) * (size * 0.46);
              const x2 = cx + (curr.muscles[0] ?? 0) * (size * 0.46);
              const y2 = cy - (curr.muscles[1] ?? curr.cosClock) * (size * 0.46);

              ctx.strokeStyle = `rgba(52, 199, 89, ${(alpha * 0.92).toFixed(2)})`;
              ctx.lineWidth = 2.2;
              ctx.beginPath();
              ctx.moveTo(x1, y1);
              ctx.lineTo(x2, y2);
              ctx.stroke();
            }

            const head = samples[samples.length - 1];
            const hx = cx + (head.muscles[0] ?? 0) * (size * 0.46);
            const hy = cy - (head.muscles[1] ?? head.cosClock) * (size * 0.46);
            ctx.fillStyle = '#FF9500';
            ctx.beginPath();
            ctx.arc(hx, hy, 5, 0, Math.PI * 2);
            ctx.fill();
          }

          ctx.restore();
        }
      }
    };

    raf = requestAnimationFrame(drawLoop);
    return () => cancelAnimationFrame(raf);
  }, [activeTab, lockedCreatureIdx, populationRef, selectedNode]);

  void renderTick;

  const genome: NeuralGenome | undefined = activeCreature?.genome;

  const totalParamCount = useMemo(() => {
    if (!genome) return 0;
    return (
      genome.w1.length +
      genome.b1.length +
      genome.w2.length +
      genome.b2.length +
      genome.muscleStrength.length +
      1
    );
  }, [genome]);

  const handleCopyGenomeJson = () => {
    if (!genome) return;
    const exportPayload = {
      architecture: `6 Inputs -> 6 Hidden (tanh) -> ${numMuscles} Muscle Outputs (tanh)`,
      baseFreqHz: Number(genome.baseFreq.toFixed(4)),
      inputLabels: INPUT_LABELS,
      w1_6x6: genome.w1.map((n) => Number(n.toFixed(4))),
      b1_6: genome.b1.map((n) => Number(n.toFixed(4))),
      w2_Mx6: genome.w2.map((n) => Number(n.toFixed(4))),
      b2_M: genome.b2.map((n) => Number(n.toFixed(4))),
      muscleStrength: genome.muscleStrength.map((n) => Number(n.toFixed(4))),
    };
    navigator.clipboard
      ?.writeText(JSON.stringify(exportPayload, null, 2))
      .then(() => {
        setCopiedJson(true);
        setTimeout(() => setCopiedJson(false), 1800);
      })
      .catch(() => {});
  };

  if (!activeCreature || !genome) {
    return null;
  }

  const { population, leaderIdx, generation, simTime, mapId } =
    populationRef.current;

  const svgW = 560;
  const svgH = 300;
  const colX = [95, 285, 475];
  const inNodes = Array.from({ length: INPUT_SIZE }, (_, i) => ({
    x: colX[0],
    y: 44 + i * 43,
    val: activeCreature.lastInputs[i] ?? 0,
    label: INPUT_LABELS[i],
  }));
  const hidNodes = Array.from({ length: HIDDEN_SIZE }, (_, h) => ({
    x: colX[1],
    y: 44 + h * 43,
    val: activeCreature.lastHidden[h] ?? 0,
    raw: activeCreature.lastHiddenRaw[h] ?? 0,
    label: `H${h}`,
  }));
  const displayMuscles = Math.min(6, numMuscles);
  const outStartY = 152 - ((displayMuscles - 1) * 43) / 2;
  const outNodes = Array.from({ length: displayMuscles }, (_, m) => ({
    x: colX[2],
    y: outStartY + m * 43,
    val: activeCreature.lastOutputs[m] ?? 0,
    raw: activeCreature.lastOutputsRaw[m] ?? 0,
    label: `M${m}`,
  }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/25 backdrop-blur-md p-2.5 sm:p-5">
      <div className="w-full max-w-[1140px] h-[91vh] rounded-[28px] bg-[#F5F5F7]/95 backdrop-blur-2xl border border-black/[0.08] shadow-[0_32px_90px_-16px_rgba(0,0,0,0.28)] flex flex-col overflow-hidden">
        {/* Clean Light macOS Window Titlebar */}
        <div className="bg-white/85 backdrop-blur-xl border-b border-black/[0.06] px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-[11px] bg-[#007AFF]/12 text-[#007AFF] flex items-center justify-center">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-[15.5px] font-semibold tracking-[-0.02em] text-[#1D1D1F]">
                  Neural Network Inspector
                </h2>
                <span className="font-mono text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-black/[0.045] text-[#6E6E73]">
                  6 → 6 → {numMuscles} · {totalParamCount} Parameter
                </span>
              </div>
              <p className="text-[12px] text-[#86868B] hidden sm:block">
                Live-Analyse für CPG-Oszillatoren, Sensorik, Matrizen &amp; eigene Implementierung
              </p>
            </div>
          </div>

          {/* Right Toolbar Controls */}
          <div className="flex items-center gap-2 flex-wrap">
            <select
              value={lockedCreatureIdx === 'leader' ? 'leader' : String(lockedCreatureIdx)}
              onChange={(e) => {
                const v = e.target.value;
                setLockedCreatureIdx(v === 'leader' ? 'leader' : Number(v));
              }}
              className="text-[12px] font-medium bg-black/[0.045] hover:bg-black/[0.075] text-[#1D1D1F] rounded-full px-3.5 py-1.5 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#007AFF]"
            >
              <option value="leader">
                #1 Champion ({(population[leaderIdx]?.distanceM ?? 0).toFixed(1)} m)
              </option>
              {population.map((c, idx) => (
                <option key={c.genome.id + idx} value={idx}>
                  Individuum #{idx + 1} {c.genome.isElite ? '★ Elite' : ''} (
                  {c.distanceM.toFixed(1)} m)
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={onTogglePause}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-[12px] font-semibold transition cursor-pointer ${
                isPaused
                  ? 'bg-[#34C759] hover:bg-[#2DB84D] text-white'
                  : 'bg-[#FF9500]/14 hover:bg-[#FF9500]/22 text-[#D97706]'
              }`}
              title="Physik einfrieren / fortsetzen"
            >
              {isPaused ? (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Play</span>
                </>
              ) : (
                <>
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span>Freeze</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onStepSingleFrame}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-black/[0.045] hover:bg-black/[0.08] text-[#1D1D1F] text-[12px] font-mono font-medium transition cursor-pointer"
              title="+1 Physik-Frame (1/60s)"
            >
              <SkipForward className="w-3.5 h-3.5" />
              <span>+1</span>
            </button>

            <button
              type="button"
              onClick={handleCopyGenomeJson}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/[0.045] hover:bg-black/[0.08] text-[#1D1D1F] text-[12px] font-medium transition cursor-pointer"
              title="Genom als JSON kopieren"
            >
              {copiedJson ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#34C759]" />
                  <span className="text-[#34C759] font-semibold">Kopiert</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-[#007AFF]" />
                  <span className="hidden md:inline">JSON</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-black/[0.06] hover:bg-black/[0.12] text-[#1D1D1F] flex items-center justify-center transition cursor-pointer ml-1"
              title="Schließen (D / Esc)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Apple Segmented Sub-Navigation Bar */}
        <div className="bg-white/65 border-b border-black/[0.05] px-5 py-2.5 flex items-center justify-center overflow-x-auto shrink-0">
          <div className="apple-segment-track rounded-full flex items-center gap-1 max-w-full overflow-x-auto">
            {[
              {
                id: 'topology' as const,
                label: 'Topologie & Formeln',
                icon: <Cpu className="w-3.5 h-3.5" />,
              },
              {
                id: 'oscilloscope' as const,
                label: 'Oszilloskop & Phase',
                icon: <Activity className="w-3.5 h-3.5" />,
              },
              {
                id: 'matrices' as const,
                label: 'Gewichtsmatrizen & Labor',
                icon: <Grid className="w-3.5 h-3.5" />,
              },
              {
                id: 'guide' as const,
                label: 'Entwickler-Guide',
                icon: <BookOpen className="w-3.5 h-3.5" />,
              },
            ].map((tab) => {
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[12.5px] font-medium transition-all cursor-pointer shrink-0 ${
                    active
                      ? 'apple-segment-active font-semibold'
                      : 'text-[#6E6E73] hover:text-[#1D1D1F]'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Bento Workspace */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left Sidebar (4 cols): Live Creature Anatomy + Live Sensor Inputs */}
            <div className="lg:col-span-4 space-y-4">
              <div className="rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] overflow-hidden">
                <div className="px-4 py-3 border-b border-black/[0.05] flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-semibold text-[#34C759] block">
                      Live-Anatomie
                    </span>
                    <span className="text-[13px] font-semibold text-[#1D1D1F]">
                      Gen {generation} · {simTime.toFixed(1)}s · {MAP_CONFIGS[mapId].name}
                    </span>
                  </div>
                  <span className="font-mono text-xs font-semibold px-2.5 py-1 rounded-full bg-black/[0.045] text-[#1D1D1F]">
                    {activeCreature.distanceM.toFixed(1)} m
                  </span>
                </div>

                <canvas
                  ref={stageCanvasRef}
                  className="w-full h-48 block bg-[#F5F5F7]"
                />

                <div className="p-3.5 bg-white border-t border-black/[0.05] space-y-2.5">
                  <div className="text-[11.5px] text-[#86868B] flex items-center justify-between">
                    <span>
                      <strong className="text-[#FF3B30] font-semibold">Rot</strong> = Kontraktion (&lt;0)
                    </span>
                    <span>
                      <strong className="text-[#007AFF] font-semibold">Blau</strong> = Streckung (&gt;0)
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {activeCreature.muscleIndices.map((edgeIdx, mIdx) => {
                      const edge = activeCreature.edges[edgeIdx];
                      const act = activeCreature.lastOutputs[mIdx] ?? 0;
                      const isSel =
                        selectedNode.layer === 'output' &&
                        selectedNode.index === mIdx;
                      return (
                        <button
                          key={edgeIdx}
                          type="button"
                          onClick={() => {
                            setSelectedNode({ layer: 'output', index: mIdx });
                            if (activeTab === 'guide') setActiveTab('topology');
                          }}
                          className={`font-mono text-[11px] px-2.5 py-1 rounded-full transition cursor-pointer flex items-center gap-1.5 ${
                            isSel
                              ? 'bg-[#1D1D1F] text-white shadow-xs'
                              : 'bg-black/[0.04] hover:bg-black/[0.08] text-[#1D1D1F]'
                          }`}
                        >
                          <span
                            className="w-2 h-2 rounded-full"
                            style={{
                              backgroundColor:
                                MUSCLE_PALETTE[mIdx % MUSCLE_PALETTE.length],
                            }}
                          />
                          <span>M{mIdx}</span>
                          <span className="font-semibold">
                            {act >= 0 ? '+' : ''}
                            {act.toFixed(2)}
                          </span>
                          {edge && (
                            <span className="text-[10px] opacity-60">
                              {Math.round(edge.currentTarget)}px
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Input Vector Card */}
              <div className="rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[12.5px] font-semibold text-[#1D1D1F]">
                    Input-Signale x ∈ [−1, +1]
                  </span>
                  <span className="font-mono text-[11.5px] font-semibold text-[#007AFF]">
                    {genome.baseFreq.toFixed(2)} Hz
                  </span>
                </div>

                <div className="space-y-2">
                  {INPUT_SPECS.map((spec) => {
                    const val = activeCreature.lastInputs[spec.index] ?? 0;
                    const isSelected =
                      selectedNode.layer === 'input' &&
                      selectedNode.index === spec.index;
                    return (
                      <button
                        key={spec.index}
                        type="button"
                        onClick={() => {
                          setSelectedNode({ layer: 'input', index: spec.index });
                          if (activeTab !== 'topology') setActiveTab('topology');
                        }}
                        className={`w-full text-left px-3 py-2 rounded-2xl transition cursor-pointer ${
                          isSelected
                            ? 'bg-[#007AFF]/10 ring-1 ring-[#007AFF]'
                            : 'bg-[#F5F5F7] hover:bg-black/[0.06]'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[11.5px] mb-1.5">
                          <span className="font-medium text-[#1D1D1F]">
                            <span className="font-mono text-[#86868B] mr-1.5">I{spec.index}</span>
                            {spec.shortLabel}
                          </span>
                          <span
                            className={`font-mono font-semibold ${
                              val >= 0 ? 'text-[#007AFF]' : 'text-[#FF3B30]'
                            }`}
                          >
                            {val >= 0 ? '+' : ''}
                            {val.toFixed(3)}
                          </span>
                        </div>
                        <div className="relative h-1.5 bg-black/[0.08] rounded-full overflow-hidden">
                          <div className="absolute left-1/2 top-0 bottom-0 w-px bg-black/20" />
                          <div
                            className={`absolute top-0 bottom-0 rounded-full transition-all duration-75 ${
                              val >= 0 ? 'bg-[#007AFF]' : 'bg-[#FF3B30]'
                            }`}
                            style={{
                              left: val >= 0 ? '50%' : `${50 + val * 50}%`,
                              width: `${Math.abs(val) * 50}%`,
                            }}
                          />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Right Main Panel (8 cols) */}
            <div className="lg:col-span-8 space-y-5">
              {/* TAB 1: TOPOLOGY & LIVE EQUATION INSPECTOR */}
              {activeTab === 'topology' && (
                <>
                  <div className="rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-5">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                      <div>
                        <h3 className="text-[15px] font-semibold text-[#1D1D1F]">
                          Interaktiver Netzwerk-Graph
                        </h3>
                        <p className="text-[12.5px] text-[#86868B]">
                          Klicke ein beliebiges Neuron an ·{' '}
                          <span className="text-[#007AFF] font-medium">Blau (+)</span> /{' '}
                          <span className="text-[#FF3B30] font-medium">Rot (−)</span>
                        </p>
                      </div>
                      <span className="font-mono text-[11.5px] px-3 py-1 rounded-full bg-[#FF9500]/14 text-[#D97706] font-semibold">
                        Auswahl:{' '}
                        {selectedNode.layer === 'input'
                          ? `I${selectedNode.index} (${INPUT_LABELS[selectedNode.index]})`
                          : selectedNode.layer === 'hidden'
                          ? `Hidden H${selectedNode.index}`
                          : `Muskel M${selectedNode.index}`}
                      </span>
                    </div>

                    <svg
                      viewBox={`0 0 ${svgW} ${svgH}`}
                      className="w-full h-auto max-h-[300px] select-none bg-[#161618] rounded-[18px] p-2.5"
                    >
                      <text
                        x={colX[0]}
                        y={20}
                        fill="rgba(255,255,255,0.48)"
                        fontSize="10"
                        fontFamily="-apple-system, Inter, sans-serif"
                        fontWeight="600"
                        textAnchor="middle"
                      >
                        Inputs (CPG &amp; Sensorik)
                      </text>
                      <text
                        x={colX[1]}
                        y={20}
                        fill="rgba(255,255,255,0.48)"
                        fontSize="10"
                        fontFamily="-apple-system, Inter, sans-serif"
                        fontWeight="600"
                        textAnchor="middle"
                      >
                        Hidden Layer (tanh)
                      </text>
                      <text
                        x={colX[2]}
                        y={20}
                        fill="rgba(255,255,255,0.48)"
                        fontSize="10"
                        fontFamily="-apple-system, Inter, sans-serif"
                        fontWeight="600"
                        textAnchor="middle"
                      >
                        Muskel-Aktoren (tanh)
                      </text>

                      {/* Synapses W1 */}
                      {hidNodes.map((hNode, hIdx) =>
                        inNodes.map((iNode, iIdx) => {
                          const w = genome.w1[hIdx * INPUT_SIZE + iIdx] ?? 0;
                          const prod = w * iNode.val;
                          const isHighlighted =
                            (selectedNode.layer === 'hidden' &&
                              selectedNode.index === hIdx) ||
                            (selectedNode.layer === 'input' &&
                              selectedNode.index === iIdx);
                          const baseAlpha = isHighlighted ? 0.92 : 0.14;
                          const strokeW = isHighlighted
                            ? Math.max(1.2, Math.min(4.2, Math.abs(prod) * 2.6 + 0.9))
                            : Math.max(0.6, Math.min(2.0, Math.abs(prod) * 1.4));
                          return (
                            <line
                              key={`w1_${hIdx}_${iIdx}`}
                              x1={iNode.x + 15}
                              y1={iNode.y}
                              x2={hNode.x - 15}
                              y2={hNode.y}
                              stroke={
                                prod >= 0
                                  ? `rgba(10, 132, 255, ${baseAlpha})`
                                  : `rgba(255, 69, 58, ${baseAlpha})`
                              }
                              strokeWidth={strokeW}
                            />
                          );
                        })
                      )}

                      {/* Synapses W2 */}
                      {outNodes.map((oNode, mIdx) =>
                        hidNodes.map((hNode, hIdx) => {
                          const w = genome.w2[mIdx * HIDDEN_SIZE + hIdx] ?? 0;
                          const prod = w * hNode.val;
                          const isHighlighted =
                            (selectedNode.layer === 'output' &&
                              selectedNode.index === mIdx) ||
                            (selectedNode.layer === 'hidden' &&
                              selectedNode.index === hIdx);
                          const baseAlpha = isHighlighted ? 0.95 : 0.14;
                          const strokeW = isHighlighted
                            ? Math.max(1.3, Math.min(4.5, Math.abs(prod) * 2.8 + 0.9))
                            : Math.max(0.6, Math.min(2.0, Math.abs(prod) * 1.4));
                          return (
                            <line
                              key={`w2_${mIdx}_${hIdx}`}
                              x1={hNode.x + 15}
                              y1={hNode.y}
                              x2={oNode.x - 15}
                              y2={oNode.y}
                              stroke={
                                prod >= 0
                                  ? `rgba(10, 132, 255, ${baseAlpha})`
                                  : `rgba(255, 69, 58, ${baseAlpha})`
                              }
                              strokeWidth={strokeW}
                            />
                          );
                        })
                      )}

                      {/* Input Nodes */}
                      {inNodes.map((node, idx) => {
                        const sel =
                          selectedNode.layer === 'input' &&
                          selectedNode.index === idx;
                        return (
                          <g
                            key={`in_${idx}`}
                            onClick={() =>
                              setSelectedNode({ layer: 'input', index: idx })
                            }
                            className="cursor-pointer"
                          >
                            <text
                              x={node.x - 20}
                              y={node.y + 3.5}
                              fill={sel ? '#FF9F0A' : 'rgba(255,255,255,0.75)'}
                              fontSize="9.5"
                              fontFamily="JetBrains Mono, monospace"
                              fontWeight="600"
                              textAnchor="end"
                            >
                              {node.label}
                            </text>
                            <circle
                              cx={node.x}
                              cy={node.y}
                              r={13.5}
                              fill={
                                node.val >= 0.05
                                  ? '#0A84FF'
                                  : node.val <= -0.05
                                  ? '#FF453A'
                                  : '#2C2C2E'
                              }
                              stroke={sel ? '#FF9F0A' : 'rgba(255,255,255,0.65)'}
                              strokeWidth={sel ? 3 : 1.2}
                            />
                            <text
                              x={node.x}
                              y={node.y + 3.2}
                              fill="#FFFFFF"
                              fontSize="8.5"
                              fontFamily="JetBrains Mono, monospace"
                              fontWeight="700"
                              textAnchor="middle"
                            >
                              {node.val.toFixed(2)}
                            </text>
                          </g>
                        );
                      })}

                      {/* Hidden Nodes */}
                      {hidNodes.map((node, idx) => {
                        const sel =
                          selectedNode.layer === 'hidden' &&
                          selectedNode.index === idx;
                        return (
                          <g
                            key={`hid_${idx}`}
                            onClick={() =>
                              setSelectedNode({ layer: 'hidden', index: idx })
                            }
                            className="cursor-pointer"
                          >
                            <circle
                              cx={node.x}
                              cy={node.y}
                              r={14.5}
                              fill={
                                node.val >= 0.05
                                  ? '#0A84FF'
                                  : node.val <= -0.05
                                  ? '#FF453A'
                                  : '#2C2C2E'
                              }
                              stroke={sel ? '#FF9F0A' : 'rgba(255,255,255,0.5)'}
                              strokeWidth={sel ? 3 : 1.2}
                            />
                            <text
                              x={node.x}
                              y={node.y + 3.2}
                              fill="#FFFFFF"
                              fontSize="8.5"
                              fontFamily="JetBrains Mono, monospace"
                              fontWeight="700"
                              textAnchor="middle"
                            >
                              {node.val.toFixed(2)}
                            </text>
                            <text
                              x={node.x}
                              y={node.y - 18}
                              fill={sel ? '#FF9F0A' : 'rgba(255,255,255,0.45)'}
                              fontSize="8.5"
                              fontFamily="JetBrains Mono, monospace"
                              fontWeight="600"
                              textAnchor="middle"
                            >
                              H{idx}
                            </text>
                          </g>
                        );
                      })}

                      {/* Output Muscle Nodes */}
                      {outNodes.map((node, idx) => {
                        const sel =
                          selectedNode.layer === 'output' &&
                          selectedNode.index === idx;
                        return (
                          <g
                            key={`out_${idx}`}
                            onClick={() =>
                              setSelectedNode({ layer: 'output', index: idx })
                            }
                            className="cursor-pointer"
                          >
                            <circle
                              cx={node.x}
                              cy={node.y}
                              r={15}
                              fill={
                                node.val >= 0.05
                                  ? '#0A84FF'
                                  : node.val <= -0.05
                                  ? '#FF453A'
                                  : '#2C2C2E'
                              }
                              stroke={sel ? '#FF9F0A' : 'rgba(255,255,255,0.7)'}
                              strokeWidth={sel ? 3.2 : 1.4}
                            />
                            <text
                              x={node.x}
                              y={node.y + 3.2}
                              fill="#FFFFFF"
                              fontSize="8.5"
                              fontFamily="JetBrains Mono, monospace"
                              fontWeight="700"
                              textAnchor="middle"
                            >
                              {node.val.toFixed(2)}
                            </text>
                            <text
                              x={node.x + 21}
                              y={node.y + 3.5}
                              fill={
                                sel
                                  ? '#FF9F0A'
                                  : MUSCLE_PALETTE[idx % MUSCLE_PALETTE.length]
                              }
                              fontSize="10"
                              fontFamily="JetBrains Mono, monospace"
                              fontWeight="700"
                              textAnchor="start"
                            >
                              M{idx}
                            </text>
                          </g>
                        );
                      })}
                    </svg>
                  </div>

                  {/* Step-by-Step Mathematical Inspector Card */}
                  <div className="rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-5">
                    {selectedNode.layer === 'input' && (
                      <div>
                        <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                          <span className="text-[13.5px] font-semibold text-[#1D1D1F]">
                            Input I{selectedNode.index}:{' '}
                            {INPUT_SPECS[selectedNode.index]?.titleDe}
                          </span>
                          <span className="font-mono text-xs px-3 py-1 rounded-full bg-[#F5F5F7] text-[#1D1D1F] font-semibold">
                            {INPUT_SPECS[selectedNode.index]?.formula}
                          </span>
                        </div>
                        <p className="text-[13px] text-[#6E6E73] mb-3.5 leading-relaxed">
                          {INPUT_SPECS[selectedNode.index]?.roleDe}
                        </p>
                        <div className="font-mono text-xs bg-[#F5F5F7] text-[#1D1D1F] rounded-2xl p-3.5 border border-black/[0.04]">
                          Aktueller Wert x[{selectedNode.index}] ={' '}
                          <strong className="text-[#007AFF]">
                            {(
                              activeCreature.lastInputs[selectedNode.index] ?? 0
                            ).toFixed(4)}
                          </strong>{' '}
                          → speist alle 6 Hidden-Neuronen H0..H5.
                        </div>
                      </div>
                    )}

                    {selectedNode.layer === 'hidden' && (() => {
                      const hIdx = selectedNode.index;
                      const bias = genome.b1[hIdx] ?? 0;
                      const zVal = activeCreature.lastHiddenRaw[hIdx] ?? 0;
                      const aVal = activeCreature.lastHidden[hIdx] ?? 0;
                      return (
                        <div>
                          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                            <span className="text-[13.5px] font-semibold text-[#1D1D1F]">
                              Hidden-Neuron H{hIdx} · Live Vorwärts-Berechnung
                            </span>
                            <span className="font-mono text-xs font-semibold text-[#6E6E73]">
                              tanh({zVal.toFixed(3)}) ={' '}
                              <span className="text-[#34C759] font-bold">
                                {aVal.toFixed(3)}
                              </span>
                            </span>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-3.5">
                            {INPUT_LABELS.map((lbl, iIdx) => {
                              const w = genome.w1[hIdx * INPUT_SIZE + iIdx] ?? 0;
                              const x = activeCreature.lastInputs[iIdx] ?? 0;
                              const prod = w * x;
                              return (
                                <div
                                  key={lbl}
                                  className="p-2.5 rounded-2xl bg-[#F5F5F7] font-mono text-[11px]"
                                >
                                  <div className="text-[#86868B] text-[10px] mb-0.5">
                                    {lbl}
                                  </div>
                                  <div className="text-[#1D1D1F] font-medium">
                                    {w.toFixed(2)} × {x.toFixed(2)} ={' '}
                                    <strong
                                      className={
                                        prod >= 0
                                          ? 'text-[#007AFF]'
                                          : 'text-[#FF3B30]'
                                      }
                                    >
                                      {prod >= 0 ? '+' : ''}
                                      {prod.toFixed(2)}
                                    </strong>
                                  </div>
                                </div>
                              );
                            })}
                          </div>

                          <div className="font-mono text-xs bg-[#1D1D1F] text-white rounded-2xl p-3.5">
                            z₁[{hIdx}] = Bias ({bias.toFixed(2)}) + Σ(w · x) ={' '}
                            <strong className="text-[#FF9F0A]">
                              {zVal.toFixed(3)}
                            </strong>{' '}
                            ⇒ tanh({zVal.toFixed(3)}) ={' '}
                            <strong className="text-[#30D158]">
                              {aVal.toFixed(4)}
                            </strong>
                          </div>
                        </div>
                      );
                    })()}

                    {selectedNode.layer === 'output' && (() => {
                      const mIdx = selectedNode.index;
                      const bias = genome.b2[mIdx] ?? 0;
                      const zVal = activeCreature.lastOutputsRaw[mIdx] ?? 0;
                      const aVal = activeCreature.lastOutputs[mIdx] ?? 0;
                      const strength = genome.muscleStrength[mIdx] ?? 0.34;
                      const edgeIdx = activeCreature.muscleIndices[mIdx];
                      const edge =
                        edgeIdx !== undefined
                          ? activeCreature.edges[edgeIdx]
                          : undefined;
                      const restLen = edge?.restLength ?? 60;
                      const desiredLen = restLen * (1 + aVal * strength);

                      return (
                        <div>
                          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                            <span className="text-[13.5px] font-semibold text-[#1D1D1F]">
                              Muskel-Aktor M{mIdx} · Vom Neuron zur Muskelkraft
                            </span>
                            <span className="font-mono text-xs px-3 py-1 rounded-full bg-[#F5F5F7] text-[#1D1D1F] font-semibold">
                              Max. Hub ±{Math.round(strength * 100)}%
                            </span>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-3.5">
                            {Array.from({ length: HIDDEN_SIZE }, (_, hIdx) => {
                              const w = genome.w2[mIdx * HIDDEN_SIZE + hIdx] ?? 0;
                              const hVal = activeCreature.lastHidden[hIdx] ?? 0;
                              const prod = w * hVal;
                              return (
                                <div
                                  key={hIdx}
                                  className="p-2.5 rounded-2xl bg-[#F5F5F7] font-mono text-[11px]"
                                >
                                  <div className="text-[#86868B] text-[10px] mb-0.5">
                                    Hidden H{hIdx}
                                  </div>
                                  <div className="text-[#1D1D1F] font-medium">
                                    {w.toFixed(2)} × {hVal.toFixed(2)} ={' '}
                                    <strong
                                      className={
                                        prod >= 0
                                          ? 'text-[#007AFF]'
                                          : 'text-[#FF3B30]'
                                      }
                                    >
                                      {prod >= 0 ? '+' : ''}
                                      {prod.toFixed(2)}
                                    </strong>
                                  </div>
                                </div>
                              );
                            })}
                          </div>

                          <div className="font-mono text-[11.5px] bg-[#1D1D1F] text-white/90 rounded-2xl p-4 space-y-1.5">
                            <div>
                              1. Summe: z₂ = {bias.toFixed(2)} (Bias) + Σ(w₂·h) ={' '}
                              <strong className="text-[#FF9F0A]">
                                {zVal.toFixed(3)}
                              </strong>
                            </div>
                            <div>
                              2. Aktivierung: a = tanh({zVal.toFixed(3)}) ={' '}
                              <strong
                                className={
                                  aVal < 0 ? 'text-[#FF453A]' : 'text-[#0A84FF]'
                                }
                              >
                                {aVal >= 0 ? '+' : ''}
                                {aVal.toFixed(3)} (
                                {aVal < -0.05
                                  ? 'Kontraktion'
                                  : aVal > 0.05
                                  ? 'Streckung'
                                  : 'Neutral'}
                                )
                              </strong>
                            </div>
                            <div>
                              3. Ziel-Länge: L_soll = {restLen.toFixed(1)}px × (1 +{' '}
                              {aVal.toFixed(2)} × {strength.toFixed(2)}) ={' '}
                              <strong className="text-[#30D158]">
                                {desiredLen.toFixed(1)}px
                              </strong>{' '}
                              (geglättet: {(edge?.currentTarget ?? desiredLen).toFixed(1)}px)
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                </>
              )}

              {/* TAB 2: OSCILLOSCOPE & PHASE PORTRAIT */}
              {activeTab === 'oscilloscope' && (
                <div className="space-y-5">
                  <div className="rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-5">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                      <div>
                        <h3 className="text-[15px] font-semibold text-[#1D1D1F]">
                          Mehrkanal-Echtzeit-Oszilloskop
                        </h3>
                        <p className="text-[12.5px] text-[#86868B]">
                          Gestrichelt = CPG-Referenztakt sin(2πft) · Farbig = Muskelkanäle M0..M{displayMuscles - 1}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {Array.from({ length: displayMuscles }, (_, m) => (
                          <span
                            key={m}
                            className="font-mono text-[10.5px] font-semibold px-2.5 py-0.5 rounded-full text-white"
                            style={{
                              backgroundColor:
                                MUSCLE_PALETTE[m % MUSCLE_PALETTE.length],
                            }}
                          >
                            M{m}
                          </span>
                        ))}
                      </div>
                    </div>

                    <canvas
                      ref={oscCanvasRef}
                      className="w-full h-56 rounded-[18px] block bg-[#161618]"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch">
                    <div className="md:col-span-5 rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-5 flex flex-col">
                      <h4 className="text-[13px] font-semibold text-[#1D1D1F] mb-2.5">
                        2D Phasenporträt (M0 vs. M1)
                      </h4>
                      <canvas
                        ref={phaseCanvasRef}
                        className="w-full h-52 rounded-[18px] block bg-[#161618] flex-1"
                      />
                    </div>

                    <div className="md:col-span-7 rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-5 flex flex-col justify-between">
                      <div>
                        <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-[#34C759]/14 text-[#248A3D]">
                          Kernprinzip für deine eigene Engine
                        </span>
                        <h4 className="text-[16px] font-semibold text-[#1D1D1F] mt-2.5 mb-2">
                          Warum Phasenversatz Vorwärtsbewegung erzeugt
                        </h4>
                        <p className="text-[13px] text-[#6E6E73] leading-relaxed mb-3">
                          Speist du nur ein einzelnes Sinussignal <code>sin(2πft)</code> ein, laufen alle Muskeln phasengleich vor und zurück: im Phasenporträt links entsteht lediglich ein <strong>gerader Strich</strong> (die Kreatur rudert auf der Stelle).
                        </p>
                        <p className="text-[13px] text-[#6E6E73] leading-relaxed">
                          Mit <strong>Sinus UND Kosinus</strong> kann das Netz beliebige Phasenwinkel{' '}
                          <code>A·sin(ωt) + B·cos(ωt) = R·sin(ωt + φ)</code> mischen. Dadurch öffnet sich links eine <strong className="text-[#1D1D1F]">echte Schleife (Grenzzyklus)</strong>: M0 hebt das Bein an, während M1 nach vorne schwingt, und drückt erst am Boden wieder ab.
                        </p>
                      </div>

                      <div className="mt-4 p-3 rounded-2xl bg-[#F5F5F7] text-[12px] text-[#6E6E73]">
                        Je weiter die grüne Trajektorie links geöffnet ist, desto klarer sind Schwung- und Abstoßphase getrennt.
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: WEIGHT MATRICES & LIVE SANDBOX */}
              {activeTab === 'matrices' && (
                <div className="space-y-5">
                  <div className="rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-5">
                    <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                      <div className="flex items-center gap-2">
                        <Sliders className="w-4 h-4 text-[#007AFF]" />
                        <h3 className="text-[15px] font-semibold text-[#1D1D1F]">
                          Live-Genom-Labor
                        </h3>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            onMutateCreatureLive(activeCreature.index, 0.25)
                          }
                          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#34C759] hover:bg-[#2DB84D] text-white text-[12px] font-semibold transition cursor-pointer"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Fein-Mutation</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onMutateCreatureLive(activeCreature.index, 0.75)
                          }
                          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#FF9500] hover:bg-[#E68600] text-white text-[12px] font-semibold transition cursor-pointer"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Starke Mutation</span>
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center bg-[#F5F5F7] p-4 rounded-2xl">
                      <div>
                        <div className="flex items-center justify-between text-xs mb-1.5">
                          <span className="font-medium text-[#1D1D1F]">
                            CPG Grundfrequenz (baseFreq)
                          </span>
                          <span className="font-mono font-semibold text-[#007AFF]">
                            {genome.baseFreq.toFixed(2)} Hz
                          </span>
                        </div>
                        <input
                          type="range"
                          min={0.5}
                          max={4.0}
                          step={0.05}
                          value={genome.baseFreq}
                          onChange={(e) => {
                            genome.baseFreq = Number(e.target.value);
                          }}
                          className="w-full accent-[#007AFF] cursor-pointer"
                        />
                      </div>

                      {selectedWeightCell ? (
                        <div>
                          <div className="flex items-center justify-between text-xs mb-1.5">
                            <span className="font-medium text-[#1D1D1F]">
                              Gewicht {selectedWeightCell.matrix.toUpperCase()}[
                              {selectedWeightCell.row}, {selectedWeightCell.col}]
                            </span>
                            <span className="font-mono font-semibold text-[#007AFF]">
                              {(selectedWeightCell.matrix === 'w1'
                                ? genome.w1[
                                    selectedWeightCell.row * INPUT_SIZE +
                                      selectedWeightCell.col
                                  ]
                                : genome.w2[
                                    selectedWeightCell.row * HIDDEN_SIZE +
                                      selectedWeightCell.col
                                  ]
                              ).toFixed(2)}
                            </span>
                          </div>
                          <input
                            type="range"
                            min={-3.5}
                            max={3.5}
                            step={0.05}
                            value={
                              selectedWeightCell.matrix === 'w1'
                                ? genome.w1[
                                    selectedWeightCell.row * INPUT_SIZE +
                                      selectedWeightCell.col
                                  ]
                                : genome.w2[
                                    selectedWeightCell.row * HIDDEN_SIZE +
                                      selectedWeightCell.col
                                  ]
                            }
                            onChange={(e) => {
                              const nextVal = Number(e.target.value);
                              if (selectedWeightCell.matrix === 'w1') {
                                genome.w1[
                                  selectedWeightCell.row * INPUT_SIZE +
                                    selectedWeightCell.col
                                ] = nextVal;
                              } else {
                                genome.w2[
                                  selectedWeightCell.row * HIDDEN_SIZE +
                                    selectedWeightCell.col
                                ] = nextVal;
                              }
                            }}
                            className="w-full accent-[#007AFF] cursor-pointer"
                          />
                        </div>
                      ) : (
                        <div className="text-[12px] text-[#86868B]">
                          Klicke unten auf eine Zelle in Matrix W¹ oder W², um das Gewicht live per Regler zu verändern.
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Matrix W1 */}
                  <div className="rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-5 overflow-x-auto">
                    <h4 className="text-[13px] font-semibold text-[#1D1D1F] mb-3">
                      Matrix W¹ (6 Hidden × 6 Inputs) + Bias b¹
                    </h4>
                    <table className="w-full font-mono text-[11px] border-collapse">
                      <thead>
                        <tr className="text-[#86868B]">
                          <th className="p-1.5 text-left font-medium">Neuron</th>
                          {INPUT_LABELS.map((lbl) => (
                            <th key={lbl} className="p-1.5 text-center font-medium">
                              {lbl}
                            </th>
                          ))}
                          <th className="p-1.5 text-center font-medium text-[#D97706]">
                            Bias b¹
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {Array.from({ length: HIDDEN_SIZE }, (_, r) => (
                          <tr key={r}>
                            <td className="p-1.5 font-semibold text-[#1D1D1F]">
                              H{r}
                            </td>
                            {Array.from({ length: INPUT_SIZE }, (_, c) => {
                              const val = genome.w1[r * INPUT_SIZE + c] ?? 0;
                              const isPicked =
                                selectedWeightCell?.matrix === 'w1' &&
                                selectedWeightCell.row === r &&
                                selectedWeightCell.col === c;
                              return (
                                <td key={c} className="p-1">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setSelectedWeightCell({
                                        matrix: 'w1',
                                        row: r,
                                        col: c,
                                      })
                                    }
                                    style={{
                                      backgroundColor: weightColorBg(val),
                                    }}
                                    className={`w-full py-1.5 px-1 rounded-xl text-center font-semibold text-[#1D1D1F] transition cursor-pointer ${
                                      isPicked
                                        ? 'ring-2 ring-[#007AFF] scale-105'
                                        : 'hover:opacity-80'
                                    }`}
                                  >
                                    {val >= 0 ? '+' : ''}
                                    {val.toFixed(2)}
                                  </button>
                                </td>
                              );
                            })}
                            <td className="p-1 text-center font-semibold text-[#D97706] bg-[#FF9500]/10 rounded-xl">
                              {(genome.b1[r] ?? 0).toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Matrix W2 */}
                  <div className="rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-5 overflow-x-auto">
                    <h4 className="text-[13px] font-semibold text-[#1D1D1F] mb-3">
                      Matrix W² ({numMuscles} Muskeln × 6 Hidden) + Bias b² + Hub α
                    </h4>
                    <table className="w-full font-mono text-[11px] border-collapse">
                      <thead>
                        <tr className="text-[#86868B]">
                          <th className="p-1.5 text-left font-medium">Aktor</th>
                          {Array.from({ length: HIDDEN_SIZE }, (_, h) => (
                            <th key={h} className="p-1.5 text-center font-medium">
                              H{h}
                            </th>
                          ))}
                          <th className="p-1.5 text-center font-medium text-[#D97706]">
                            Bias b²
                          </th>
                          <th className="p-1.5 text-center font-medium text-[#248A3D]">
                            Hub α
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {Array.from({ length: numMuscles }, (_, m) => (
                          <tr key={m}>
                            <td className="p-1.5 font-semibold text-[#1D1D1F]">
                              M{m}
                            </td>
                            {Array.from({ length: HIDDEN_SIZE }, (_, h) => {
                              const val = genome.w2[m * HIDDEN_SIZE + h] ?? 0;
                              const isPicked =
                                selectedWeightCell?.matrix === 'w2' &&
                                selectedWeightCell.row === m &&
                                selectedWeightCell.col === h;
                              return (
                                <td key={h} className="p-1">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setSelectedWeightCell({
                                        matrix: 'w2',
                                        row: m,
                                        col: h,
                                      })
                                    }
                                    style={{
                                      backgroundColor: weightColorBg(val),
                                    }}
                                    className={`w-full py-1.5 px-1 rounded-xl text-center font-semibold text-[#1D1D1F] transition cursor-pointer ${
                                      isPicked
                                        ? 'ring-2 ring-[#007AFF] scale-105'
                                        : 'hover:opacity-80'
                                    }`}
                                  >
                                    {val >= 0 ? '+' : ''}
                                    {val.toFixed(2)}
                                  </button>
                                </td>
                              );
                            })}
                            <td className="p-1 text-center font-semibold text-[#D97706] bg-[#FF9500]/10 rounded-xl">
                              {(genome.b2[m] ?? 0).toFixed(2)}
                            </td>
                            <td className="p-1 text-center font-semibold text-[#248A3D] bg-[#34C759]/12 rounded-xl">
                              ±{Math.round((genome.muscleStrength[m] ?? 0.34) * 100)}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 4: DEVELOPER ARCHITECTURE GUIDE */}
              {activeTab === 'guide' && (
                <div className="rounded-[22px] bg-white border border-black/[0.055] shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-5 sm:p-6 space-y-5">
                  <div>
                    <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-[#007AFF]/12 text-[#007AFF]">
                      Architektur-Blueprint
                    </span>
                    <h3 className="text-[17px] font-semibold text-[#1D1D1F] mt-2">
                      So entwickelst du deinen eigenen Neuro-Evolutions-Simulator
                    </h3>
                    <p className="text-[13px] text-[#6E6E73] mt-1 leading-relaxed">
                      Die 4 wichtigsten Säulen aus der Praxis — inklusive der typischen Stolpersteine bei Physik und Training:
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    <div className="p-4 rounded-2xl bg-[#F5F5F7]">
                      <div className="text-[13px] font-semibold text-[#1D1D1F] mb-1">
                        1. Neuroevolution statt Backpropagation
                      </div>
                      <p className="text-[12.5px] text-[#6E6E73] leading-relaxed">
                        Es gibt keine Trainings-Labels pro Frame und Bodenkontakte sind unstetig. Lasse 16–50 Individuen parallel für z. B. 12 Sekunden laufen und selektiere nach Distanz (Turnier-Selektion + Gauß-Mutation).
                      </p>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#F5F5F7]">
                      <div className="text-[13px] font-semibold text-[#1D1D1F] mb-1">
                        2. Hybrid CPG + Sensorik
                      </div>
                      <p className="text-[12.5px] text-[#6E6E73] leading-relaxed">
                        Kombiniere einen Oszillator (<code>sin</code>, <code>cos</code>, <code>sin(2ωt)</code>) mit Propriozeption (Bodenkontakt, Rumpfneigung, <code>vy</code>). So bewegt sich Generation 1 sofort rhythmisch und reagiert trotzdem auf Hügel.
                      </p>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#F5F5F7]">
                      <div className="text-[13px] font-semibold text-[#1D1D1F] mb-1">
                        3. Verlet + PBD statt Hooke-Federn
                      </div>
                      <p className="text-[12.5px] text-[#6E6E73] leading-relaxed">
                        Steife Federkräfte (<code>F = -k·Δx</code>) schwingen numerisch auf. Nutze Verlet-Integration + 10 iterative Distanz-Constraints pro Step und glätte die Muskel-Ziellänge per Tiefpass (<code>0.34</code>).
                      </p>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#F5F5F7]">
                      <div className="text-[13px] font-semibold text-[#1D1D1F] mb-1">
                        4. Anti-Umfall-Fitness &amp; Elitismus
                      </div>
                      <p className="text-[12.5px] text-[#6E6E73] leading-relaxed">
                        Bewerte <code>0.72 * endDistanz + 0.28 * maxDistanz</code> und übernimm die Top-2 Eliten unverändert in die nächste Generation, damit ein gefundener Laufstil niemals verloren geht.
                      </p>
                    </div>
                  </div>

                  <div>
                    <div className="text-[12.5px] font-semibold text-[#1D1D1F] mb-2">
                      Kompletter Kern-Code (Forward Pass + Muskel-Kopplung):
                    </div>
                    <pre className="p-4 rounded-[18px] bg-[#161618] text-white/90 font-mono text-[11px] overflow-x-auto leading-relaxed">
{`// 1. CPG + Sensorik Inputs [-1, +1]
const phase = 2 * Math.PI * genome.baseFreq * timeSec;
const x = [
  Math.sin(phase),                    // I0: Grundtakt
  Math.cos(phase),                    // I1: 90° Phasenversatz -> 2D Grenzzyklus!
  Math.sin(2 * phase),                // I2: Oberwelle für asymmetrischen Abstoß
  (groundContacts / joints.length) * 2 - 1, // I3: Bodenkontakt [-1..+1]
  bodyTiltSin,                        // I4: Rumpfneigung [-1..+1]
  clamp(avgVy / 350, -1, 1),          // I5: Vertikalgeschwindigkeit
];

// 2. MLP Forward Pass: h = tanh(W1 * x + b1), out = tanh(W2 * h + b2)
const h = genome.b1.map((b, r) =>
  Math.tanh(b + x.reduce((s, xi, c) => s + genome.w1[r * 6 + c] * xi, 0))
);
const muscleOut = genome.b2.map((b, m) =>
  Math.tanh(b + h.reduce((s, hi, c) => s + genome.w2[m * 6 + c] * hi, 0))
);

// 3. Sanfte Kopplung an PBD Muskel-Constraint
muscle.desired = muscle.restLen * (1 + muscleOut[m] * genome.strength[m]);
muscle.target += (muscle.desired - muscle.target) * 0.34;`}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
