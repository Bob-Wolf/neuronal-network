import React from 'react';
import {
  Cpu,
  Flag,
  Pause,
  RotateCcw,
  SkipForward,
  SlidersHorizontal,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import { MapId } from '../types/simulation';
import { MAP_CONFIGS } from '../simulation/terrain';

interface SimulationHUDProps {
  mapId: MapId;
  generation: number;
  maxChallengeGens: number;
  endlessMode: boolean;
  genTimeRemaining: number;
  genDuration: number;
  leaderDistanceM: number;
  bestDistanceM: number;
  currentScore: number;
  simSpeed: number;
  onSetSimSpeed: (speed: number) => void;
  boostCooldownRatio: number; // 0 = ready, 0..1 = recharging
  boostActive: boolean;
  onTriggerBoost: () => void;
  onNextGeneration: () => void;
  onFinishRun: () => void;
  onEditCreature: () => void;
  onPause: () => void;
  onInstantRestart: () => void;
  showNeuralOverlay: boolean;
  onToggleNeuralOverlay: () => void;
  onOpenNeuralDashboard: () => void;
  muted: boolean;
  onToggleMute: () => void;
}

export const SimulationHUD: React.FC<SimulationHUDProps> = ({
  mapId,
  generation,
  maxChallengeGens,
  endlessMode,
  genTimeRemaining,
  genDuration,
  leaderDistanceM,
  bestDistanceM,
  currentScore,
  simSpeed,
  onSetSimSpeed,
  boostCooldownRatio,
  boostActive,
  onTriggerBoost,
  onNextGeneration,
  onFinishRun,
  onEditCreature,
  onPause,
  onInstantRestart,
  showNeuralOverlay,
  onToggleNeuralOverlay,
  onOpenNeuralDashboard,
  muted,
  onToggleMute,
}) => {
  const mapCfg = MAP_CONFIGS[mapId];
  const progressPct = Math.max(0, Math.min(100, (genTimeRemaining / genDuration) * 100));
  const speedOptions = [1, 2, 5, 10];

  return (
    <>
      {/* Top Floating Telemetry Bar */}
      <div className="fixed top-4 left-4 right-4 z-20 flex flex-wrap items-center justify-between gap-2.5 pointer-events-none">
        {/* Left Telemetry Capsule */}
        <div className="pointer-events-auto flex items-center gap-4 apple-glass rounded-full px-5 py-2">
          {/* Generation + Progress */}
          <div className="min-w-[88px]">
            <div className="flex items-center justify-between text-[11.5px] font-semibold text-[#1D1D1F]">
              <span>
                Gen {generation}
                {!endlessMode ? `/${maxChallengeGens}` : ''}
              </span>
              <span className="font-mono text-[11px] font-medium text-[#86868B]">
                {genTimeRemaining.toFixed(1)}s
              </span>
            </div>
            <div className="w-full h-1.5 bg-black/[0.07] rounded-full overflow-hidden mt-1">
              <div
                className="h-full rounded-full transition-all duration-75"
                style={{
                  width: `${progressPct}%`,
                  backgroundColor: mapCfg.accentColor,
                }}
              />
            </div>
          </div>

          <div className="h-6 w-px bg-black/[0.08]" />

          {/* Distance */}
          <div>
            <div className="text-[10.5px] font-medium text-[#86868B] leading-none mb-0.5">
              Distance
            </div>
            <div className="font-mono text-[14px] sm:text-[15px] font-semibold text-[#1D1D1F] leading-tight">
              {Math.max(0, leaderDistanceM).toFixed(1)}
              <span className="text-[11.5px] text-[#86868B] font-medium">
                /{mapCfg.targetMeters}m
              </span>
            </div>
          </div>

          <div className="h-6 w-px bg-black/[0.08] hidden sm:block" />

          {/* Best Run */}
          <div className="hidden sm:block">
            <div className="text-[10.5px] font-medium text-[#86868B] leading-none mb-0.5">
              Best
            </div>
            <div className="font-mono text-[14px] sm:text-[15px] font-semibold text-[#FF9500] leading-tight">
              {bestDistanceM.toFixed(1)}m
            </div>
          </div>

          <div className="h-6 w-px bg-black/[0.08]" />

          {/* Score */}
          <div>
            <div className="text-[10.5px] font-medium text-[#86868B] leading-none mb-0.5">
              Score
            </div>
            <div className="font-mono text-[14px] sm:text-[15px] font-semibold text-[#1D1D1F] leading-tight">
              {currentScore.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Right Controls Capsule */}
        <div className="pointer-events-auto flex items-center gap-1.5 apple-glass rounded-full p-1.5">
          <button
            type="button"
            onClick={onOpenNeuralDashboard}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#007AFF] hover:bg-[#0066D6] active:scale-[0.97] text-white text-[12px] font-semibold transition-all cursor-pointer shadow-[0_4px_12px_rgba(0,122,255,0.3)]"
            title="Open Neural Network Dashboard (D)"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Neural</span>
          </button>

          <button
            type="button"
            onClick={onToggleNeuralOverlay}
            className={`px-2.5 py-1.5 rounded-full text-[11px] font-medium transition cursor-pointer ${
              showNeuralOverlay
                ? 'bg-[#007AFF]/12 text-[#007AFF] font-semibold'
                : 'text-[#86868B] hover:bg-black/[0.05]'
            }`}
            title="Toggle Mini Cortex Widget"
          >
            Widget
          </button>

          <button
            type="button"
            onClick={onToggleMute}
            className="w-8 h-8 rounded-full text-[#1D1D1F] hover:bg-black/[0.06] flex items-center justify-center transition cursor-pointer"
            title={muted ? 'Unmute' : 'Mute'}
          >
            {muted ? <VolumeX className="w-4 h-4 text-[#86868B]" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={onInstantRestart}
            className="w-8 h-8 rounded-full text-[#1D1D1F] hover:bg-black/[0.06] flex items-center justify-center transition cursor-pointer"
            title="Restart Gen 1 (R)"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onPause}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#1D1D1F] hover:bg-[#323236] active:scale-[0.97] text-white text-[12px] font-semibold transition-all cursor-pointer"
            title="Pause (P / Esc)"
          >
            <Pause className="w-3 h-3 fill-current" />
            <span className="hidden sm:inline">Pause</span>
          </button>
        </div>
      </div>

      {/* Bottom Floating Playback Control Dock */}
      <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-20 w-[calc(100%-1.5rem)] max-w-[650px] pointer-events-none">
        <div className="pointer-events-auto flex flex-wrap sm:flex-nowrap items-center justify-between gap-2 apple-glass rounded-[28px] sm:rounded-full p-2">
          {/* Edit Creature Studio Button */}
          <button
            type="button"
            onClick={onEditCreature}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-black/[0.05] hover:bg-black/[0.085] text-[#1D1D1F] text-[12.5px] font-medium transition cursor-pointer"
            title="Edit Creature Anatomy (E)"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Studio</span>
          </button>

          {/* Segmented Speed Selector */}
          <div className="apple-segment-track rounded-full flex items-center gap-0.5">
            {speedOptions.map((spd) => {
              const active = simSpeed === spd;
              return (
                <button
                  key={spd}
                  type="button"
                  onClick={() => onSetSimSpeed(spd)}
                  className={`font-mono px-3 py-1.5 rounded-full text-[12px] font-medium transition-all cursor-pointer ${
                    active
                      ? 'apple-segment-active font-semibold'
                      : 'text-[#6E6E73] hover:text-[#1D1D1F]'
                  }`}
                >
                  {spd === 10 ? 'Max' : `${spd}×`}
                </button>
              );
            })}
          </div>

          {/* Interactive Neural Surge Button */}
          <button
            type="button"
            onClick={onTriggerBoost}
            disabled={boostCooldownRatio > 0}
            className={`relative overflow-hidden flex items-center gap-1.5 px-4 py-2 rounded-full text-[12.5px] font-semibold transition-all cursor-pointer ${
              boostActive
                ? 'bg-[#FF9500] text-white shadow-[0_6px_16px_rgba(255,149,0,0.4)] scale-[1.02]'
                : boostCooldownRatio > 0
                ? 'bg-black/[0.04] text-[#86868B] cursor-not-allowed'
                : 'bg-[#FF9500]/14 hover:bg-[#FF9500] hover:text-white text-[#D97706]'
            }`}
            title="Send Neural Surge (Space)"
          >
            {boostCooldownRatio > 0 && (
              <div
                className="absolute inset-y-0 left-0 bg-[#FF9500]/16 transition-all duration-75"
                style={{ width: `${(1 - boostCooldownRatio) * 100}%` }}
              />
            )}
            <Zap className="w-3.5 h-3.5 relative z-10" />
            <span className="relative z-10">Surge</span>
          </button>

          {/* Next Generation + Finish Run */}
          <div className="flex items-center gap-1.5 ml-auto sm:ml-0">
            <button
              type="button"
              onClick={onNextGeneration}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#34C759] hover:bg-[#2DB84D] active:scale-[0.97] text-white text-[12.5px] font-semibold transition-all cursor-pointer shadow-[0_6px_16px_-3px_rgba(52,199,89,0.45)]"
              title="Evolve Next Generation Now (N)"
            >
              <SkipForward className="w-3.5 h-3.5" />
              <span>Next Gen</span>
            </button>

            <button
              type="button"
              onClick={onFinishRun}
              className="w-9 h-9 rounded-full bg-[#1D1D1F] hover:bg-[#323236] text-white flex items-center justify-center transition cursor-pointer"
              title="Finish Run & Save Record"
            >
              <Flag className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
