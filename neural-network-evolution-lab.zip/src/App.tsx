import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  CreatureBlueprint,
  CreatureInstance,
  EditorTool,
  FloatingPopup,
  GameScreen,
  GenerationSummary,
  HighScoreEntry,
  JointBlueprint,
  MapId,
  NeuralGenome,
  Particle,
  RunEndReason,
} from './types/simulation';
import { CREATURE_PRESETS, cloneBlueprint } from './simulation/presets';
import {
  getTerrainHeight,
  MAP_CONFIGS,
  PIXELS_PER_METER,
} from './simulation/terrain';
import {
  createInitialPopulation,
  evolvePopulation,
  POPULATION_SIZE,
} from './simulation/neuralNet';
import {
  autoRigMuscles,
  ImpactEvent,
  JOINT_RADIUS,
  spawnPopulation,
  stepCreaturePhysics,
} from './simulation/physics';
import {
  CameraState,
  EditorInteractionPreview,
  getNeuralHudBounds,
  renderSimulationFrame,
  screenToWorld,
} from './simulation/renderer';
import { soundEngine } from './audio/soundEngine';
import {
  calculateEvolutionScore,
  loadHighScores,
  renameHighScoreEntry,
  saveHighScore,
} from './storage/highScores';
import { StartScreen } from './components/StartScreen';
import { EditorToolbar } from './components/EditorToolbar';
import { SimulationHUD } from './components/SimulationHUD';
import { PauseAndGameOverModal } from './components/PauseAndGameOverModal';
import { NeuralDashboard } from './components/NeuralDashboard';

const GEN_DURATION_SEC = 12.0;
const CHALLENGE_MAX_GENS = 8;
const BOOST_DURATION_SEC = 1.45;
const BOOST_COOLDOWN_SEC = 4.5;

function distancePointToSegment(
  px: number,
  py: number,
  x1: number,
  y1: number,
  x2: number,
  y2: number
): number {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) return Math.hypot(px - x1, py - y1);
  let t = ((px - x1) * dx + (py - y1) * dy) / lenSq;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
}

export function App() {
  // Primary UI state
  const [screen, setScreen] = useState<GameScreen>('start');
  const [mapId, setMapId] = useState<MapId>('flat');
  const [selectedPresetIdx, setSelectedPresetIdx] = useState<number>(0);
  const [tool, setTool] = useState<EditorTool>('bone');
  const [blueprint, setBlueprint] = useState<CreatureBlueprint>(() =>
    cloneBlueprint(CREATURE_PRESETS[0])
  );
  const [undoStack, setUndoStack] = useState<CreatureBlueprint[]>([]);

  // Simulation HUD synced states
  const [generation, setGeneration] = useState<number>(1);
  const [genTimeRemaining, setGenTimeRemaining] = useState<number>(GEN_DURATION_SEC);
  const [leaderDistanceM, setLeaderDistanceM] = useState<number>(0);
  const [bestDistanceM, setBestDistanceM] = useState<number>(0);
  const [currentScore, setCurrentScore] = useState<number>(0);
  const [simSpeed, setSimSpeed] = useState<number>(1);
  const [endlessMode, setEndlessMode] = useState<boolean>(false);
  const [boostCooldownRatio, setBoostCooldownRatio] = useState<number>(0);
  const [boostActiveUI, setBoostActiveUI] = useState<boolean>(false);
  const [showNeuralOverlay, setShowNeuralOverlay] = useState<boolean>(true);
  const [muted, setMuted] = useState<boolean>(() => soundEngine.isMuted());

  // Modals & Records
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [showNeuralDashboard, setShowNeuralDashboard] = useState<boolean>(false);
  const [showLeaderboardModal, setShowLeaderboardModal] = useState<boolean>(false);
  const [runEndReason, setRunEndReason] = useState<RunEndReason>(null);
  const [isNewRecord, setIsNewRecord] = useState<boolean>(false);
  const [lastSavedScoreId, setLastSavedScoreId] = useState<string | null>(null);
  const [genHistory, setGenHistory] = useState<GenerationSummary[]>([]);
  const [highScores, setHighScores] = useState<HighScoreEntry[]>(() =>
    loadHighScores()
  );

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Mutable simulation core reference for locked 60fps loop with zero GC jitter
  const simRef = useRef<{
    screen: GameScreen;
    mapId: MapId;
    blueprint: CreatureBlueprint;
    genomes: NeuralGenome[];
    population: CreatureInstance[];
    leaderIdx: number;
    generation: number;
    simTime: number;
    totalVisualTime: number;
    simSpeed: number;
    bestDistanceM: number;
    peakSpeedMps: number;
    nextMilestoneM: number;
    stagnationCount: number;
    lastGenBestM: number;
    endlessMode: boolean;
    goalCelebrated: boolean;
    isPaused: boolean;
    runEnded: boolean;
    boostTimer: number;
    boostCooldown: number;
    shakeTrauma: number;
    buildZoom: number;
    camera: CameraState;
    particles: Particle[];
    popups: FloatingPopup[];
    editorPreview: EditorInteractionPreview;
    panDragging: boolean;
    panLastScreenX: number;
    panLastScreenY: number;
    showNeuralOverlay: boolean;
    dashboardOpen: boolean;
  }>({
    screen: 'start',
    mapId: 'flat',
    blueprint: cloneBlueprint(CREATURE_PRESETS[0]),
    genomes: [],
    population: [],
    leaderIdx: 0,
    generation: 1,
    simTime: 0,
    totalVisualTime: 0,
    simSpeed: 1,
    bestDistanceM: 0,
    peakSpeedMps: 0,
    nextMilestoneM: 10,
    stagnationCount: 0,
    lastGenBestM: 0,
    endlessMode: false,
    goalCelebrated: false,
    isPaused: false,
    runEnded: false,
    boostTimer: 0,
    boostCooldown: 0,
    shakeTrauma: 0,
    buildZoom: 1.08,
    camera: { x: 80, y: -60, zoom: 1.0, shakeX: 0, shakeY: 0 },
    particles: [],
    popups: [],
    editorPreview: {
      tool: 'bone',
      pointerWorldX: 0,
      pointerWorldY: -60,
      hoveredJointId: null,
      hoveredEdgeId: null,
      dragStartJointId: null,
      dragStartX: 0,
      dragStartY: 0,
      isDragging: false,
    },
    panDragging: false,
    panLastScreenX: 0,
    panLastScreenY: 0,
    showNeuralOverlay: true,
    dashboardOpen: false,
  });

  // Sync key states into simRef
  useEffect(() => {
    simRef.current.screen = screen;
    simRef.current.editorPreview.tool = tool;
    simRef.current.simSpeed = simSpeed;
    simRef.current.isPaused = isPaused;
    simRef.current.endlessMode = endlessMode;
    simRef.current.showNeuralOverlay = showNeuralOverlay;
    simRef.current.dashboardOpen = showNeuralDashboard;
    simRef.current.blueprint = blueprint;
  }, [
    screen,
    tool,
    simSpeed,
    isPaused,
    endlessMode,
    showNeuralOverlay,
    showNeuralDashboard,
    blueprint,
  ]);

  const emitBurstParticles = useCallback(
    (
      x: number,
      y: number,
      count: number,
      colors: string[],
      kind: Particle['kind'] = 'spark',
      speedScale = 1
    ) => {
      const arr = simRef.current.particles;
      for (let i = 0; i < count && arr.length < 260; i++) {
        const angle = -Math.PI * Math.random();
        const speed = (45 + Math.random() * 145) * speedScale;
        arr.push({
          x,
          y,
          vx: Math.cos(angle) * speed + (Math.random() - 0.5) * 50,
          vy: Math.sin(angle) * speed - Math.random() * 40,
          size: kind === 'dust' ? 2.5 + Math.random() * 3.5 : 3 + Math.random() * 4,
          alpha: 0.95,
          decay: kind === 'dust' ? 1.8 : 1.15,
          color: colors[i % colors.length],
          kind,
        });
      }
    },
    []
  );

  const addPopup = useCallback(
    (x: number, y: number, text: string, color = '#0F172A', subtext?: string) => {
      simRef.current.popups.push({
        x,
        y,
        vy: -38,
        text,
        subtext,
        color,
        alpha: 1.0,
        scale: 1.08,
      });
    },
    []
  );

  // Initialize or restart fresh evolution run
  const startNewEvolutionRun = useCallback(
    (
      targetBlueprint: CreatureBlueprint,
      targetMap: MapId,
      targetScreen: GameScreen = 'evolve',
      keepEndless = false
    ) => {
      let workingBp = cloneBlueprint(targetBlueprint);

      // Guarantee valid anatomy so even empty or bone-only creatures spring into action!
      if (workingBp.joints.length < 2) {
        workingBp = cloneBlueprint(CREATURE_PRESETS[0]);
      }
      const muscleCount = workingBp.edges.filter((e) => e.kind === 'muscle').length;
      let autoRigged = false;
      if (muscleCount === 0) {
        workingBp = autoRigMuscles(workingBp);
        autoRigged = true;
      }

      setBlueprint(workingBp);

      const finalMuscles = workingBp.edges.filter((e) => e.kind === 'muscle').length;
      const genomes = createInitialPopulation(finalMuscles, POPULATION_SIZE);
      const pop = spawnPopulation(workingBp, genomes, targetMap);

      const s = simRef.current;
      s.mapId = targetMap;
      s.blueprint = workingBp;
      s.genomes = genomes;
      s.population = pop;
      s.leaderIdx = 0;
      s.generation = 1;
      s.simTime = 0;
      s.bestDistanceM = 0;
      s.peakSpeedMps = 0;
      s.nextMilestoneM = 10;
      s.stagnationCount = 0;
      s.lastGenBestM = 0;
      s.endlessMode = keepEndless;
      s.goalCelebrated = false;
      s.runEnded = false;
      s.isPaused = false;
      s.boostTimer = 0;
      s.boostCooldown = 0;
      s.particles = [];
      s.popups = [];
      s.camera.x = targetScreen === 'start' ? 90 : 60;
      s.camera.y = -65;

      if (autoRigged && targetScreen === 'evolve') {
        addPopup(0, -135, 'AUTO-RIGGED MUSCLES ⚡', '#F43F5E', 'Ready for evolution');
      }

      setMapId(targetMap);
      setScreen(targetScreen);
      setGeneration(1);
      setGenTimeRemaining(GEN_DURATION_SEC);
      setLeaderDistanceM(0);
      setBestDistanceM(0);
      setCurrentScore(0);
      setEndlessMode(keepEndless);
      setIsPaused(false);
      setRunEndReason(null);
      setIsNewRecord(false);
      setGenHistory([]);
      setBoostCooldownRatio(0);
      setBoostActiveUI(false);
    },
    [addPopup]
  );

  // Kick off background demo on first mount
  useEffect(() => {
    startNewEvolutionRun(cloneBlueprint(CREATURE_PRESETS[0]), 'flat', 'start', true);
  }, [startNewEvolutionRun]);

  // Complete run & persist local high score
  const finalizeRun = useCallback((reason: RunEndReason) => {
    const s = simRef.current;
    if (s.runEnded) return;
    s.runEnded = true;

    const score = calculateEvolutionScore({
      distanceM: s.bestDistanceM,
      peakSpeedMps: s.peakSpeedMps,
      generation: s.generation,
      mapId: s.mapId,
      blueprint: s.blueprint,
    });

    const bonesCount = s.blueprint.edges.filter((e) => e.kind === 'bone').length;
    const musclesCount = s.blueprint.edges.filter((e) => e.kind === 'muscle').length;

    let recordFlag = false;
    if (score > 0) {
      const saved = saveHighScore({
        creatureName: s.blueprint.name || 'Custom Specimen',
        mapId: s.mapId,
        distanceM: Number(s.bestDistanceM.toFixed(1)),
        score,
        generations: s.generation,
        bonesCount,
        musclesCount,
      });
      setHighScores(saved.updated);
      setLastSavedScoreId(saved.entryId);
      recordFlag = saved.isNewRecord;
    } else {
      setLastSavedScoreId(null);
    }

    setCurrentScore(score);
    setBestDistanceM(s.bestDistanceM);
    setIsNewRecord(recordFlag);
    setRunEndReason(reason);

    if (reason === 'target_reached') {
      soundEngine.playVictory();
    } else {
      soundEngine.playMilestone(4);
    }
  }, []);

  // Advance to Next Generation
  const advanceGeneration = useCallback(() => {
    const s = simRef.current;
    if (s.population.length === 0) return;

    let genBestM = 0;
    let sumM = 0;
    for (const c of s.population) {
      if (c.maxDistanceM > genBestM) genBestM = c.maxDistanceM;
      sumM += Math.max(0, c.maxDistanceM);
      if (c.peakSpeedMps > s.peakSpeedMps) s.peakSpeedMps = c.peakSpeedMps;
    }
    const avgM = sumM / s.population.length;
    if (genBestM > s.bestDistanceM) {
      s.bestDistanceM = genBestM;
    }

    const genScore = calculateEvolutionScore({
      distanceM: s.bestDistanceM,
      peakSpeedMps: s.peakSpeedMps,
      generation: s.generation,
      mapId: s.mapId,
      blueprint: s.blueprint,
    });

    const summaryItem: GenerationSummary = {
      generation: s.generation,
      bestDistanceM: genBestM,
      avgDistanceM: avgM,
      score: genScore,
    };

    if (s.screen === 'evolve') {
      setGenHistory((prev) => [...prev, summaryItem]);
    }

    // Check if Challenge 8-Generation Trial ended (unless in Endless Mode or Start Demo)
    if (
      s.screen === 'evolve' &&
      !s.endlessMode &&
      s.generation >= CHALLENGE_MAX_GENS
    ) {
      finalizeRun('generations_complete');
      return;
    }

    // Track stagnation to adapt mutation exploration
    if (genBestM <= s.lastGenBestM + 0.25) {
      s.stagnationCount++;
    } else {
      s.stagnationCount = 0;
      s.lastGenBestM = genBestM;
    }

    const numMuscles = s.blueprint.edges.filter((e) => e.kind === 'muscle').length;
    const nextGenomes = evolvePopulation(s.genomes, numMuscles, s.stagnationCount);
    const nextPop = spawnPopulation(s.blueprint, nextGenomes, s.mapId);

    s.genomes = nextGenomes;
    s.population = nextPop;
    s.leaderIdx = 0;
    s.generation += 1;
    s.simTime = 0;

    if (s.screen === 'evolve') {
      soundEngine.playEvolveNext();
      addPopup(
        0,
        -125,
        `GENERATION ${s.generation}`,
        '#10B981',
        `Elites preserved · Mutating gaits`
      );
      setGeneration(s.generation);
      setBestDistanceM(s.bestDistanceM);
      setCurrentScore(genScore);
    }
  }, [addPopup, finalizeRun]);

  // Adrenaline Neural Surge trigger
  const triggerBoost = useCallback(() => {
    const s = simRef.current;
    if (s.screen !== 'evolve' || s.isPaused || s.runEnded || s.boostCooldown > 0) {
      return;
    }
    soundEngine.unlock();
    soundEngine.playBoost();
    s.boostTimer = BOOST_DURATION_SEC;
    s.boostCooldown = BOOST_COOLDOWN_SEC;
    s.shakeTrauma = Math.min(1, s.shakeTrauma + 0.45);
    setBoostActiveUI(true);

    const leader = s.population[s.leaderIdx];
    if (leader && leader.joints.length > 0) {
      const j = leader.joints[0];
      emitBurstParticles(j.x, j.y, 18, ['#F59E0B', '#FBBF24', '#06B6D4'], 'spark', 1.25);
      addPopup(j.x, j.y - 45, 'NEURAL SURGE ⚡', '#D97706');
    }
  }, [addPopup, emitBurstParticles]);

  // Switch Mode to Build Editor cleanly
  const enterBuildMode = useCallback(
    (customBp?: CreatureBlueprint) => {
      soundEngine.unlock();
      const s = simRef.current;
      const bpToEdit = customBp ? cloneBlueprint(customBp) : cloneBlueprint(s.blueprint);
      setBlueprint(bpToEdit);
      s.blueprint = bpToEdit;
      s.screen = 'build';
      s.isPaused = false;
      s.runEnded = false;
      s.camera.x = 0;
      s.camera.y = -65;
      const initZoom = window.innerWidth < 640 ? 0.88 : 1.1;
      s.buildZoom = initZoom;
      s.camera.zoom = initZoom;
      setScreen('build');
      setIsPaused(false);
      setRunEndReason(null);
    },
    []
  );

  // Blueprint Undo Helper
  const pushBlueprintEdit = useCallback((nextBp: CreatureBlueprint) => {
    setBlueprint((prev) => {
      setUndoStack((stack) => [...stack.slice(-24), cloneBlueprint(prev)]);
      return nextBp;
    });
  }, []);

  const handleUndo = useCallback(() => {
    setUndoStack((stack) => {
      if (stack.length === 0) return stack;
      const previous = stack[stack.length - 1];
      setBlueprint(previous);
      soundEngine.playSnap(0.85);
      return stack.slice(0, -1);
    });
  }, []);

  const openNeuralDashboard = useCallback(() => {
    soundEngine.unlock();
    soundEngine.playSnap(1.08);
    const s = simRef.current;
    // If opened while in Build mode, ensure population matches latest edited anatomy
    if (s.screen === 'build') {
      let workingBp = cloneBlueprint(s.blueprint);
      if (workingBp.joints.length < 2) {
        workingBp = cloneBlueprint(CREATURE_PRESETS[0]);
      }
      if (workingBp.edges.filter((e) => e.kind === 'muscle').length === 0) {
        workingBp = autoRigMuscles(workingBp);
      }
      const mCount = workingBp.edges.filter((e) => e.kind === 'muscle').length;
      if (s.population.length === 0 || s.population[0].muscleIndices.length !== mCount) {
        const genomes = createInitialPopulation(mCount, POPULATION_SIZE);
        s.genomes = genomes;
        s.population = spawnPopulation(workingBp, genomes, s.mapId);
        s.leaderIdx = 0;
        s.simTime = 0;
      }
    }
    setShowNeuralDashboard(true);
  }, []);

  const handleStepSingleFrame = useCallback(() => {
    const s = simRef.current;
    setIsPaused(true);
    s.isPaused = true;
    const dt = 1 / 60;
    s.simTime += dt;
    let bestX = -Infinity;
    let currentLeader = 0;
    for (let i = 0; i < s.population.length; i++) {
      const c = s.population[i];
      stepCreaturePhysics(c, s.simTime, dt, s.mapId, 1.0, false);
      if (c.currentX > bestX) {
        bestX = c.currentX;
        currentLeader = i;
      }
    }
    s.leaderIdx = currentLeader;
    soundEngine.playSnap(1.2);
  }, []);

  const handleMutateCreatureLive = useCallback(
    (creatureIdx: number, sigma: number) => {
      const s = simRef.current;
      const target = s.population[creatureIdx];
      if (!target) return;
      const g = target.genome;
      const randNorm = () => {
        let u = 0;
        let v = 0;
        while (u === 0) u = Math.random();
        while (v === 0) v = Math.random();
        return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
      };
      g.baseFreq = Math.max(0.6, Math.min(3.8, g.baseFreq + randNorm() * sigma * 0.35));
      for (let i = 0; i < g.w1.length; i++) {
        if (Math.random() < 0.55) {
          g.w1[i] = Math.max(-3.5, Math.min(3.5, g.w1[i] + randNorm() * sigma));
        }
      }
      for (let i = 0; i < g.w2.length; i++) {
        if (Math.random() < 0.55) {
          g.w2[i] = Math.max(-3.5, Math.min(3.5, g.w2[i] + randNorm() * sigma));
        }
      }
      soundEngine.playMuscleAttach();
    },
    []
  );

  // Keyboard Controls for tight desktop responsiveness
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement &&
        ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)
      ) {
        return;
      }

      const key = e.key.toLowerCase();
      const s = simRef.current;

      if (key === 'd') {
        e.preventDefault();
        if (s.dashboardOpen) {
          setShowNeuralDashboard(false);
        } else {
          openNeuralDashboard();
        }
        return;
      }

      if (key === 'escape' && s.dashboardOpen) {
        e.preventDefault();
        setShowNeuralDashboard(false);
        return;
      }

      if ((e.metaKey || e.ctrlKey) && key === 'z' && s.screen === 'build') {
        e.preventDefault();
        handleUndo();
        return;
      }

      if (s.screen === 'build') {
        if (key === '1') setTool('bone');
        else if (key === '2') setTool('muscle');
        else if (key === '3') setTool('move');
        else if (key === '4' || key === 'x') setTool('erase');
        else if (e.code === 'Space' || key === 'enter') {
          e.preventDefault();
          soundEngine.unlock();
          startNewEvolutionRun(s.blueprint, s.mapId, 'evolve', false);
        }
        return;
      }

      if (s.screen === 'evolve') {
        if (key === 'p' || key === 'escape') {
          e.preventDefault();
          if (s.runEnded) return;
          setIsPaused((prev) => !prev);
        } else if (key === 'r') {
          e.preventDefault();
          soundEngine.unlock();
          startNewEvolutionRun(s.blueprint, s.mapId, 'evolve', s.endlessMode);
        } else if (key === 'e') {
          e.preventDefault();
          enterBuildMode();
        } else if (key === 'n' && !s.isPaused && !s.runEnded) {
          e.preventDefault();
          advanceGeneration();
        } else if (e.code === 'Space' && !s.isPaused && !s.runEnded) {
          e.preventDefault();
          triggerBoost();
        } else if (key === '1') setSimSpeed(1);
        else if (key === '2') setSimSpeed(2);
        else if (key === '3') setSimSpeed(5);
        else if (key === '4') setSimSpeed(10);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    advanceGeneration,
    enterBuildMode,
    handleUndo,
    openNeuralDashboard,
    startNewEvolutionRun,
    triggerBoost,
  ]);

  // Master 60fps Simulation + Canvas Rendering Loop
  useEffect(() => {
    let rafId = 0;
    let lastTimestamp = performance.now();
    let hudSyncAccum = 0;

    const fixedDt = 1 / 60;

    const frame = (now: number) => {
      rafId = requestAnimationFrame(frame);
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Resize canvas cleanly to match viewport + devicePixelRatio
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const viewW = window.innerWidth;
      const viewH = window.innerHeight;
      if (canvas.width !== Math.round(viewW * dpr) || canvas.height !== Math.round(viewH * dpr)) {
        canvas.width = Math.round(viewW * dpr);
        canvas.height = Math.round(viewH * dpr);
      }

      const rawDt = Math.min(0.05, Math.max(0.001, (now - lastTimestamp) / 1000));
      lastTimestamp = now;

      const s = simRef.current;
      s.totalVisualTime += rawDt;

      // Step physics when in Start background demo, active Evolve mode, OR live Dashboard preview
      if (
        (s.screen === 'start' || s.screen === 'evolve' || s.dashboardOpen) &&
        !s.isPaused &&
        !s.runEnded &&
        s.population.length > 0
      ) {
        const stepsToRun =
          s.screen === 'start' || (s.dashboardOpen && s.screen === 'build')
            ? 1
            : s.simSpeed;
        const impacts: ImpactEvent[] = [];

        // Update boost cooldown timers in wall-clock time so player interaction feels consistent
        if (s.boostTimer > 0) {
          s.boostTimer = Math.max(0, s.boostTimer - rawDt);
        }
        if (s.boostCooldown > 0) {
          s.boostCooldown = Math.max(0, s.boostCooldown - rawDt);
        }

        const boostMult = s.boostTimer > 0 ? 1.38 : 1.0;

        for (let step = 0; step < stepsToRun; step++) {
          s.simTime += fixedDt;

          let bestX = -Infinity;
          let currentLeader = 0;

          for (let i = 0; i < s.population.length; i++) {
            const c = s.population[i];
            const isLead = i === s.leaderIdx;
            stepCreaturePhysics(
              c,
              s.simTime,
              fixedDt,
              s.mapId,
              boostMult,
              isLead && step === stepsToRun - 1,
              impacts
            );

            if (c.currentX > bestX) {
              bestX = c.currentX;
              currentLeader = i;
            }
          }

          s.leaderIdx = currentLeader;
          const leader = s.population[s.leaderIdx];

          if (leader) {
            if (leader.maxDistanceM > s.bestDistanceM) {
              s.bestDistanceM = leader.maxDistanceM;
            }
            if (leader.peakSpeedMps > s.peakSpeedMps) {
              s.peakSpeedMps = leader.peakSpeedMps;
            }

            // Emit boost bio-sparks while surge is active
            if (s.boostTimer > 0 && Math.random() < 0.35 && leader.joints.length > 0) {
              const rj = leader.joints[Math.floor(Math.random() * leader.joints.length)];
              s.particles.push({
                x: rj.x,
                y: rj.y,
                vx: (Math.random() - 0.5) * 60,
                vy: -20 - Math.random() * 50,
                size: 2.8,
                alpha: 0.9,
                decay: 2.2,
                color: '#F59E0B',
                kind: 'spark',
              });
            }

            // Check 10-meter juicy milestones in Evolve mode
            if (s.screen === 'evolve' && leader.distanceM >= s.nextMilestoneM) {
              const reachedM = s.nextMilestoneM;
              s.nextMilestoneM += 10;
              s.shakeTrauma = Math.min(1, s.shakeTrauma + 0.38);
              soundEngine.playMilestone(Math.floor(reachedM / 10));
              emitBurstParticles(
                leader.currentX,
                leader.joints[0].y - 25,
                22,
                ['#10B981', '#06B6D4', '#F59E0B', '#F43F5E'],
                'confetti',
                1.3
              );
              addPopup(
                leader.currentX,
                leader.joints[0].y - 55,
                `+${reachedM}m MILESTONE!`,
                '#10B981'
              );
            }

            // Check Map Target Banner Victory!
            const targetM = MAP_CONFIGS[s.mapId].targetMeters;
            if (
              s.screen === 'evolve' &&
              !s.goalCelebrated &&
              leader.distanceM >= targetM
            ) {
              s.goalCelebrated = true;
              s.shakeTrauma = 0.85;
              emitBurstParticles(
                targetM * PIXELS_PER_METER,
                getTerrainHeight(s.mapId, targetM * PIXELS_PER_METER) - 90,
                42,
                ['#10B981', '#F59E0B', '#06B6D4', '#F43F5E', '#8B5CF6'],
                'confetti',
                1.6
              );
              addPopup(
                targetM * PIXELS_PER_METER,
                getTerrainHeight(s.mapId, targetM * PIXELS_PER_METER) - 120,
                `GOAL ${targetM}m CONQUERED!`,
                '#10B981'
              );
              if (!s.endlessMode) {
                finalizeRun('target_reached');
                break;
              } else {
                soundEngine.playVictory();
              }
            }
          }

          if (s.simTime >= GEN_DURATION_SEC) {
            advanceGeneration();
            break;
          }
        }

        // Process footstep landing dust & audio
        for (let i = 0; i < impacts.length; i++) {
          const imp = impacts[i];
          emitBurstParticles(
            imp.x,
            imp.y - 2,
            Math.ceil(3 + imp.intensity * 4),
            ['rgba(148, 163, 184, 0.7)', 'rgba(100, 116, 139, 0.55)'],
            'dust',
            0.55 + imp.intensity * 0.5
          );
          if (imp.isLeader && s.screen === 'evolve') {
            soundEngine.playFootstep(imp.intensity);
            if (imp.intensity > 0.68) {
              s.shakeTrauma = Math.min(1, s.shakeTrauma + imp.intensity * 0.16);
            }
          }
        }
      }

      // Camera smooth tracking
      const targetZoom = viewW < 640 ? 0.82 : 1.02;
      if (s.screen === 'build') {
        s.camera.zoom += (s.buildZoom - s.camera.zoom) * 0.16;
      } else {
        s.camera.zoom += (targetZoom - s.camera.zoom) * 0.08;
        const leader = s.population[s.leaderIdx];
        if (leader && leader.joints.length > 0) {
          let avgY = 0;
          for (const j of leader.joints) avgY += j.y;
          avgY /= leader.joints.length;
          const desiredX = leader.currentX + 75;
          const desiredY = Math.min(-45, avgY - 25);
          s.camera.x += (desiredX - s.camera.x) * 0.09;
          s.camera.y += (desiredY - s.camera.y) * 0.07;
        }
      }

      // Update screen shake trauma
      if (s.shakeTrauma > 0.001) {
        const mag = s.shakeTrauma * s.shakeTrauma * 12;
        s.camera.shakeX = (Math.random() * 2 - 1) * mag;
        s.camera.shakeY = (Math.random() * 2 - 1) * mag;
        s.shakeTrauma = Math.max(0, s.shakeTrauma - rawDt * 2.6);
      } else {
        s.camera.shakeX = 0;
        s.camera.shakeY = 0;
      }

      // Step particles in-place
      for (let i = s.particles.length - 1; i >= 0; i--) {
        const p = s.particles[i];
        p.x += p.vx * rawDt;
        p.y += p.vy * rawDt;
        if (p.kind !== 'ring') {
          p.vy += 320 * rawDt;
        } else {
          p.size += 80 * rawDt;
        }
        p.alpha -= p.decay * rawDt;
        if (p.alpha <= 0) {
          s.particles.splice(i, 1);
        }
      }

      // Step floating milestone popups
      for (let i = s.popups.length - 1; i >= 0; i--) {
        const pop = s.popups[i];
        pop.y += pop.vy * rawDt;
        pop.alpha -= 0.72 * rawDt;
        if (pop.alpha <= 0) {
          s.popups.splice(i, 1);
        }
      }

      // Render high-DPI frame
      ctx.save();
      ctx.scale(dpr, dpr);
      renderSimulationFrame({
        ctx,
        width: viewW,
        height: viewH,
        screen: s.screen,
        mapId: s.mapId,
        camera: s.camera,
        blueprint: s.blueprint,
        editorPreview: s.screen === 'build' ? s.editorPreview : null,
        population: s.population,
        leaderIndex: s.leaderIdx,
        bestDistanceM: s.bestDistanceM,
        particles: s.particles,
        popups: s.popups,
        boostActive: s.boostTimer > 0,
        simTime: s.totalVisualTime,
        showNeuralOverlay: s.showNeuralOverlay,
      });
      ctx.restore();

      // Throttle React HUD state sync (~12Hz) for ultra-clean CPU profile
      hudSyncAccum += rawDt;
      if (hudSyncAccum >= 0.08 && s.screen === 'evolve') {
        hudSyncAccum = 0;
        const leader = s.population[s.leaderIdx];
        const liveDist = leader ? leader.distanceM : 0;
        const liveScore = calculateEvolutionScore({
          distanceM: Math.max(s.bestDistanceM, liveDist),
          peakSpeedMps: s.peakSpeedMps,
          generation: s.generation,
          mapId: s.mapId,
          blueprint: s.blueprint,
        });
        setGenTimeRemaining(Math.max(0, GEN_DURATION_SEC - s.simTime));
        setLeaderDistanceM(liveDist);
        setBestDistanceM(s.bestDistanceM);
        setCurrentScore(liveScore);
        setBoostCooldownRatio(s.boostCooldown / BOOST_COOLDOWN_SEC);
        setBoostActiveUI(s.boostTimer > 0);
      }
    };

    rafId = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(rafId);
  }, [addPopup, advanceGeneration, emitBurstParticles, finalizeRun]);

  // Helper: Find closest joint / edge in Build Mode with touch-friendly magnetic snap
  const hitTestBlueprint = useCallback(
    (wx: number, wy: number) => {
      const s = simRef.current;
      const snapRadius = 24 / s.camera.zoom;
      let nearestJoint: JointBlueprint | null = null;
      let minJDist = snapRadius;

      for (const j of s.blueprint.joints) {
        const d = Math.hypot(j.x - wx, j.y - wy);
        if (d < minJDist) {
          minJDist = d;
          nearestJoint = j;
        }
      }

      let nearestEdgeId: string | null = null;
      let minEDist = 16 / s.camera.zoom;
      const jMap = new Map(s.blueprint.joints.map((j) => [j.id, j]));
      for (const e of s.blueprint.edges) {
        const ja = jMap.get(e.a);
        const jb = jMap.get(e.b);
        if (!ja || !jb) continue;
        const d = distancePointToSegment(wx, wy, ja.x, ja.y, jb.x, jb.y);
        if (d < minEDist) {
          minEDist = d;
          nearestEdgeId = e.id;
        }
      }

      return { nearestJoint, nearestEdgeId };
    },
    []
  );

  const eraseAtWorldPos = useCallback(
    (wx: number, wy: number) => {
      const { nearestJoint, nearestEdgeId } = hitTestBlueprint(wx, wy);
      const bp = simRef.current.blueprint;

      if (nearestJoint) {
        const nextJoints = bp.joints.filter((j) => j.id !== nearestJoint.id);
        const nextEdges = bp.edges.filter(
          (e) => e.a !== nearestJoint.id && e.b !== nearestJoint.id
        );
        soundEngine.playErase();
        emitBurstParticles(nearestJoint.x, nearestJoint.y, 8, ['#EF4444', '#64748B'], 'spark', 0.7);
        pushBlueprintEdit({ ...bp, joints: nextJoints, edges: nextEdges });
        return true;
      }

      if (nearestEdgeId) {
        const removed = bp.edges.find((e) => e.id === nearestEdgeId);
        const nextEdges = bp.edges.filter((e) => e.id !== nearestEdgeId);
        soundEngine.playErase();
        if (removed) {
          const ja = bp.joints.find((j) => j.id === removed.a);
          const jb = bp.joints.find((j) => j.id === removed.b);
          if (ja && jb) {
            emitBurstParticles(
              (ja.x + jb.x) * 0.5,
              (ja.y + jb.y) * 0.5,
              8,
              ['#EF4444', '#94A3B8'],
              'spark',
              0.7
            );
          }
        }
        pushBlueprintEdit({ ...bp, edges: nextEdges });
        return true;
      }

      return false;
    },
    [emitBurstParticles, hitTestBlueprint, pushBlueprintEdit]
  );

  const snapBuildY = (wx: number, wy: number, mId: MapId): number => {
    const surfaceContactY = getTerrainHeight(mId, wx) - JOINT_RADIUS;
    if (wy > surfaceContactY - 14) {
      return surfaceContactY;
    }
    return wy;
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    const s = simRef.current;
    if (s.screen !== 'build') return;
    const factor = e.deltaY > 0 ? 0.92 : 1.08;
    s.buildZoom = Math.max(0.62, Math.min(1.75, s.buildZoom * factor));
  };

  // Unified Pointer Handlers for Canvas (Desktop Mouse + Mobile Touch)
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    soundEngine.unlock();
    const s = simRef.current;
    const rectCheck = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rectCheck.left;
    const clickY = e.clientY - rectCheck.top;

    // Allow clicking directly on the top-left Neural Cortex HUD card in Evolve mode to open the full Dashboard
    if (s.screen === 'evolve' && s.showNeuralOverlay) {
      const leader = s.population[s.leaderIdx];
      const hudBox = getNeuralHudBounds(
        rectCheck.width,
        leader?.muscleIndices.length ?? 1
      );
      if (
        clickX >= hudBox.x &&
        clickX <= hudBox.x + hudBox.w &&
        clickY >= hudBox.y &&
        clickY <= hudBox.y + hudBox.h
      ) {
        openNeuralDashboard();
        return;
      }
    }

    if (s.screen !== 'build') return;

    (e.target as HTMLCanvasElement).setPointerCapture(e.pointerId);

    const rect = e.currentTarget.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const { wx, wy } = screenToWorld(sx, sy, s.camera, rect.width, rect.height);
    const clampedY = snapBuildY(wx, wy, s.mapId);

    // Right click quick-erase convenience on desktop
    if (e.button === 2) {
      eraseAtWorldPos(wx, wy);
      return;
    }

    const { nearestJoint, nearestEdgeId } = hitTestBlueprint(wx, wy);
    const preview = s.editorPreview;
    preview.pointerWorldX = wx;
    preview.pointerWorldY = clampedY;
    preview.hoveredJointId = nearestJoint?.id ?? null;
    preview.hoveredEdgeId = nearestEdgeId;

    if (tool === 'erase') {
      preview.isDragging = true;
      eraseAtWorldPos(wx, wy);
      return;
    }

    if (tool === 'move') {
      if (nearestJoint) {
        // Save undo snapshot before moving joint
        setUndoStack((stack) => [...stack.slice(-24), cloneBlueprint(s.blueprint)]);
        preview.dragStartJointId = nearestJoint.id;
        preview.isDragging = true;
      } else {
        s.panDragging = true;
        s.panLastScreenX = sx;
        s.panLastScreenY = sy;
      }
      return;
    }

    // Bone or Muscle tool
    preview.isDragging = true;
    if (nearestJoint) {
      preview.dragStartJointId = nearestJoint.id;
      preview.dragStartX = nearestJoint.x;
      preview.dragStartY = nearestJoint.y;
    } else {
      preview.dragStartJointId = null;
      preview.dragStartX = wx;
      preview.dragStartY = clampedY;
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const s = simRef.current;
    if (s.screen !== 'build') return;

    const rect = e.currentTarget.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;

    if (s.panDragging) {
      const dx = sx - s.panLastScreenX;
      const dy = sy - s.panLastScreenY;
      s.camera.x -= dx / s.camera.zoom;
      s.camera.y -= dy / s.camera.zoom;
      s.panLastScreenX = sx;
      s.panLastScreenY = sy;
      return;
    }

    const { wx, wy } = screenToWorld(sx, sy, s.camera, rect.width, rect.height);
    const clampedY = snapBuildY(wx, wy, s.mapId);
    const { nearestJoint, nearestEdgeId } = hitTestBlueprint(wx, wy);

    const preview = s.editorPreview;
    preview.pointerWorldX = wx;
    preview.pointerWorldY = clampedY;
    preview.hoveredJointId = nearestJoint?.id ?? null;
    preview.hoveredEdgeId = nearestEdgeId;

    if (preview.isDragging && tool === 'erase') {
      eraseAtWorldPos(wx, wy);
      return;
    }

    if (preview.isDragging && tool === 'move' && preview.dragStartJointId) {
      const moveId = preview.dragStartJointId;
      setBlueprint((prev) => ({
        ...prev,
        joints: prev.joints.map((j) =>
          j.id === moveId ? { ...j, x: wx, y: clampedY } : j
        ),
      }));
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const s = simRef.current;
    if (s.screen !== 'build') return;

    if (s.panDragging) {
      s.panDragging = false;
      return;
    }

    const preview = s.editorPreview;
    if (!preview.isDragging) return;
    preview.isDragging = false;

    if (tool === 'erase' || tool === 'move') {
      preview.dragStartJointId = null;
      return;
    }

    const rect = e.currentTarget.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const { wx, wy } = screenToWorld(sx, sy, s.camera, rect.width, rect.height);
    const clampedY = snapBuildY(wx, wy, s.mapId);
    const { nearestJoint } = hitTestBlueprint(wx, wy);

    const bp = cloneBlueprint(s.blueprint);
    const dragDist = Math.hypot(wx - preview.dragStartX, clampedY - preview.dragStartY);

    // Case A: Simple click/tap in empty space with Bone tool -> place standalone Joint
    if (dragDist < 12 && !preview.dragStartJointId && !nearestJoint) {
      const newId = `j_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
      bp.joints.push({ id: newId, x: wx, y: clampedY });
      soundEngine.playSnap(1.0);
      emitBurstParticles(wx, clampedY, 6, ['#10B981', '#0F172A'], 'spark', 0.6);
      pushBlueprintEdit(bp);
      preview.dragStartJointId = null;
      return;
    }

    // Ignore micro-clicks on the exact same joint
    if (
      dragDist < 12 &&
      preview.dragStartJointId &&
      nearestJoint?.id === preview.dragStartJointId
    ) {
      preview.dragStartJointId = null;
      return;
    }

    // Resolve Start Joint (existing or newly created)
    let startId = preview.dragStartJointId;
    if (!startId) {
      startId = `j_${Date.now()}_a`;
      bp.joints.push({
        id: startId,
        x: preview.dragStartX,
        y: preview.dragStartY,
      });
    }

    // Resolve End Joint (snap to existing if different from start, otherwise create new)
    let endId =
      nearestJoint && nearestJoint.id !== startId ? nearestJoint.id : null;
    if (!endId) {
      endId = `j_${Date.now()}_b`;
      bp.joints.push({
        id: endId,
        x: wx,
        y: clampedY,
      });
    }

    // Ensure no duplicate edge between startId and endId (upgrade/replace cleanly if needed)
    const existingIdx = bp.edges.findIndex(
      (ed) =>
        (ed.a === startId && ed.b === endId) || (ed.a === endId && ed.b === startId)
    );
    const kind = tool === 'muscle' ? 'muscle' : 'bone';
    if (existingIdx >= 0) {
      bp.edges[existingIdx] = { ...bp.edges[existingIdx], kind };
    } else {
      bp.edges.push({
        id: `e_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
        a: startId,
        b: endId,
        kind,
      });
    }

    if (kind === 'muscle') {
      soundEngine.playMuscleAttach();
      emitBurstParticles(wx, clampedY, 10, ['#F43F5E', '#FB7185'], 'spark', 0.8);
    } else {
      soundEngine.playSnap(1.1);
      emitBurstParticles(wx, clampedY, 8, ['#0F172A', '#10B981'], 'spark', 0.75);
    }

    pushBlueprintEdit(bp);
    preview.dragStartJointId = null;
  };

  return (
    <div
      className="relative w-screen h-screen overflow-hidden select-none bg-[#F5F5F7]"
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* Fullscreen High-DPI Interactive Physics & Blueprint Canvas */}
      <canvas
        ref={canvasRef}
        onWheel={handleWheel}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className={`block w-full h-full ${
          screen === 'build'
            ? tool === 'move'
              ? 'cursor-grab active:cursor-grabbing'
              : 'cursor-crosshair'
            : 'cursor-default'
        }`}
      />

      {/* Start Screen Overlay over Live Background Evolution */}
      {screen === 'start' && (
        <StartScreen
          selectedMap={mapId}
          onSelectMap={(nextMap) => {
            soundEngine.unlock();
            soundEngine.playSnap(1.05);
            const starter =
              selectedPresetIdx >= 0
                ? cloneBlueprint(CREATURE_PRESETS[selectedPresetIdx])
                : cloneBlueprint(CREATURE_PRESETS[0]);
            startNewEvolutionRun(starter, nextMap, 'start', true);
          }}
          selectedPresetIndex={selectedPresetIdx}
          onSelectPreset={(idx) => {
            soundEngine.unlock();
            soundEngine.playSnap(0.95);
            setSelectedPresetIdx(idx);
            if (idx >= 0) {
              const chosen = cloneBlueprint(CREATURE_PRESETS[idx]);
              startNewEvolutionRun(chosen, mapId, 'start', true);
            } else {
              // Blank scratchpad preview keeps background world calm until entering build
              setBlueprint({ name: 'Custom Specimen', joints: [], edges: [] });
            }
          }}
          highScores={highScores}
          muted={muted}
          onToggleMute={() => {
            const next = !muted;
            soundEngine.setMuted(next);
            setMuted(next);
          }}
          onStartBuild={() => {
            soundEngine.unlock();
            soundEngine.playSnap(1.15);
            const targetBp: CreatureBlueprint =
              selectedPresetIdx >= 0
                ? cloneBlueprint(CREATURE_PRESETS[selectedPresetIdx])
                : {
                    name: 'Custom Specimen',
                    joints: [
                      { id: 'j_init_1', x: -35, y: -55 },
                      { id: 'j_init_2', x: 35, y: -55 },
                    ],
                    edges: [
                      {
                        id: 'e_init_1',
                        a: 'j_init_1',
                        b: 'j_init_2',
                        kind: 'bone',
                      },
                    ],
                  };
            enterBuildMode(targetBp);
          }}
          onQuickEvolve={() => {
            soundEngine.unlock();
            soundEngine.playEvolveNext();
            const targetBp =
              selectedPresetIdx >= 0
                ? cloneBlueprint(CREATURE_PRESETS[selectedPresetIdx])
                : cloneBlueprint(CREATURE_PRESETS[0]);
            startNewEvolutionRun(targetBp, mapId, 'evolve', false);
          }}
          onOpenNeuralDashboard={openNeuralDashboard}
          customBlueprint={blueprint}
        />
      )}

      {/* Build Mode HUD & Tool Dock */}
      {screen === 'build' && (
        <EditorToolbar
          tool={tool}
          onSelectTool={(t) => {
            soundEngine.unlock();
            soundEngine.playSnap(1.0);
            setTool(t);
          }}
          blueprint={blueprint}
          mapId={mapId}
          onSelectMap={(m) => {
            soundEngine.playSnap(1.05);
            setMapId(m);
            simRef.current.mapId = m;
          }}
          canUndo={undoStack.length > 0}
          onUndo={handleUndo}
          onClear={() => {
            soundEngine.playErase();
            pushBlueprintEdit({
              name: 'Custom Specimen',
              joints: [],
              edges: [],
            });
          }}
          onAutoMuscle={() => {
            soundEngine.unlock();
            soundEngine.playMuscleAttach();
            const rigged = autoRigMuscles(blueprint);
            pushBlueprintEdit(rigged);
            addPopup(0, -135, 'MUSCLES AUTO-RIGGED', '#F43F5E');
          }}
          onLoadPreset={(idx) => {
            soundEngine.playSnap(1.1);
            pushBlueprintEdit(cloneBlueprint(CREATURE_PRESETS[idx]));
          }}
          onStartEvolution={() => {
            soundEngine.unlock();
            soundEngine.playEvolveNext();
            startNewEvolutionRun(blueprint, mapId, 'evolve', false);
          }}
          onOpenHome={() => {
            startNewEvolutionRun(
              blueprint.joints.length >= 2
                ? blueprint
                : cloneBlueprint(CREATURE_PRESETS[0]),
              mapId,
              'start',
              true
            );
          }}
          onOpenLeaderboard={() => setShowLeaderboardModal(true)}
          onOpenNeuralDashboard={openNeuralDashboard}
          muted={muted}
          onToggleMute={() => {
            const next = !muted;
            soundEngine.setMuted(next);
            setMuted(next);
          }}
        />
      )}

      {/* Active Evolution HUD */}
      {screen === 'evolve' && (
        <SimulationHUD
          mapId={mapId}
          generation={generation}
          maxChallengeGens={CHALLENGE_MAX_GENS}
          endlessMode={endlessMode}
          genTimeRemaining={genTimeRemaining}
          genDuration={GEN_DURATION_SEC}
          leaderDistanceM={leaderDistanceM}
          bestDistanceM={bestDistanceM}
          currentScore={currentScore}
          simSpeed={simSpeed}
          onSetSimSpeed={(spd) => {
            soundEngine.playSnap(1 + spd * 0.03);
            setSimSpeed(spd);
          }}
          boostCooldownRatio={boostCooldownRatio}
          boostActive={boostActiveUI}
          onTriggerBoost={triggerBoost}
          onNextGeneration={advanceGeneration}
          onFinishRun={() => finalizeRun('manual_finish')}
          onEditCreature={() => enterBuildMode()}
          onPause={() => setIsPaused(true)}
          onInstantRestart={() => {
            soundEngine.playSnap(1.1);
            startNewEvolutionRun(blueprint, mapId, 'evolve', endlessMode);
          }}
          showNeuralOverlay={showNeuralOverlay}
          onToggleNeuralOverlay={() => setShowNeuralOverlay((v) => !v)}
          onOpenNeuralDashboard={openNeuralDashboard}
          muted={muted}
          onToggleMute={() => {
            const next = !muted;
            soundEngine.setMuted(next);
            setMuted(next);
          }}
        />
      )}

      {/* Full Interactive Neural Network Inspector & Developer Architecture Dashboard */}
      {showNeuralDashboard && (
        <NeuralDashboard
          populationRef={simRef}
          isPaused={isPaused}
          onTogglePause={() => setIsPaused((prev) => !prev)}
          onStepSingleFrame={handleStepSingleFrame}
          onMutateCreatureLive={handleMutateCreatureLive}
          onClose={() => {
            setShowNeuralDashboard(false);
            setIsPaused(false);
          }}
        />
      )}

      {/* Pause, Game-Over / Goal Victory, and High-Score Modals */}
      {!showNeuralDashboard &&
        (isPaused || runEndReason !== null || showLeaderboardModal) && (
        <PauseAndGameOverModal
          mode={
            showLeaderboardModal
              ? 'leaderboard'
              : runEndReason !== null
              ? 'gameover'
              : 'paused'
          }
          runEndReason={runEndReason}
          mapId={mapId}
          creatureName={blueprint.name}
          onRenameCreature={(newName) => {
            setBlueprint((prev) => ({ ...prev, name: newName }));
            if (lastSavedScoreId) {
              const updatedList = renameHighScoreEntry(lastSavedScoreId, newName);
              setHighScores(updatedList);
            }
          }}
          generation={generation}
          bestDistanceM={bestDistanceM}
          finalScore={currentScore}
          isNewRecord={isNewRecord}
          history={genHistory}
          highScores={highScores}
          onResume={() => {
            setShowLeaderboardModal(false);
            setIsPaused(false);
          }}
          onInstantRestart={() => {
            soundEngine.playSnap(1.1);
            setShowLeaderboardModal(false);
            startNewEvolutionRun(blueprint, mapId, 'evolve', false);
          }}
          onContinueEndless={() => {
            soundEngine.playEvolveNext();
            simRef.current.endlessMode = true;
            simRef.current.runEnded = false;
            setEndlessMode(true);
            setRunEndReason(null);
            setIsPaused(false);
          }}
          onEditCreature={() => {
            setShowLeaderboardModal(false);
            enterBuildMode();
          }}
          onSwitchMap={(newMap) => {
            soundEngine.playSnap(1.1);
            startNewEvolutionRun(blueprint, newMap, 'evolve', endlessMode);
          }}
          onMainMenu={() => {
            setShowLeaderboardModal(false);
            startNewEvolutionRun(blueprint, mapId, 'start', true);
          }}
        />
      )}
    </div>
  );
}

export default App;
