import React, { useState } from 'react';
import { GeneratedNetwork } from '../lib/neuralEngine';
import { Card, LegendDot, Segmented } from './ui';

/* ------------------------------------------------------------------ */
/* Convergence: this network vs. a plain baseline MLP                  */
/* ------------------------------------------------------------------ */
export const ConvergenceChart: React.FC<{ network: GeneratedNetwork }> = ({
  network,
}) => {
  const [view, setView] = useState<'loss' | 'score'>('loss');
  const [hover, setHover] = useState<number | null>(null);

  const data = network.epochSeries;
  const W = 560;
  const H = 228;
  const padL = 42;
  const padR = 12;
  const padT = 14;
  const padB = 28;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;

  const isLoss = view === 'loss';
  const max = isLoss ? 1.6 : 5200;
  const ticks = isLoss
    ? [0, 0.4, 0.8, 1.2, 1.6]
    : [0, 1300, 2600, 3900, 5200];

  const x = (i: number) => padL + (i / (data.length - 1)) * plotW;
  const y = (v: number) =>
    padT + plotH - (Math.min(max, Math.max(0, v)) / max) * plotH;

  const smooth = (pts: { x: number; y: number }[]) => {
    if (!pts.length) return '';
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const mid = (pts[i].x + pts[i + 1].x) / 2;
      d += ` C ${mid} ${pts[i].y}, ${mid} ${pts[i + 1].y}, ${pts[i + 1].x} ${pts[i + 1].y}`;
    }
    return d;
  };

  const cur = data.map((d, i) => ({
    x: x(i),
    y: y(isLoss ? d.trainLoss : d.currentScore),
  }));
  const base = data.map((d, i) => ({
    x: x(i),
    y: y(isLoss ? d.baselineLoss : d.baselineScore),
  }));
  const areaPath = `${smooth(cur)} L ${cur[cur.length - 1].x} ${padT + plotH} L ${cur[0].x} ${padT + plotH} Z`;

  const active = hover !== null ? data[hover] : null;

  return (
    <Card
      tag="Convergence"
      title="Training curve vs. baseline"
      subtitle="Simulated epoch trajectory compared against a 2-layer baseline MLP."
      actions={
        <Segmented
          value={view}
          onChange={(v) => setView(v as 'loss' | 'score')}
          options={[
            { id: 'loss', label: 'Loss' },
            { id: 'score', label: 'Throughput' },
          ]}
        />
      }
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-4">
          <LegendDot color="var(--color-accent)" label="Active topology" />
          <LegendDot color="var(--color-warm)" label="Baseline MLP" />
        </div>
        {active && (
          <span className="tnum font-mono text-[11px] text-ink">
            {active.label}:{' '}
            {isLoss
              ? `${active.trainLoss.toFixed(3)} loss`
              : `${active.currentScore.toLocaleString()} tok/s`}
          </span>
        )}
      </div>

      <div className="overflow-x-auto">
        <svg
          viewBox={`0 0 ${W} ${H}`}
          className="w-full h-auto block select-none min-w-[440px]"
        >
          <defs>
            <linearGradient id="conv-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--color-accent)" stopOpacity="0.16" />
              <stop offset="100%" stopColor="var(--color-accent)" stopOpacity="0" />
            </linearGradient>
          </defs>

          {ticks.map((t, i) => (
            <g key={`t-${i}`}>
              <line
                x1={padL}
                y1={y(t)}
                x2={W - padR}
                y2={y(t)}
                stroke="var(--color-line)"
                strokeWidth={1}
                strokeDasharray={i === 0 ? undefined : '3 4'}
              />
              <text
                x={padL - 8}
                y={y(t) + 3.5}
                textAnchor="end"
                className="fill-faint text-[10px] tnum"
              >
                {isLoss ? t.toFixed(1) : t === 0 ? '0' : `${(t / 1000).toFixed(1)}k`}
              </text>
            </g>
          ))}

          <path d={areaPath} fill="url(#conv-fill)" />
          <path
            d={smooth(base)}
            fill="none"
            stroke="var(--color-warm)"
            strokeWidth={1.75}
            strokeDasharray="4 4"
            strokeLinecap="round"
          />
          <path
            d={smooth(cur)}
            fill="none"
            stroke="var(--color-accent)"
            strokeWidth={2.2}
            strokeLinecap="round"
          />

          {hover !== null && (
            <g>
              <line
                x1={cur[hover].x}
                y1={padT}
                x2={cur[hover].x}
                y2={padT + plotH}
                stroke="var(--color-faint)"
                strokeWidth={1}
                strokeDasharray="2 3"
              />
              <circle
                cx={base[hover].x}
                cy={base[hover].y}
                r={3.5}
                fill="var(--color-warm)"
              />
              <circle
                cx={cur[hover].x}
                cy={cur[hover].y}
                r={4}
                fill="var(--color-accent)"
                stroke="var(--color-surface)"
                strokeWidth={1.5}
              />
            </g>
          )}

          {data.map((d, i) => {
            const colW = plotW / data.length;
            return (
              <g key={d.label}>
                <text
                  x={x(i)}
                  y={H - 7}
                  textAnchor="middle"
                  className="fill-faint text-[10px]"
                >
                  {d.label}
                </text>
                <rect
                  x={x(i) - colW / 2}
                  y={padT}
                  width={colW}
                  height={plotH}
                  fill="transparent"
                  className="cursor-crosshair"
                  onMouseEnter={() => setHover(i)}
                  onMouseLeave={() => setHover(null)}
                />
              </g>
            );
          })}
        </svg>
      </div>
    </Card>
  );
};

/* ------------------------------------------------------------------ */
/* Weight norm vs gradient flow per layer                              */
/* ------------------------------------------------------------------ */
export const WeightGradientChart: React.FC<{ network: GeneratedNetwork }> = ({
  network,
}) => {
  const [hover, setHover] = useState<number | null>(null);

  const items = network.layerSummaries.map((s, i) => ({
    tag: `W${i + 1}`,
    name: s.name,
    w: Math.round(s.weightL2Norm * 260 + s.activeEdges * 14),
    g: Math.round(s.gradL2Norm * 1400 + s.biasesCount * 52),
    rawW: s.weightL2Norm,
    rawG: s.gradL2Norm,
  }));

  const W = 460;
  const H = 228;
  const padL = 42;
  const padR = 12;
  const padT = 14;
  const padB = 28;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;

  const maxBar = Math.max(1000, ...items.flatMap((i) => [i.w, i.g]));
  const top = Math.ceil(maxBar / 500) * 500;
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((t) => t * top);
  const y = (v: number) => padT + plotH - (Math.min(top, v) / top) * plotH;

  return (
    <Card
      tag="Diagnostics"
      title="Weight vs. gradient norm"
      subtitle="Forward weight magnitude (‖W‖₂) against backprop gradient norm per matrix."
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-4">
          <LegendDot color="var(--color-accent)" label="‖W‖₂" />
          <LegendDot color="var(--color-warm)" label="‖∇L‖₂" />
        </div>
        {hover !== null && items[hover] && (
          <span className="tnum font-mono text-[11px] text-ink">
            {items[hover].tag}: W={items[hover].rawW.toFixed(2)} ∇=
            {items[hover].rawG.toFixed(3)}
          </span>
        )}
      </div>

      <div className="overflow-x-auto">
        <svg
          viewBox={`0 0 ${W} ${H}`}
          className="w-full h-auto block select-none min-w-[380px]"
        >
          {ticks.map((t, i) => (
            <g key={`bt-${i}`}>
              <line
                x1={padL}
                y1={y(t)}
                x2={W - padR}
                y2={y(t)}
                stroke="var(--color-line)"
                strokeWidth={1}
                strokeDasharray={i === 0 ? undefined : '3 4'}
              />
              <text
                x={padL - 8}
                y={y(t) + 3.5}
                textAnchor="end"
                className="fill-faint text-[10px] tnum"
              >
                {t === 0 ? '0' : t >= 1000 ? `${(t / 1000).toFixed(1)}k` : Math.round(t)}
              </text>
            </g>
          ))}

          {items.map((item, i) => {
            const slot = plotW / items.length;
            const cx = padL + slot * i + slot / 2;
            const bw = Math.min(14, slot * 0.22);
            const gap = 3;
            const wY = y(item.w);
            const gY = y(item.g);
            const isHover = hover === i;

            return (
              <g
                key={item.tag}
                onMouseEnter={() => setHover(i)}
                onMouseLeave={() => setHover(null)}
                className="cursor-pointer"
              >
                {isHover && (
                  <rect
                    x={centerClamp(cx - bw - gap - 6)}
                    y={padT}
                    width={(bw + gap) * 2 + 12}
                    height={plotH}
                    rx={6}
                    fill="var(--color-surface-3)"
                  />
                )}
                <rect
                  x={cx - bw - gap / 2}
                  y={wY}
                  width={bw}
                  height={Math.max(3, padT + plotH - wY)}
                  rx={3}
                  fill="var(--color-accent)"
                  opacity={hover === null || isHover ? 1 : 0.45}
                />
                <rect
                  x={cx + gap / 2}
                  y={gY}
                  width={bw}
                  height={Math.max(3, padT + plotH - gY)}
                  rx={3}
                  fill="var(--color-warm)"
                  opacity={hover === null || isHover ? 1 : 0.45}
                />
                <text
                  x={cx}
                  y={H - 7}
                  textAnchor="middle"
                  className="fill-faint text-[10px] font-mono font-medium"
                >
                  {item.tag}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </Card>
  );
};

function centerClamp(v: number): number {
  return Math.max(0, v);
}

/* ------------------------------------------------------------------ */
/* Synaptic Weight Matrix Heatmap Inspector                            */
/* ------------------------------------------------------------------ */
export const WeightMatrixCard: React.FC<{ network: GeneratedNetwork }> = ({
  network,
}) => {
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [cellHover, setCellHover] = useState<{
    from: number;
    to: number;
    fromName: string;
    toName: string;
    w: number;
    grad: number;
  } | null>(null);

  const safeIdx = Math.min(selectedIdx, network.layerSummaries.length - 1);
  const summary = network.layerSummaries[safeIdx];
  const edges = network.edges.filter((e) => e.layerIndex === safeIdx);

  const fromNodes = network.nodes.filter((n) => n.layerIndex === safeIdx);
  const toNodes = network.nodes.filter((n) => n.layerIndex === safeIdx + 1);

  return (
    <Card
      tag="Weight matrix"
      title="Synaptic weights — W[to, from]"
      subtitle={`${summary.fromName} → ${summary.toName} (${summary.shapeTo}×${summary.shapeFrom})`}
      actions={
        <div className="inline-flex rounded-lg bg-surface-3 p-0.5 text-[11px] font-mono">
          {network.layerSummaries.map((s, idx) => (
            <button
              key={s.name + idx}
              type="button"
              onClick={() => setSelectedIdx(idx)}
              className={`px-2 py-0.5 rounded-[5px] cursor-pointer transition-colors ${
                safeIdx === idx
                  ? 'bg-surface text-ink font-semibold shadow-2xs'
                  : 'text-muted hover:text-ink'
              }`}
            >
              W{idx + 1}
            </button>
          ))}
        </div>
      }
    >
      <div className="flex flex-col justify-between h-full gap-3">
        <div className="overflow-x-auto py-1">
          <div
            className="inline-grid gap-1"
            style={{
              gridTemplateColumns: `repeat(${summary.shapeFrom}, minmax(38px, 1fr))`,
            }}
          >
            {Array.from({ length: summary.shapeTo }).map((_, toIdx) =>
              Array.from({ length: summary.shapeFrom }).map((__, fromIdx) => {
                const edge = edges.find(
                  (e) => e.fromIndex === fromIdx && e.toIndex === toIdx
                );
                const w = edge ? edge.weight : 0;
                const abs = Math.min(1, Math.abs(w) / 1.35);
                const bg = edge?.pruned
                  ? 'color-mix(in srgb, var(--color-faint) 10%, transparent)'
                  : w >= 0
                  ? `color-mix(in srgb, var(--color-accent) ${Math.round(
                      12 + abs * 66
                    )}%, var(--color-surface))`
                  : `color-mix(in srgb, var(--color-warm) ${Math.round(
                      14 + abs * 66
                    )}%, var(--color-surface))`;

                return (
                  <div
                    key={`m-${toIdx}-${fromIdx}`}
                    onMouseEnter={() =>
                      setCellHover({
                        from: fromIdx,
                        to: toIdx,
                        fromName:
                          fromNodes[fromIdx]?.featureName ||
                          fromNodes[fromIdx]?.id ||
                          `in[${fromIdx}]`,
                        toName:
                          toNodes[toIdx]?.featureName ||
                          toNodes[toIdx]?.id ||
                          `out[${toIdx}]`,
                        w,
                        grad: edge?.gradient ?? 0,
                      })
                    }
                    onMouseLeave={() => setCellHover(null)}
                    style={{ background: bg }}
                    className="h-8 rounded border border-line/80 flex items-center justify-center text-[10px] font-mono tnum text-ink cursor-crosshair transition-transform hover:scale-105"
                  >
                    {w >= 0 ? `+${w.toFixed(2)}` : w.toFixed(2)}
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="pt-2.5 border-t border-line flex items-center justify-between gap-2 text-[11px] font-mono text-muted">
          {cellHover ? (
            <span className="text-ink truncate">
              {cellHover.fromName} → {cellHover.toName}:{' '}
              <strong>w={cellHover.w.toFixed(3)}</strong> · ∂L/∂w=
              {cellHover.grad.toFixed(4)}
            </span>
          ) : (
            <span className="truncate">
              Hover any cell to inspect exact float weight &amp; gradient
            </span>
          )}
          <span className="shrink-0 tnum">‖W‖₂={summary.weightL2Norm.toFixed(2)}</span>
        </div>
      </div>
    </Card>
  );
};

/* ------------------------------------------------------------------ */
/* Capacity distribution per layer                                    */
/* ------------------------------------------------------------------ */
export const LayerCapacityChart: React.FC<{ network: GeneratedNetwork }> = ({
  network,
}) => {
  const [mode, setMode] = useState<'params' | 'activation'>('params');
  const maxAct = Math.max(
    0.0001,
    ...network.layerSummaries.map((s) => s.meanActivation)
  );

  return (
    <Card
      tag="Capacity"
      title="Capacity & activation distribution"
      subtitle="Parameter share and mean activation intensity across matrix transitions."
      actions={
        <Segmented
          value={mode}
          onChange={(v) => setMode(v as 'params' | 'activation')}
          options={[
            { id: 'params', label: 'Params' },
            { id: 'activation', label: 'Act.' },
          ]}
        />
      }
    >
      <div className="space-y-3">
        {network.layerSummaries.map((s) => {
          const pct =
            mode === 'params'
              ? s.paramSharePct
              : Math.min(100, (s.meanActivation / maxAct) * 100);
          const value =
            mode === 'params'
              ? `${s.params.toLocaleString()}p · ${s.paramSharePct.toFixed(1)}%`
              : `${s.meanActivation.toFixed(3)} μ`;
          return (
            <div key={s.name + s.index}>
              <div className="flex items-baseline justify-between gap-3 mb-1">
                <div className="flex items-baseline gap-2 min-w-0">
                  <span className="text-[12px] font-semibold text-ink truncate">
                    {s.fromName} → {s.toName}
                  </span>
                  <span className="hidden sm:inline font-mono text-[10.5px] text-faint">
                    {s.tensorShape}
                  </span>
                </div>
                <span className="tnum font-mono text-[11.5px] text-ink shrink-0">
                  {value}
                </span>
              </div>
              <div className="h-1.5 rounded-full bg-surface-3 overflow-hidden">
                <div
                  className="h-full rounded-full bg-accent transition-[width] duration-300"
                  style={{ width: `${Math.max(4, pct)}%` }}
                />
              </div>
              <div className="mt-1 flex justify-between text-[10px] font-mono text-faint">
                <span>
                  {s.activeEdges}/{s.totalEdges} active edges
                </span>
                <span>{s.flops.toLocaleString()} FLOPs</span>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
};
