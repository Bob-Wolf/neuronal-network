import React from 'react';

/* Calm Apple-style card: white surface, hairline border, soft depth,
   continuous corner radius, quiet header. */
export const Card: React.FC<{
  title?: string;
  subtitle?: string;
  tag?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  bodyClassName?: string;
}> = ({
  title,
  subtitle,
  tag,
  actions,
  children,
  className = '',
  bodyClassName = '',
}) => (
  <section
    className={`bg-surface border border-line/60 rounded-[18px] shadow-card flex flex-col overflow-hidden transition-shadow hover:shadow-lift ${className}`}
  >
    {(title || actions) && (
      <header className="flex flex-wrap items-start justify-between gap-x-3 gap-y-2 px-5 pt-4 pb-3">
        <div className="min-w-0">
          {tag && (
            <div className="text-[10.5px] font-semibold text-faint mb-1">
              {tag}
            </div>
          )}
          {title && (
            <h2 className="text-[14px] font-semibold tracking-[-0.01em] text-ink leading-tight">
              {title}
            </h2>
          )}
          {subtitle && (
            <p className="text-[12px] text-muted mt-0.5 leading-snug">
              {subtitle}
            </p>
          )}
        </div>
        {actions && (
          <div className="flex items-center gap-1.5 shrink-0 -mt-0.5">
            {actions}
          </div>
        )}
      </header>
    )}
    <div className={`p-5 pt-4 flex-1 ${bodyClassName}`}>{children}</div>
  </section>
);

/* Digital instrument readout for the unified telemetry strip */
export const TelemetryCell: React.FC<{
  label: string;
  value: string;
  unit?: string;
  sub?: string;
  accent?: 'accent' | 'warm' | 'good' | 'ink';
}> = ({ label, value, unit, sub, accent = 'ink' }) => {
  const valueColor =
    accent === 'accent'
      ? 'text-accent-strong'
      : accent === 'warm'
      ? 'text-warm-strong'
      : accent === 'good'
      ? 'text-good'
      : 'text-ink';

  return (
    <div className="px-5 py-3 flex flex-col justify-center min-w-0">
      <div className="text-[11px] font-medium text-faint truncate">
        {label}
      </div>
      <div className="mt-1 flex items-baseline gap-1 min-w-0">
        <span
          className={`tnum font-mono text-[21px] font-semibold leading-none tracking-[-0.01em] truncate ${valueColor}`}
        >
          {value}
        </span>
        {unit && (
          <span className="text-[11.5px] font-medium text-muted shrink-0">
            {unit}
          </span>
        )}
      </div>
      {sub && (
        <div className="text-[10.5px] text-faint mt-1 truncate">{sub}</div>
      )}
    </div>
  );
};

/* Apple-style quiet section header: small number, bold title, gray note */
export const SectionHeader: React.FC<{
  index: string;
  title: string;
  description?: string;
  right?: React.ReactNode;
}> = ({ index, title, description, right }) => (
  <div className="flex flex-wrap items-baseline justify-between gap-2 pt-1">
    <div className="flex items-baseline gap-2.5 min-w-0">
      <span className="font-mono text-[11px] font-medium text-faint">
        {index}
      </span>
      <h2 className="text-[17px] font-semibold tracking-[-0.02em] text-ink">
        {title}
      </h2>
      {description && (
        <span className="hidden md:inline text-[12.5px] text-muted truncate">
          {description}
        </span>
      )}
    </div>
    {right && <div>{right}</div>}
  </div>
);

/* Apple-style segmented control */
export const Segmented: React.FC<{
  options: { id: string; label: string }[];
  value: string;
  onChange: (id: string) => void;
}> = ({ options, value, onChange }) => (
  <div className="inline-flex rounded-[9px] bg-surface-3/80 p-0.5 text-[11.5px] font-medium">
    {options.map((o) => (
      <button
        key={o.id}
        type="button"
        onClick={() => onChange(o.id)}
        className={`px-2.5 py-1 rounded-[7px] transition-all cursor-pointer ${
          value === o.id
            ? 'bg-surface text-ink shadow-[0_1px_3px_rgba(0,0,0,0.1)]'
            : 'text-muted hover:text-ink'
        }`}
      >
        {o.label}
      </button>
    ))}
  </div>
);

export const LegendDot: React.FC<{ color: string; label: string }> = ({
  color,
  label,
}) => (
  <span className="inline-flex items-center gap-1.5 text-[11.5px] text-muted">
    <span className="w-2 h-2 rounded-full" style={{ background: color }} />
    {label}
  </span>
);
