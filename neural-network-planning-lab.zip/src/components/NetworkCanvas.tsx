import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivationType,
  GeneratedNetwork,
  InitStrategy,
  NETWORK_PRESETS,
  NetworkConfig,
  NeuronNode,
  PresetItem,
  activationLabel,
  addHiddenLayerToConfig,
  addInputNodeToConfig,
  addOutputNodeToConfig,
  denormalizeToRawValue,
  removeHiddenLayerFromConfig,
  removeInputNodeFromConfig,
  removeOutputNodeFromConfig,
  updateInputNodeInConfig,
  updateLayerSpecInConfig,
} from '../lib/neuralEngine';
import {
  ChevronDown,
  Compass,
  Filter,
  Minus,
  Pause,
  Play,
  Plus,
  RefreshCw,
  RotateCcw,
  X,
} from 'lucide-react';
import { TelemetryCell } from './ui';

interface NetworkCanvasProps {
  network: GeneratedNetwork;
  onChangeConfig: (updater: (prev: NetworkConfig) => NetworkConfig) => void;
  onSelectPreset: (preset: PresetItem) => void;
  onAdjustLayerSize: (layerIdx: number, delta: number) => void;
  onRemoveHiddenLayer: (hiddenIdx: number) => void;
  onOpenPlanner: () => void;
}

type Inspector =
  | { kind: 'node'; id: string }
  | { kind: 'edge'; id: string }
  | { kind: 'none' };

export const NetworkCanvas: React.FC<NetworkCanvasProps> = ({
  network,
  onChangeConfig,
  onSelectPreset,
  onAdjustLayerSize,
  onRemoveHiddenLayer,
  onOpenPlanner,
}) => {
  const [inspect, setInspect] = useState<Inspector>({ kind: 'none' });
  const [playhead, setPlayhead] = useState<number | null>(null);
  const [playing, setPlaying] = useState(false);
  const [edgeThreshold, setEdgeThreshold] = useState(0);
  const [showPruned, setShowPruned] = useState(false);

  const {
    config,
    resolvedSpecs,
    resolvedInputSpecs,
    resolvedOutputSpecs,
    metrics: m,
  } = network;

  const activePreset = NETWORK_PRESETS.find((p) => p.config.name === config.name);

  // Clean coordinate space for center SVG stage
  const svgW = 860;
  const svgH = 446;
  const padLeft = 148;
  const padRight = 166;
  const padTop = 74;
  const padBottom = 54;

  const { coords, groups } = useMemo(() => {
    const numLayers = network.layerSizes.length;
    const g: NeuronNode[][] = Array.from({ length: numLayers }, () => []);
    network.nodes.forEach((n) => g[n.layerIndex].push(n));

    const c = new Map<string, { x: number; y: number }>();
    const usableW = svgW - padLeft - padRight;
    const usableH = svgH - padTop - padBottom;

    g.forEach((layerNodes, l) => {
      const x =
        numLayers === 1 ? svgW / 2 : padLeft + (l / (numLayers - 1)) * usableW;
      const count = layerNodes.length;
      layerNodes.forEach((node, i) => {
        const y =
          count === 1
            ? padTop + usableH / 2
            : padTop + ((i + 0.5) / count) * usableH;
        c.set(node.id, { x, y });
      });
    });

    return { coords: c, groups: g };
  }, [network.nodes, network.layerSizes]);

  useEffect(() => {
    if (playhead !== null && playhead >= network.layerSizes.length) {
      setPlayhead(null);
      setPlaying(false);
    }
  }, [playhead, network.layerSizes.length]);

  useEffect(() => {
    if (!playing) return;
    const layers = network.layerSizes.length;
    const id = window.setInterval(() => {
      setPlayhead((prev) => {
        const next = prev === null ? 0 : prev + 1;
        if (next >= layers - 1) {
          setPlaying(false);
          return layers - 1;
        }
        return next;
      });
    }, 900);
    return () => window.clearInterval(id);
  }, [playing, network.layerSizes.length]);

  const startPlay = () => {
    if (playing) {
      setPlaying(false);
      return;
    }
    setPlayhead(0);
    setPlaying(true);
  };

  const resetPlay = () => {
    setPlaying(false);
    setPlayhead(null);
  };

  const visibleEdges = useMemo(
    () =>
      network.edges.filter((e) => {
        if (e.pruned) return showPruned;
        return Math.abs(e.rawWeight) >= edgeThreshold;
      }),
    [network.edges, edgeThreshold, showPruned]
  );

  const activeNode = useMemo(() => {
    if (inspect.kind !== 'node') return undefined;
    return network.nodes.find((n) => n.id === inspect.id);
  }, [inspect, network.nodes]);

  const activeEdge = useMemo(() => {
    if (inspect.kind !== 'edge') return undefined;
    return network.edges.find((e) => e.id === inspect.id);
  }, [inspect, network.edges]);

  const outputNodes = useMemo(
    () => network.nodes.filter((n) => n.layerType === 'output'),
    [network.nodes]
  );

  const dimOthers = playhead !== null;
  const nodeRadius = network.layerSizes.some((s) => s > 8) ? 14 : 16.5;
  const lastStageIdx = network.layerSizes.length - 1;

  return (
    <section className="bg-surface border border-line/60 rounded-[20px] overflow-hidden shadow-card">
      {/* =================================================================== */}
      {/* 1. UNIFIED 6-CELL DIGITAL TELEMETRY RIBBON                          */}
      {/* =================================================================== */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 divide-x divide-y lg:divide-y-0 divide-line border-b border-line bg-surface-2/80">
        <TelemetryCell
          label="Topology"
          value={network.layerSizes.join(' → ')}
          sub={`${config.hiddenLayers.length} hidden ${
            config.hiddenLayers.length === 1 ? 'stage' : 'stages'
          }`}
        />
        <TelemetryCell
          label="Parameters"
          value={m.totalParams.toLocaleString()}
          sub={`${m.trainableParams.toLocaleString()} trainable${
            m.frozenParams > 0 ? ` · ${m.frozenParams} frz` : ''
          }`}
        />
        <TelemetryCell
          label="Val accuracy"
          value={m.valAccuracyPct.toFixed(2)}
          unit="%"
          accent="accent"
          sub="modelled estimate"
        />
        <TelemetryCell
          label="Latency p95"
          value={m.estimatedLatencyMs.toFixed(2)}
          unit="ms"
          sub="batch = 1 · CPU"
        />
        <TelemetryCell
          label="Compute / pass"
          value={m.totalFlops.toLocaleString()}
          unit="FLOPs"
          sub={`${m.memoryKB.toFixed(2)} KB FP32`}
        />
        <TelemetryCell
          label="Active synapses"
          value={m.activeDensityPct.toFixed(1)}
          unit="%"
          accent="warm"
          sub={`${m.sparsityPct.toFixed(1)}% pruned`}
        />
      </div>

      {/* =================================================================== */}
      {/* 2. ARCHITECTURE CHAIN & EXECUTION CONTROL BAR                       */}
      {/* =================================================================== */}
      <div className="px-4 py-2.5 border-b border-line bg-surface flex flex-wrap items-center justify-between gap-2.5">
        {/* Left: Preset Switcher + Editable Architecture Chain */}
        <div className="flex flex-wrap items-center gap-1.5 min-w-0">
          <div className="relative mr-1">
            <select
              value={activePreset?.id ?? 'custom'}
              onChange={(e) => {
                const found = NETWORK_PRESETS.find((p) => p.id === e.target.value);
                if (found) onSelectPreset(found);
              }}
              aria-label="Select neural network preset"
              className="appearance-none pl-3 pr-7 py-1.5 rounded-[10px] bg-surface-3/60 border border-line/60 text-[12px] font-medium text-ink cursor-pointer focus:outline-none focus:border-accent/50"
            >
              {NETWORK_PRESETS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title} ({p.badge})
                </option>
              ))}
              <option value="custom">Custom · {config.name}</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-faint pointer-events-none" />
          </div>

          {/* Input stage pill */}
          <StagePill
            label={resolvedSpecs[0]?.name ?? 'Inputs'}
            count={config.inputNodes}
            tone="input"
            onRename={(name) =>
              onChangeConfig((prev) => updateLayerSpecInConfig(prev, 0, { name }))
            }
            onStep={(d) =>
              onChangeConfig((prev) =>
                d > 0
                  ? addInputNodeToConfig(prev)
                  : removeInputNodeFromConfig(prev, prev.inputNodes - 1)
              )
            }
          />

          {/* Hidden layer pills */}
          {config.hiddenLayers.map((h, i) => (
            <React.Fragment key={resolvedSpecs[i + 1]?.id ?? `pill-${i}`}>
              <ChainArrow />
              <StagePill
                label={resolvedSpecs[i + 1]?.name ?? `Hidden ${i + 1}`}
                count={h}
                tone="hidden"
                frozen={resolvedSpecs[i + 1]?.frozen}
                onRename={(name) =>
                  onChangeConfig((prev) =>
                    updateLayerSpecInConfig(prev, i + 1, { name })
                  )
                }
                onStep={(d) =>
                  onChangeConfig((prev) => {
                    const hidden = [...prev.hiddenLayers];
                    hidden[i] = Math.max(1, Math.min(12, hidden[i] + d));
                    return { ...prev, hiddenLayers: hidden };
                  })
                }
                onRemove={() => onRemoveHiddenLayer(i)}
              />
            </React.Fragment>
          ))}

          {/* Output stage pill */}
          <ChainArrow />
          <StagePill
            label={resolvedSpecs[resolvedSpecs.length - 1]?.name ?? 'Outputs'}
            count={config.outputNodes}
            tone="output"
            onRename={(name) =>
              onChangeConfig((prev) =>
                updateLayerSpecInConfig(prev, resolvedSpecs.length - 1, { name })
              )
            }
            onStep={(d) =>
              onChangeConfig((prev) =>
                d > 0
                  ? addOutputNodeToConfig(prev)
                  : removeOutputNodeFromConfig(prev, prev.outputNodes - 1)
              )
            }
          />

          {/* Quick +layer / -layer triggers */}
          <div className="inline-flex items-center gap-1 ml-1">
            <button
              type="button"
              onClick={() => onChangeConfig((prev) => addHiddenLayerToConfig(prev, 6))}
              disabled={config.hiddenLayers.length >= 6}
              title="Add hidden layer"
              className="px-2.5 py-1 rounded-full text-[11.5px] font-medium text-muted hover:text-ink hover:bg-surface-3 transition-colors disabled:opacity-35 cursor-pointer"
            >
              + layer
            </button>
            <button
              type="button"
              onClick={() =>
                onChangeConfig((prev) =>
                  removeHiddenLayerFromConfig(prev, prev.hiddenLayers.length - 1)
                )
              }
              disabled={config.hiddenLayers.length === 0}
              title="Remove last hidden layer"
              className="px-2.5 py-1 rounded-full text-[11.5px] font-medium text-muted hover:text-warm-strong hover:bg-surface-3 transition-colors disabled:opacity-35 cursor-pointer"
            >
              − layer
            </button>
          </div>
        </div>

        {/* Right: Execution & Blueprint Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() =>
              onChangeConfig((prev) => ({ ...prev, seed: prev.seed + 29 }))
            }
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-surface-3/70 text-[11.5px] font-medium text-ink hover:bg-surface-3 transition-colors cursor-pointer"
            title="Reseed random weights"
          >
            <RefreshCw className="w-3.5 h-3.5 text-accent" />
            <span className="hidden sm:inline">Reseed</span>
          </button>

          <button
            type="button"
            onClick={onOpenPlanner}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-surface-3/70 text-[11.5px] font-medium text-ink hover:bg-surface-3 transition-colors cursor-pointer"
          >
            <Compass className="w-3.5 h-3.5 text-accent" />
            <span>Plan I/O &amp; layers</span>
          </button>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={startPlay}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-accent text-white text-[12px] font-semibold hover:bg-accent-strong transition-colors cursor-pointer"
            >
              {playing ? (
                <Pause className="w-3.5 h-3.5" />
              ) : (
                <Play className="w-3.5 h-3.5" />
              )}
              <span>{playing ? 'Pause' : 'Run pass'}</span>
            </button>
            {playhead !== null && (
              <button
                type="button"
                onClick={resetPlay}
                title="Reset step highlight"
                className="p-1.5 rounded-full border border-line/70 bg-surface text-muted hover:text-ink cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* =================================================================== */}
      {/* 3. THREE-PANE INTERACTIVE LAB STAGE: INPUTS ──▶ GRAPH ──▶ OUTPUTS   */}
      {/* =================================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-[248px_minmax(0,1fr)_272px]">
        {/* ---------------- LEFT DOCK: LIVE INPUT PROBES ---------------- */}
        <div className="border-b lg:border-b-0 lg:border-r border-line bg-surface-2/55 flex flex-col justify-between">
          <div className="p-3.5">
            <div className="flex items-center justify-between mb-2.5">
              <div>
                <div className="micro text-faint">
                  Input signals ({resolvedInputSpecs.length})
                </div>
                <div className="text-[11px] text-muted mt-0.5">
                  Drag values to test forward pass
                </div>
              </div>
              <button
                type="button"
                onClick={() => onChangeConfig((prev) => addInputNodeToConfig(prev))}
                disabled={resolvedInputSpecs.length >= 12}
                title="Add a new input signal"
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-accent text-white text-[11px] font-semibold hover:bg-accent-strong transition-colors disabled:opacity-40 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>Add</span>
              </button>
            </div>

            <div className="space-y-2 max-h-[385px] overflow-y-auto pr-0.5">
              {resolvedInputSpecs.map((inp, idx) => {
                const nodeId = `L0-N${idx}`;
                const isHighlighted =
                  inspect.kind === 'node' && inspect.id === nodeId;
                const normVal = config.inputVector[idx] ?? 0;

                return (
                  <div
                    key={inp.id}
                    onMouseEnter={() => setInspect({ kind: 'node', id: nodeId })}
                    onMouseLeave={() =>
                      setInspect((p) =>
                        p.kind === 'node' && p.id === nodeId ? { kind: 'none' } : p
                      )
                    }
                    className={`rounded-[12px] border p-2.5 transition-colors ${
                      isHighlighted
                        ? 'bg-surface border-accent/60 shadow-card'
                        : 'bg-surface-2 border-line/60 hover:border-accent/40'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1.5 mb-1.5">
                      <span
                        className="font-mono text-[11.5px] font-semibold text-ink truncate"
                        title={inp.description || inp.name}
                      >
                        {inp.name}
                      </span>
                      <span className="tnum font-mono text-[10.5px] px-1.5 py-0.5 rounded bg-surface border border-line/60 text-muted shrink-0">
                        {inp.kind === 'binary'
                          ? inp.rawValue >= 0.5
                            ? '1 (True)'
                            : '0 (False)'
                          : `${inp.rawValue}${inp.unit ? ` ${inp.unit}` : ''}`}
                      </span>
                    </div>

                    {inp.kind === 'binary' ? (
                      <div className="flex items-center justify-between gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            onChangeConfig((prev) =>
                              updateInputNodeInConfig(prev, idx, {
                                rawValue: inp.rawValue >= 0.5 ? 0 : 1,
                              })
                            )
                          }
                          className={`flex-1 py-1 rounded text-[11px] font-mono font-medium border cursor-pointer ${
                            inp.rawValue >= 0.5
                              ? 'bg-good/15 border-good/45 text-good'
                              : 'bg-surface-2 border-line text-muted'
                          }`}
                        >
                          {inp.rawValue >= 0.5 ? 'State: ON (1.0)' : 'State: OFF (0.0)'}
                        </button>
                        <span className="tnum font-mono text-[10px] text-faint">
                          x={normVal.toFixed(1)}
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <input
                          type="range"
                          min={inp.min}
                          max={inp.max}
                          step={
                            Math.abs(inp.max - inp.min) > 20
                              ? 1
                              : Math.abs(inp.max - inp.min) > 2
                              ? 0.1
                              : 0.01
                          }
                          value={inp.rawValue}
                          aria-label={`${inp.name} value`}
                          onChange={(e) =>
                            onChangeConfig((prev) =>
                              updateInputNodeInConfig(prev, idx, {
                                rawValue: Number(e.target.value),
                              })
                            )
                          }
                          className="flex-1"
                        />
                        <span
                          title="Normalized tensor coordinate [-1..1]"
                          className="tnum font-mono text-[10px] text-faint w-10 text-right shrink-0"
                        >
                          {normVal >= 0 ? `+${normVal.toFixed(2)}` : normVal.toFixed(2)}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="px-3.5 py-2.5 border-t border-line flex items-center justify-between text-[11px] text-muted">
            <span>Input tensor shape</span>
            <span className="tnum font-mono font-semibold text-ink">
              [B, {resolvedInputSpecs.length}]
            </span>
          </div>
        </div>

        {/* ---------------- CENTER STAGE: INTERACTIVE TOPOLOGY GRAPH ---------------- */}
        <div className="relative graph-paper flex flex-col justify-between overflow-hidden">
          {/* Subtle Floating HUD Bar inside Graph Canvas */}
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2 border-b border-line-soft bg-surface/85 backdrop-blur-xs text-[11px]">
            <div className="flex flex-wrap items-center gap-3.5 text-muted">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-accent" />
                <span>+w excitatory</span>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-warm" />
                <span>−w inhibitory</span>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-good" />
                <span>★ active output</span>
              </span>
            </div>

            <div className="flex items-center gap-2">
              <label className="inline-flex items-center gap-1.5 text-[11px] text-muted">
                <Filter className="w-3 h-3 text-accent" />
                <span>|w| ≥</span>
                <input
                  type="range"
                  min={0}
                  max={1.2}
                  step={0.05}
                  value={edgeThreshold}
                  onChange={(e) => setEdgeThreshold(Number(e.target.value))}
                  className="w-16"
                  title="Filter weak connections on canvas"
                />
                <span className="tnum font-mono text-ink w-7 text-right">
                  {edgeThreshold.toFixed(2)}
                </span>
              </label>

              <button
                type="button"
                onClick={() => setShowPruned((s) => !s)}
                className={`px-2 py-0.5 rounded text-[10.5px] font-medium border transition-colors cursor-pointer ${
                  showPruned
                    ? 'bg-accent-soft border-accent/35 text-accent-strong'
                    : 'bg-surface-2 border-line text-muted hover:text-ink'
                }`}
              >
                Pruned ({m.sparsityPct}%)
              </button>
            </div>
          </div>

          {/* Responsive Vector Stage */}
          <div className="overflow-x-auto flex-1 flex items-center">
            <svg
              viewBox={`0 0 ${svgW} ${svgH}`}
              className="w-full h-auto block select-none min-w-[680px]"
              role="img"
              aria-label="Neural network topology graph"
            >
              {/* Active playhead layer band */}
              {groups.map((layerNodes, l) => {
                const first = coords.get(layerNodes[0]?.id);
                if (!first) return null;
                const bandW = 88;
                const isActive = playhead === l;
                return (
                  <rect
                    key={`band-${l}`}
                    x={first.x - bandW / 2}
                    y={padTop - 24}
                    width={bandW}
                    height={svgH - padTop - padBottom + 48}
                    rx={12}
                    fill="var(--color-accent)"
                    opacity={isActive ? 0.075 : 0}
                    className="transition-opacity duration-300"
                  />
                );
              })}

              {/* Column headers & bottom neuron steppers */}
              {groups.map((layerNodes, l) => {
                const first = coords.get(layerNodes[0]?.id);
                if (!first) return null;
                const transition = network.layerSummaries[l - 1];
                const spec = network.resolvedSpecs[l];
                const isInput = l === 0;
                const isOutput = l === groups.length - 1;
                const isHidden = !isInput && !isOutput;
                const label =
                  spec?.name ||
                  (isInput ? 'Inputs' : isOutput ? 'Outputs' : `Hidden ${l}`);
                const sub = isInput
                  ? `${layerNodes.length} in`
                  : isOutput
                  ? `${layerNodes.length} out`
                  : `${layerNodes.length}u · ${transition?.params ?? 0}p`;

                return (
                  <g key={`head-${l}`}>
                    <text
                      x={first.x}
                      y={22}
                      textAnchor="middle"
                      className="fill-ink text-[11.5px] font-semibold"
                    >
                      {label.length > 15 ? `${label.slice(0, 14)}…` : label}
                    </text>
                    <text
                      x={first.x}
                      y={36}
                      textAnchor="middle"
                      className="fill-muted text-[10px] font-mono"
                    >
                      {sub}
                    </text>

                    {isHidden && (
                      <g
                        transform={`translate(${first.x}, 50)`}
                        onClick={() => onRemoveHiddenLayer(l - 1)}
                        className="cursor-pointer opacity-75 hover:opacity-100"
                      >
                        <title>{`Remove layer "${label}"`}</title>
                        <rect
                          x={-25}
                          y={-7}
                          width={50}
                          height={14}
                          rx={4}
                          fill="var(--color-surface)"
                          stroke="var(--color-line)"
                        />
                        <text
                          x={0}
                          y={3}
                          textAnchor="middle"
                          className="fill-muted hover:fill-warm-strong text-[9.5px] font-mono"
                        >
                          × remove
                        </text>
                      </g>
                    )}

                    <line
                      x1={first.x}
                      y1={padTop - 16}
                      x2={first.x}
                      y2={svgH - padBottom + 22}
                      stroke="var(--color-line)"
                      strokeWidth={1}
                      strokeDasharray="2 6"
                    />

                    {/* Bottom - / N / + steppers */}
                    <g
                      transform={`translate(${first.x - 27}, ${svgH - padBottom + 36})`}
                      className="cursor-pointer"
                      onClick={() => onAdjustLayerSize(l, -1)}
                    >
                      <rect
                        x={-9}
                        y={-9}
                        width={18}
                        height={17}
                        rx={4.5}
                        fill="var(--color-surface)"
                        stroke="var(--color-line)"
                      />
                      <text
                        x={0}
                        y={3}
                        textAnchor="middle"
                        className="fill-muted text-[11.5px] font-semibold"
                      >
                        −
                      </text>
                    </g>
                    <text
                      x={first.x}
                      y={svgH - padBottom + 40}
                      textAnchor="middle"
                      className="fill-ink text-[11.5px] font-mono font-semibold"
                    >
                      {layerNodes.length}
                    </text>
                    <g
                      transform={`translate(${first.x + 27}, ${svgH - padBottom + 36})`}
                      className="cursor-pointer"
                      onClick={() => onAdjustLayerSize(l, 1)}
                    >
                      <rect
                        x={-9}
                        y={-9}
                        width={18}
                        height={17}
                        rx={4.5}
                        fill="var(--color-surface)"
                        stroke="var(--color-line)"
                      />
                      <text
                        x={0}
                        y={3}
                        textAnchor="middle"
                        className="fill-muted text-[11.5px] font-semibold"
                      >
                        +
                      </text>
                    </g>
                  </g>
                );
              })}

              {/* Synaptic Bezier Curves */}
              {visibleEdges.map((edge) => {
                const a = coords.get(edge.sourceId);
                const b = coords.get(edge.targetId);
                if (!a || !b) return null;

                const connected =
                  playhead === null ||
                  edge.sourceId.startsWith(`L${playhead}-`) ||
                  edge.targetId.startsWith(`L${playhead}-`);
                const inspected =
                  inspect.kind === 'edge' && inspect.id === edge.id;
                const relatedToNode =
                  inspect.kind === 'node' &&
                  (edge.sourceId === inspect.id || edge.targetId === inspect.id);

                const mag = Math.min(1.6, Math.abs(edge.rawWeight));
                const opacity = edge.pruned
                  ? 0.25
                  : 0.12 + (mag / 1.6) * 0.52;
                const finalOpacity =
                  inspected || relatedToNode
                    ? 0.98
                    : dimOthers
                    ? connected
                      ? 0.85
                      : 0.05
                    : inspect.kind === 'node'
                    ? 0.08
                    : opacity;

                const stroke = edge.pruned
                  ? 'var(--color-faint)'
                  : edge.weight >= 0
                  ? 'var(--color-accent)'
                  : 'var(--color-warm)';

                const width = edge.pruned
                  ? 0.9
                  : (inspected || relatedToNode ? 1.15 : 0) + 0.55 + mag * 0.85;

                const mid = (a.x + b.x) / 2;
                const d = `M ${a.x} ${a.y} C ${mid} ${a.y}, ${mid} ${b.y}, ${b.x} ${b.y}`;

                return (
                  <g key={edge.id}>
                    <path
                      d={d}
                      fill="none"
                      stroke={stroke}
                      strokeWidth={width}
                      strokeOpacity={finalOpacity}
                      strokeDasharray={
                        edge.pruned ? '2 5' : edge.frozen ? '6 3' : undefined
                      }
                      strokeLinecap="round"
                      className={
                        !edge.pruned &&
                        !edge.frozen &&
                        (connected || !dimOthers) &&
                        (inspect.kind !== 'node' || relatedToNode)
                          ? 'animate-signal-flow'
                          : undefined
                      }
                    />
                    <path
                      d={d}
                      fill="none"
                      stroke="transparent"
                      strokeWidth={9}
                      className="cursor-pointer"
                      onMouseEnter={() => setInspect({ kind: 'edge', id: edge.id })}
                      onMouseLeave={() =>
                        setInspect((p) =>
                          p.kind === 'edge' ? { kind: 'none' } : p
                        )
                      }
                    />
                  </g>
                );
              })}

              {/* Neurons + Single Input & Single Output Callouts */}
              {network.nodes.map((node) => {
                const p = coords.get(node.id);
                if (!p) return null;
                const inspected =
                  inspect.kind === 'node' && inspect.id === node.id;
                const inPlayhead = playhead === node.layerIndex;
                const dim = dimOthers && !inPlayhead && !inspected;
                const neg = node.activation < 0;
                const hue = neg ? 'var(--color-warm)' : 'var(--color-accent)';
                const strength = Math.min(1, Math.abs(node.activation));

                const isInputNode = node.layerType === 'input';
                const isOutputNode = node.layerType === 'output';
                const inSpec = isInputNode
                  ? resolvedInputSpecs[node.neuronIndex]
                  : undefined;

                return (
                  <g
                    key={node.id}
                    transform={`translate(${p.x}, ${p.y})`}
                    className="cursor-pointer"
                    opacity={dim ? 0.28 : 1}
                    onMouseEnter={() => setInspect({ kind: 'node', id: node.id })}
                    onMouseLeave={() =>
                      setInspect((p) =>
                        p.kind === 'node' ? { kind: 'none' } : p
                      )
                    }
                    onClick={() =>
                      setInspect((p) =>
                        p.kind === 'node' && p.id === node.id
                          ? { kind: 'none' }
                          : { kind: 'node', id: node.id }
                      )
                    }
                  >
                    {(inPlayhead || inspected) && (
                      <circle
                        r={nodeRadius + 5.5}
                        fill="none"
                        stroke={hue}
                        strokeWidth={1.5}
                        opacity={inspected ? 0.45 : undefined}
                        className={inPlayhead ? 'animate-pulse-ring' : undefined}
                      />
                    )}

                    {/* Left Callout for Single Input */}
                    {isInputNode && node.featureName && (
                      <g transform={`translate(${-(nodeRadius + 9)}, 0)`}>
                        <line
                          x1={2}
                          y1={0}
                          x2={7}
                          y2={0}
                          stroke="var(--color-line)"
                          strokeWidth={1}
                        />
                        <text
                          x={-2}
                          y={inSpec ? -1.5 : 3.5}
                          textAnchor="end"
                          className="fill-ink text-[10.5px] font-mono font-semibold"
                        >
                          {node.featureName.length > 15
                            ? `${node.featureName.slice(0, 14)}…`
                            : node.featureName}
                        </text>
                        {inSpec && (
                          <text
                            x={-2}
                            y={10}
                            textAnchor="end"
                            className="fill-muted text-[9.2px] font-mono"
                          >
                            {denormalizeToRawValue(node.activation, inSpec)}
                            {inSpec.unit ? ` ${inSpec.unit}` : ''}
                          </text>
                        )}
                      </g>
                    )}

                    {/* Right Callout for Single Output */}
                    {isOutputNode && node.featureName && (
                      <g transform={`translate(${nodeRadius + 9}, 0)`}>
                        <line
                          x1={-7}
                          y1={0}
                          x2={-2}
                          y2={0}
                          stroke="var(--color-line)"
                          strokeWidth={1}
                        />
                        <text
                          x={2}
                          y={-1.5}
                          textAnchor="start"
                          className={`text-[10.5px] font-mono font-semibold ${
                            node.isTopPrediction ? 'fill-accent-strong' : 'fill-ink'
                          }`}
                        >
                          {node.featureName.length > 15
                            ? `${node.featureName.slice(0, 14)}…`
                            : node.featureName}
                        </text>
                        {node.interpretedDisplay && (
                          <text
                            x={2}
                            y={10}
                            textAnchor="start"
                            className={`text-[9.5px] font-mono ${
                              node.isTopPrediction
                                ? 'fill-good font-semibold'
                                : 'fill-muted'
                            }`}
                          >
                            {node.interpretedDisplay}
                            {node.isTopPrediction ? ' ★' : ''}
                          </text>
                        )}
                      </g>
                    )}

                    {/* Optional Hidden Neuron Label */}
                    {!isInputNode && !isOutputNode && node.featureName && (
                      <text
                        y={nodeRadius + 10.5}
                        textAnchor="middle"
                        className="fill-muted text-[9px] font-mono pointer-events-none"
                      >
                        {node.featureName.length > 11
                          ? `${node.featureName.slice(0, 10)}…`
                          : node.featureName}
                      </text>
                    )}

                    <circle
                      r={nodeRadius}
                      fill="var(--color-surface)"
                      stroke={
                        inspected
                          ? 'var(--color-ink)'
                          : node.isTopPrediction
                          ? 'var(--color-good)'
                          : hue
                      }
                      strokeWidth={inspected || node.isTopPrediction ? 2.2 : 1.6}
                      strokeDasharray={node.frozen ? '3 2' : undefined}
                    />
                    <circle
                      r={nodeRadius * 0.66}
                      fill={hue}
                      fillOpacity={0.12 + strength * 0.6}
                    />
                    <text
                      y={3.4}
                      textAnchor="middle"
                      className="fill-ink text-[9.5px] font-mono font-semibold pointer-events-none"
                    >
                      {node.activation.toFixed(2)}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* ---------------- RIGHT DOCK: OUTPUTS, TELEMETRY & LAB KNOBS ---------------- */}
        <div className="border-t lg:border-t-0 lg:border-l border-line bg-surface-2/55 flex flex-col justify-between divide-y divide-line">
          {/* Top Section: Live Decoded Outputs */}
          <div className="p-3.5">
            <div className="flex items-center justify-between mb-2.5">
              <div>
                <div className="micro text-faint">
                  Decoded outputs ({resolvedOutputSpecs.length})
                </div>
                <div className="text-[11px] text-muted mt-0.5">
                  Live forward-pass predictions
                </div>
              </div>
              <button
                type="button"
                onClick={() => onChangeConfig((prev) => addOutputNodeToConfig(prev))}
                disabled={resolvedOutputSpecs.length >= 10}
                title="Add a new output target"
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-accent text-white text-[11px] font-semibold hover:bg-accent-strong transition-colors disabled:opacity-40 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>Add</span>
              </button>
            </div>

            <div className="space-y-2 max-h-[175px] overflow-y-auto pr-0.5">
              {outputNodes.map((outNode, idx) => {
                const outSpec = resolvedOutputSpecs[idx];
                const isHovered =
                  inspect.kind === 'node' && inspect.id === outNode.id;
                const barPct =
                  outSpec?.mode === 'softmax_class'
                    ? Math.round((outNode.softmaxProb ?? 0) * 100)
                    : outSpec?.mode === 'sigmoid_prob'
                    ? Math.round(
                        (1 /
                          (1 +
                            Math.exp(
                              -Math.max(-10, Math.min(10, outNode.preActivation))
                            ))) *
                          100
                      )
                    : Math.round(
                        Math.min(100, Math.max(8, Math.abs(outNode.activation) * 100))
                      );

                return (
                  <div
                    key={outNode.id}
                    onMouseEnter={() =>
                      setInspect({ kind: 'node', id: outNode.id })
                    }
                    onMouseLeave={() =>
                      setInspect((p) =>
                        p.kind === 'node' && p.id === outNode.id
                          ? { kind: 'none' }
                          : p
                      )
                    }
                    className={`rounded-[12px] border p-2 transition-colors cursor-pointer ${
                      isHovered
                        ? 'bg-surface border-accent/60 shadow-card'
                        : outNode.isTopPrediction
                        ? 'bg-accent-soft/55 border-accent/40'
                        : 'bg-surface-2 border-line/60'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 text-[11.5px]">
                      <span className="font-mono font-semibold text-ink truncate">
                        {outNode.featureName}
                      </span>
                      <span
                        className={`tnum font-mono font-semibold shrink-0 ${
                          outNode.isTopPrediction ? 'text-good' : 'text-ink'
                        }`}
                      >
                        {outNode.interpretedDisplay ?? outNode.activation.toFixed(3)}
                        {outNode.isTopPrediction ? ' ★' : ''}
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-surface-3 overflow-hidden mt-1.5">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          outNode.isTopPrediction ? 'bg-good' : 'bg-accent'
                        }`}
                        style={{ width: `${barPct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Middle Section: Dynamic Node / Synapse / Step Inspector */}
          <div className="p-3.5 min-h-[122px] flex flex-col justify-center">
            {activeNode ? (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="micro text-accent-strong">
                    Neuron telemetry
                  </span>
                  <span className="font-mono text-[10.5px] text-muted">
                    {activeNode.layerLabel}
                  </span>
                </div>
                <div className="font-mono text-[12px] font-semibold text-ink truncate mb-1.5">
                  {activeNode.featureName
                    ? `${activeNode.featureName} (${activeNode.id})`
                    : activeNode.id}
                </div>
                <div className="grid grid-cols-2 gap-x-3 gap-y-1 font-mono text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-muted">z:</span>
                    <span className="tnum text-ink">
                      {activeNode.preActivation.toFixed(3)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted">a:</span>
                    <span className="tnum text-ink">
                      {activeNode.activation.toFixed(3)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted">b:</span>
                    <span className="tnum text-ink">{activeNode.bias.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted">∂L/∂z:</span>
                    <span className="tnum text-ink">
                      {activeNode.gradient.toFixed(4)}
                    </span>
                  </div>
                </div>
              </div>
            ) : activeEdge ? (
              <div>
                <div className="micro text-accent-strong mb-1">
                  Synapse telemetry
                </div>
                <div className="font-mono text-[12px] font-semibold text-ink mb-1.5">
                  {activeEdge.sourceId} → {activeEdge.targetId}
                </div>
                <div className="grid grid-cols-2 gap-x-3 gap-y-1 font-mono text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-muted">w:</span>
                    <span className="tnum text-ink">
                      {activeEdge.weight.toFixed(3)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted">a·w:</span>
                    <span className="tnum text-ink">
                      {activeEdge.signal.toFixed(3)}
                    </span>
                  </div>
                  <div className="flex justify-between col-span-2">
                    <span className="text-muted">grad ∂L/∂w:</span>
                    <span className="tnum text-ink">
                      {activeEdge.gradient.toFixed(4)}
                    </span>
                  </div>
                </div>
              </div>
            ) : playhead !== null ? (
              <div>
                <div className="micro text-accent-strong mb-1">
                  Pass step {playhead + 1} of {groups.length}
                </div>
                <div className="text-[12.5px] font-semibold text-ink">
                  {resolvedSpecs[playhead]?.name ?? `Stage ${playhead}`}
                </div>
                <p className="text-[11px] font-mono text-muted mt-1 leading-snug">
                  {playhead === 0
                    ? `x ∈ ℝ^${config.inputNodes} normalized intake`
                    : `a(${playhead}) = ${
                        network.layerSummaries[playhead - 1]?.activationUsed
                      }(W·a + b)`}
                </p>
              </div>
            ) : (
              <div>
                <div className="micro text-faint mb-1">Signal inspector</div>
                <p className="text-[11.5px] text-muted leading-relaxed">
                  Hover any input slider, neuron, synapse, or output bar to inspect
                  live activations, weights, and backprop gradients.
                </p>
              </div>
            )}
          </div>

          {/* Bottom Section: Precision Hyperparameter Knobs */}
          <div className="p-3.5 space-y-2.5 bg-surface/65">
            <div className="micro text-faint">Lab hyperparameters</div>

                <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10.5px] font-medium text-faint block mb-1">
                  Activation
                </label>
                <select
                  value={config.activation}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      activation: e.target.value as ActivationType,
                    }))
                  }
                  aria-label="Global activation function"
                  className="w-full bg-surface-3/60 border border-line/60 rounded-[9px] px-2 py-1.5 text-[11.5px] font-medium text-ink cursor-pointer focus:outline-none focus:border-accent/50"
                >
                  {(
                    ['gelu', 'relu', 'swish', 'tanh', 'sigmoid'] as ActivationType[]
                  ).map((a) => (
                    <option key={a} value={a}>
                      {activationLabel(a)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10.5px] font-medium text-faint block mb-1">
                  Weight Init
                </label>
                <select
                  value={config.initStrategy}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      initStrategy: e.target.value as InitStrategy,
                    }))
                  }
                  aria-label="Weight initialization strategy"
                  className="w-full bg-surface-3/60 border border-line/60 rounded-[9px] px-2 py-1.5 text-[11.5px] font-medium text-ink cursor-pointer focus:outline-none focus:border-accent/50"
                >
                  <option value="he">He normal</option>
                  <option value="xavier">Xavier</option>
                  <option value="lecun">LeCun</option>
                  <option value="sparse">Sparse L1</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5 pt-0.5">
              <div>
                <div className="flex justify-between text-[10.5px] mb-1">
                  <span className="text-muted">Prune threshold τ</span>
                  <span className="tnum font-mono font-semibold text-ink">
                    {config.pruneThreshold.toFixed(2)}
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={0.44}
                  step={0.02}
                  value={config.pruneThreshold}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      pruneThreshold: Number(e.target.value),
                    }))
                  }
                  aria-label="Magnitude pruning threshold"
                  className="w-full"
                />
              </div>

              <div>
                <div className="flex justify-between text-[10.5px] mb-1">
                  <span className="text-muted">Weight variance σ</span>
                  <span className="tnum font-mono font-semibold text-ink">
                    {config.weightScale.toFixed(2)}×
                  </span>
                </div>
                <input
                  type="range"
                  min={0.4}
                  max={2.0}
                  step={0.05}
                  value={config.weightScale}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      weightScale: Number(e.target.value),
                    }))
                  }
                  aria-label="Weight scale multiplier"
                  className="w-full"
                />
              </div>
            </div>

            <div className="pt-1 flex items-center justify-between text-[10.5px] text-faint font-mono">
              <span>Out shape: [B, {resolvedOutputSpecs.length}]</span>
              <span>∇L₂ = {m.globalGradNorm.toFixed(3)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Subtle status footer strip across the unified console */}
      <div className="px-4 py-2 border-t border-line bg-surface-2/70 flex flex-wrap items-center justify-between gap-2 text-[11px] text-muted">
        <span>
          <strong className="font-semibold text-ink">{config.name}</strong>
          {config.planConstraints?.objectiveNote
            ? ` — ${config.planConstraints.objectiveNote}`
            : ''}
        </span>
        <span className="font-mono text-[10.5px] text-faint">
          Stage {lastStageIdx} readout · {network.edges.length} total synapses (
          {network.edges.length - Math.round((network.edges.length * m.sparsityPct) / 100)}{' '}
          active)
        </span>
      </div>
    </section>
  );
};

/* Compact inline stage pill inside the unified Lab toolbar */
const ChainArrow: React.FC = () => (
  <svg width="13" height="9" viewBox="0 0 14 10" className="text-faint shrink-0">
    <path
      d="M0 5h11M7.5 1.5L11 5l-3.5 3.5"
      stroke="currentColor"
      strokeWidth="1.4"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const StagePill: React.FC<{
  label: string;
  count: number;
  tone: 'input' | 'hidden' | 'output';
  frozen?: boolean;
  onRename: (name: string) => void;
  onStep: (delta: number) => void;
  onRemove?: () => void;
}> = ({ label, count, tone, frozen, onRename, onStep, onRemove }) => {
  const borderCls =
    tone === 'output'
      ? 'border-accent/35 bg-accent-soft/40'
      : 'border-line/70 bg-surface-3/50';

  return (
    <div
      className={`inline-flex items-center gap-1.5 pl-3 pr-1.5 py-1.5 rounded-full border text-[11.5px] ${borderCls}`}
    >
      <input
        type="text"
        value={label}
        onChange={(e) => onRename(e.target.value)}
        aria-label="Layer name"
        title="Click to rename stage"
        style={{ width: `${Math.max(4, Math.min(13, label.length + 0.6))}ch` }}
        className="bg-transparent font-medium text-ink focus:outline-none focus:underline truncate"
      />
      {frozen && (
        <span className="text-[9px] font-mono px-1 rounded bg-warm-soft text-warm-strong">
          frz
        </span>
      )}
      <div className="inline-flex items-center rounded-full bg-surface border border-line/60 px-1 py-0.5 font-mono text-[11px]">
        <button
          type="button"
          onClick={() => onStep(-1)}
          className="text-muted hover:text-accent px-0.5 cursor-pointer"
          title="Decrease units"
        >
          <Minus className="w-2.5 h-2.5" />
        </button>
        <span className="tnum font-semibold text-ink min-w-[14px] text-center">
          {count}
        </span>
        <button
          type="button"
          onClick={() => onStep(1)}
          className="text-muted hover:text-accent px-0.5 cursor-pointer"
          title="Increase units"
        >
          <Plus className="w-2.5 h-2.5" />
        </button>
      </div>
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          className="p-0.5 rounded text-faint hover:text-warm-strong hover:bg-warm-soft transition-colors cursor-pointer"
          title={`Remove layer "${label}"`}
          aria-label={`Remove layer ${label}`}
        >
          <X className="w-3 h-3" />
        </button>
      )}
    </div>
  );
};
