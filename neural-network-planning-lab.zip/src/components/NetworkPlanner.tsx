import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowRight,
  ArrowUp,
  Bookmark,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Copy,
  CopyPlus,
  Download,
  Eye,
  Info,
  Lock,
  Minus,
  Plus,
  Sparkles,
  Trash2,
  TriangleAlert,
  Unlock,
  X,
} from 'lucide-react';
import {
  GeneratedNetwork,
  InputSignalKind,
  LayerActivationOverride,
  LayerNormType,
  NETWORK_PRESETS,
  NetworkConfig,
  OutputHeadMode,
  PlanConstraints,
  PresetItem,
  TaskKind,
  TrainingPlan,
  addBulkInputsFromList,
  addBulkOutputsFromList,
  addHiddenLayerToConfig,
  addInputNodeToConfig,
  addOutputNodeToConfig,
  duplicateHiddenLayerInConfig,
  evaluatePlanDiagnostics,
  generateMarkdownSpec,
  generatePyTorchCode,
  generateTypeScriptCode,
  moveHiddenLayerInConfig,
  moveInputNodeInConfig,
  moveOutputNodeInConfig,
  normalizeInputRawValue,
  removeHiddenLayerFromConfig,
  removeInputNodeFromConfig,
  removeOutputNodeFromConfig,
  updateInputNodeInConfig,
  updateLayerSpecInConfig,
  updateOutputNodeInConfig,
} from '../lib/neuralEngine';
import { Card } from './ui';

export interface SavedPlanDraft {
  id: string;
  savedAt: string;
  label: string;
  topology: string;
  stageSummary: string;
  totalParams: number;
  trainableParams: number;
  latencyMs: number;
  accuracyPct: number;
  config: NetworkConfig;
}

interface NetworkPlannerProps {
  network: GeneratedNetwork;
  plan: TrainingPlan;
  onChange: (updater: (prev: NetworkConfig) => NetworkConfig) => void;
  onSelectPreset: (preset: PresetItem) => void;
  drafts: SavedPlanDraft[];
  onSaveDraft: () => void;
  onLoadDraft: (cfg: NetworkConfig) => void;
  onDeleteDraft: (id: string) => void;
  onSwitchToWorkbench: () => void;
}

export const NetworkPlanner: React.FC<NetworkPlannerProps> = ({
  network,
  plan,
  onChange,
  onSelectPreset,
  drafts,
  onSaveDraft,
  onLoadDraft,
  onDeleteDraft,
  onSwitchToWorkbench,
}) => {
  const [bulkInputText, setBulkInputText] = useState('');
  const [bulkOutputText, setBulkOutputText] = useState('');
  const [openNeuronStage, setOpenNeuronStage] = useState<string | null>(null);
  const [exportFormat, setExportFormat] = useState<
    'markdown' | 'pytorch' | 'typescript'
  >('markdown');
  const [copied, setCopied] = useState(false);

  const {
    config,
    resolvedSpecs,
    resolvedInputSpecs,
    resolvedOutputSpecs,
    layerSizes,
    layerSummaries,
    metrics,
  } = network;

  const outputNodes = network.nodes.filter((n) => n.layerType === 'output');

  const constraints: PlanConstraints = config.planConstraints ?? {
    taskKind: 'classification',
    objectiveNote: 'Feed-forward neural architecture blueprint.',
    maxParamsBudget: 220,
    maxLatencyMs: 2.5,
  };

  const updateConstraints = (patch: Partial<PlanConstraints>) => {
    onChange((prev) => ({
      ...prev,
      planConstraints: {
        ...(prev.planConstraints ?? constraints),
        ...patch,
      },
    }));
  };

  const setHiddenWidth = (hiddenIdx: number, rawWidth: number) => {
    const n = Math.max(1, Math.min(12, rawWidth));
    onChange((prev) => {
      const hidden = [...prev.hiddenLayers];
      hidden[hiddenIdx] = n;
      return { ...prev, hiddenLayers: hidden };
    });
  };

  const setHiddenNeuronLabel = (
    stageIdx: number,
    width: number,
    neuronIdx: number,
    label: string
  ) => {
    onChange((prev) => {
      const existing = prev.layerSpecs?.[stageIdx]?.neuronLabels ?? [];
      const arr = Array.from({ length: width }, (_, k) => existing[k] ?? '');
      arr[neuronIdx] = label;
      return updateLayerSpecInConfig(prev, stageIdx, { neuronLabels: arr });
    });
  };

  const diagnostics = evaluatePlanDiagnostics(network);
  const specText =
    exportFormat === 'markdown'
      ? generateMarkdownSpec(network, plan)
      : exportFormat === 'pytorch'
      ? generatePyTorchCode(network)
      : generateTypeScriptCode(network);

  const handleCopySpec = () => {
    navigator.clipboard.writeText(specText);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const handleDownloadSpec = () => {
    const ext =
      exportFormat === 'markdown' ? 'md' : exportFormat === 'pytorch' ? 'py' : 'ts';
    const blob = new Blob([specText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${config.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-plan.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const paramRatio = Math.min(
    100,
    Math.round((metrics.totalParams / Math.max(1, constraints.maxParamsBudget)) * 100)
  );
  const overParamBudget = metrics.totalParams > constraints.maxParamsBudget;

  const latencyRatio = Math.min(
    100,
    Math.round(
      (metrics.estimatedLatencyMs / Math.max(0.1, constraints.maxLatencyMs)) * 100
    )
  );
  const overLatencyBudget = metrics.estimatedLatencyMs > constraints.maxLatencyMs;

  return (
    <div className="space-y-5">
      {/* ===================================================================== */}
      {/* UNIFIED BLUEPRINT CONSOLE HEADER + LIVE HORIZONTAL PIPELINE SCHEMATIC */}
      {/* ===================================================================== */}
      <section className="bg-surface border border-line/60 rounded-[20px] overflow-hidden shadow-card">
        {/* Starter Templates & Quick Actions Bar */}
        <div className="px-4 py-2.5 bg-surface-2/80 border-b border-line flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="micro text-faint mr-1 inline-flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-accent" />
              Blueprints:
            </span>
            {NETWORK_PRESETS.map((preset) => {
              const selected = config.name === preset.config.name;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => onSelectPreset(preset)}
                  className={`px-3 py-1 rounded-full text-[11.5px] font-medium transition-colors cursor-pointer ${
                    selected
                      ? 'bg-ink text-surface'
                      : 'bg-surface-3/60 text-muted hover:text-ink'
                  }`}
                >
                  {preset.title}
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onSaveDraft}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-surface-3/70 text-[11.5px] font-medium text-ink hover:bg-surface-3 transition-colors cursor-pointer"
            >
              <Bookmark className="w-3.5 h-3.5 text-accent" />
              <span>Pin draft</span>
            </button>
            <button
              type="button"
              onClick={onSwitchToWorkbench}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-accent text-white text-[12px] font-semibold hover:bg-accent-strong transition-colors cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Open in Live Lab</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Model Identity + Objective + Live Budgets */}
        <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 border-b border-line">
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-12 gap-3">
            <div className="sm:col-span-4">
              <label className="micro text-faint block mb-1" htmlFor="plan-model-name">
                Model / Class Name
              </label>
              <input
                id="plan-model-name"
                type="text"
                value={config.name}
                onChange={(e) =>
                  onChange((prev) => ({ ...prev, name: e.target.value }))
                }
                placeholder="MyCustomNet"
                className="w-full bg-surface-2 border border-line rounded-lg px-2.5 py-1.5 text-[13px] font-mono font-semibold text-ink focus:outline-none focus:border-accent"
              />
            </div>

            <div className="sm:col-span-3">
              <label className="micro text-faint block mb-1" htmlFor="plan-task-kind">
                Problem Type
              </label>
              <select
                id="plan-task-kind"
                value={constraints.taskKind}
                onChange={(e) =>
                  updateConstraints({ taskKind: e.target.value as TaskKind })
                }
                className="w-full bg-surface-2 border border-line rounded-lg px-2.5 py-1.5 text-[12.5px] font-medium text-ink cursor-pointer focus:outline-none focus:border-accent"
              >
                <option value="classification">Classification</option>
                <option value="regression">Regression</option>
                <option value="control">Control / Policy</option>
                <option value="embedding">Autoencoder</option>
              </select>
            </div>

            <div className="sm:col-span-5">
              <label className="micro text-faint block mb-1" htmlFor="plan-objective">
                Design Objective
              </label>
              <input
                id="plan-objective"
                type="text"
                value={constraints.objectiveNote}
                onChange={(e) =>
                  updateConstraints({ objectiveNote: e.target.value })
                }
                placeholder="What does this network predict?"
                className="w-full bg-surface-2 border border-line rounded-lg px-2.5 py-1.5 text-[12.5px] text-ink focus:outline-none focus:border-accent"
              />
            </div>
          </div>

          {/* Budget Gauges */}
          <div className="lg:col-span-5 lg:border-l border-line lg:pl-4 grid grid-cols-1 sm:grid-cols-2 gap-3.5 items-center">
            <div>
              <div className="flex items-baseline justify-between mb-1">
                <span className="micro text-faint">Param budget</span>
                <span
                  className={`tnum font-mono text-[11.5px] font-semibold ${
                    overParamBudget ? 'text-warm-strong' : 'text-ink'
                  }`}
                >
                  {metrics.totalParams} / {constraints.maxParamsBudget}p
                </span>
              </div>
              <div className="h-1.5 rounded-full bg-surface-3 overflow-hidden mb-1.5">
                <div
                  className={`h-full rounded-full transition-all ${
                    overParamBudget ? 'bg-warm' : 'bg-accent'
                  }`}
                  style={{ width: `${paramRatio}%` }}
                />
              </div>
              <input
                type="range"
                min={20}
                max={800}
                step={10}
                value={constraints.maxParamsBudget}
                onChange={(e) =>
                  updateConstraints({ maxParamsBudget: Number(e.target.value) })
                }
                aria-label="Maximum parameter budget"
                className="w-full"
              />
            </div>

            <div>
              <div className="flex items-baseline justify-between mb-1">
                <span className="micro text-faint">Latency ceiling</span>
                <span
                  className={`tnum font-mono text-[11.5px] font-semibold ${
                    overLatencyBudget ? 'text-warm-strong' : 'text-ink'
                  }`}
                >
                  {metrics.estimatedLatencyMs.toFixed(2)} /{' '}
                  {constraints.maxLatencyMs.toFixed(1)}ms
                </span>
              </div>
              <div className="h-1.5 rounded-full bg-surface-3 overflow-hidden mb-1.5">
                <div
                  className={`h-full rounded-full transition-all ${
                    overLatencyBudget ? 'bg-warm' : 'bg-good'
                  }`}
                  style={{ width: `${latencyRatio}%` }}
                />
              </div>
              <input
                type="range"
                min={0.6}
                max={6.0}
                step={0.1}
                value={constraints.maxLatencyMs}
                onChange={(e) =>
                  updateConstraints({ maxLatencyMs: Number(e.target.value) })
                }
                aria-label="Maximum latency budget"
                className="w-full"
              />
            </div>
          </div>
        </div>

        {/* Live Horizontal Blueprint Schematic Diagram */}
        <div className="px-4 py-3.5 graph-paper overflow-x-auto">
          <div className="flex items-center gap-2 min-w-max">
            {resolvedSpecs.map((spec, idx) => {
              const isInput = idx === 0;
              const isOutput = idx === resolvedSpecs.length - 1;
              const isHidden = !isInput && !isOutput;
              const width = layerSizes[idx];
              const nextSummary = layerSummaries[idx];

              return (
                <React.Fragment key={`pipe-${spec.id}`}>
                  {/* Stage Blueprint Block */}
                  <div
                    className={`rounded-xl border px-3.5 py-2.5 min-w-[164px] max-w-[215px] transition-colors ${
                      isOutput
                        ? 'bg-accent-soft/75 border-accent/45'
                        : isInput
                        ? 'bg-surface border-line shadow-2xs'
                        : 'bg-surface border-line shadow-2xs'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="micro text-faint">
                        {isInput ? 'IN' : isOutput ? 'OUT' : `H${idx}`}
                      </span>
                      <div className="flex items-center gap-1">
                        <span className="tnum font-mono text-[11px] font-semibold px-1.5 py-0.5 rounded bg-surface-2 border border-line text-ink">
                          [B, {width}]
                        </span>
                        {isHidden && (
                          <button
                            type="button"
                            onClick={() =>
                              onChange((prev) =>
                                removeHiddenLayerFromConfig(prev, idx - 1)
                              )
                            }
                            title={`Remove "${spec.name}"`}
                            className="p-0.5 rounded text-faint hover:text-warm-strong cursor-pointer"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="text-[12.5px] font-semibold text-ink truncate mt-1">
                      {spec.name}
                    </div>

                    <div className="text-[10.5px] font-mono text-muted truncate mt-0.5">
                      {isInput
                        ? resolvedInputSpecs.map((s) => s.name).join(', ')
                        : isOutput
                        ? resolvedOutputSpecs.map((s) => s.name).join(', ')
                        : `${layerSummaries[idx - 1]?.activationUsed}${
                            spec.norm !== 'none' ? ` · ${spec.norm}` : ''
                          }${spec.frozen ? ' · frz' : ''}`}
                    </div>
                  </div>

                  {/* Connector Matrix + Inline Insert Button */}
                  {nextSummary && (
                    <div className="flex flex-col items-center justify-center px-1 shrink-0">
                      <span className="font-mono text-[10px] text-muted tnum">
                        W{idx + 1} ({nextSummary.shapeFrom}×{nextSummary.shapeTo})
                      </span>
                      <div className="flex items-center gap-1 my-0.5">
                        <div className="w-5 border-t border-line" />
                        {config.hiddenLayers.length < 6 && (
                          <button
                            type="button"
                            onClick={() =>
                              onChange((prev) =>
                                addHiddenLayerToConfig(prev, width, idx)
                              )
                            }
                            title="Insert hidden layer on this connection"
                            className="w-4 h-4 rounded-full border border-line bg-surface text-muted hover:text-accent hover:border-accent flex items-center justify-center text-[11px] leading-none cursor-pointer"
                          >
                            +
                          </button>
                        )}
                        <div className="w-5 border-t border-line" />
                        <span className="text-muted text-[11px] leading-none">▶</span>
                      </div>
                      <span className="font-mono text-[9.5px] text-faint tnum">
                        {nextSummary.params}p
                      </span>
                    </div>
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>
      </section>

      {/* ===================================================================== */}
      {/* TRUE LEFT-TO-RIGHT 3-COLUMN PIPELINE STUDIO:                          */}
      {/* [ 01 · INPUT SIGNALS ] ──▶ [ 02 · HIDDEN STACK ] ──▶ [ 03 · OUTPUTS ] */}
      {/* ===================================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4 items-start">
        {/* ---------------- COLUMN 1: SINGLE INPUTS DESIGNER ---------------- */}
        <Card
          tag="01 · Inputs"
          title={`Input signals (${resolvedInputSpecs.length})`}
          subtitle="Define every single input feature, domain range/unit, and test value."
          actions={
            <button
              type="button"
              onClick={() => onChange((prev) => addInputNodeToConfig(prev))}
              disabled={resolvedInputSpecs.length >= 12}
              className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-accent text-white text-[11.5px] font-semibold hover:bg-accent-strong transition-colors disabled:opacity-40 cursor-pointer"
            >
              <Plus className="w-3 h-3" />
              <span>Add input</span>
            </button>
          }
        >
          {/* Quick Bulk Comma Paste */}
          <div className="flex items-center gap-1.5 mb-3 p-2 rounded-lg bg-surface-2 border border-line">
            <input
              type="text"
              value={bulkInputText}
              onChange={(e) => setBulkInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && bulkInputText.trim()) {
                  onChange((prev) =>
                    addBulkInputsFromList(prev, bulkInputText, false)
                  );
                  setBulkInputText('');
                }
              }}
              placeholder="Paste names: speed, fuel, wind_x..."
              className="flex-1 min-w-0 bg-surface border border-line rounded px-2 py-1 text-[11.5px] font-mono text-ink focus:outline-none focus:border-accent"
            />
            <button
              type="button"
              disabled={!bulkInputText.trim()}
              onClick={() => {
                onChange((prev) =>
                  addBulkInputsFromList(prev, bulkInputText, false)
                );
                setBulkInputText('');
              }}
              className="px-2 py-1 rounded border border-line bg-surface text-[11px] font-medium text-ink hover:border-accent disabled:opacity-40 cursor-pointer shrink-0"
            >
              + Add
            </button>
            <button
              type="button"
              disabled={!bulkInputText.trim()}
              onClick={() => {
                onChange((prev) =>
                  addBulkInputsFromList(prev, bulkInputText, true)
                );
                setBulkInputText('');
              }}
              title="Replace current inputs with these names"
              className="px-2 py-1 rounded border border-line bg-surface text-[11px] font-medium text-warm-strong hover:border-warm/50 disabled:opacity-40 cursor-pointer shrink-0"
            >
              Replace
            </button>
          </div>

          <div className="space-y-2.5">
            {resolvedInputSpecs.map((inp, idx) => {
              const normVal =
                config.inputVector[idx] ?? normalizeInputRawValue(inp);

              return (
                <div
                  key={inp.id}
                  className="rounded-xl border border-line bg-surface-2 p-3 transition-colors hover:border-accent/35"
                >
                  {/* Line 1: Index + Name + Kind + Reorder/Delete */}
                  <div className="flex items-center gap-1.5">
                    <span className="tnum font-mono text-[10px] px-1.5 py-0.5 rounded bg-surface border border-line text-muted shrink-0">
                      in[{idx}]
                    </span>
                    <input
                      type="text"
                      value={inp.name}
                      onChange={(e) =>
                        onChange((prev) =>
                          updateInputNodeInConfig(prev, idx, {
                            name: e.target.value,
                          })
                        )
                      }
                      aria-label={`Input ${idx + 1} name`}
                      className="flex-1 min-w-0 bg-surface border border-line rounded-md px-2 py-1 text-[12.5px] font-mono font-semibold text-ink focus:outline-none focus:border-accent"
                    />
                    <select
                      value={inp.kind}
                      onChange={(e) =>
                        onChange((prev) =>
                          updateInputNodeInConfig(prev, idx, {
                            kind: e.target.value as InputSignalKind,
                          })
                        )
                      }
                      aria-label="Input signal type"
                      className="bg-surface border border-line rounded-md px-1.5 py-1 text-[11px] font-medium text-ink cursor-pointer shrink-0"
                    >
                      <option value="continuous">Range</option>
                      <option value="bounded01">0..1</option>
                      <option value="binary">Bool</option>
                      <option value="signed">-1..1</option>
                    </select>
                    <button
                      type="button"
                      onClick={() =>
                        onChange((prev) => moveInputNodeInConfig(prev, idx, -1))
                      }
                      disabled={idx === 0}
                      title="Move up"
                      className="p-1 rounded border border-line bg-surface text-muted hover:text-ink disabled:opacity-35 cursor-pointer"
                    >
                      <ArrowUp className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onChange((prev) => moveInputNodeInConfig(prev, idx, 1))
                      }
                      disabled={idx === resolvedInputSpecs.length - 1}
                      title="Move down"
                      className="p-1 rounded border border-line bg-surface text-muted hover:text-ink disabled:opacity-35 cursor-pointer"
                    >
                      <ArrowDown className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onChange((prev) => removeInputNodeFromConfig(prev, idx))
                      }
                      disabled={resolvedInputSpecs.length <= 1}
                      title={`Remove "${inp.name}"`}
                      className="p-1 rounded border border-line bg-surface text-muted hover:text-warm-strong disabled:opacity-35 cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Line 2: Range + Unit (if continuous) */}
                  {inp.kind === 'continuous' && (
                    <div className="mt-2 flex items-center gap-1.5 text-[11px]">
                      <span className="text-faint text-[10px]">Domain:</span>
                      <input
                        type="number"
                        value={inp.min}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          if (!Number.isNaN(v))
                            onChange((prev) =>
                              updateInputNodeInConfig(prev, idx, { min: v })
                            );
                        }}
                        className="tnum font-mono w-16 bg-surface border border-line rounded px-1.5 py-0.5 text-ink"
                      />
                      <span className="text-faint">..</span>
                      <input
                        type="number"
                        value={inp.max}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          if (!Number.isNaN(v))
                            onChange((prev) =>
                              updateInputNodeInConfig(prev, idx, { max: v })
                            );
                        }}
                        className="tnum font-mono w-16 bg-surface border border-line rounded px-1.5 py-0.5 text-ink"
                      />
                      <input
                        type="text"
                        value={inp.unit}
                        onChange={(e) =>
                          onChange((prev) =>
                            updateInputNodeInConfig(prev, idx, {
                              unit: e.target.value,
                            })
                          )
                        }
                        placeholder="unit"
                        className="font-mono w-14 bg-surface border border-line rounded px-1.5 py-0.5 text-muted focus:text-ink"
                      />
                    </div>
                  )}

                  {/* Line 3: Sample Slider + Normalized Readout */}
                  <div className="mt-2 pt-2 border-t border-line flex items-center justify-between gap-2 text-[11px]">
                    {inp.kind === 'binary' ? (
                      <button
                        type="button"
                        onClick={() =>
                          onChange((prev) =>
                            updateInputNodeInConfig(prev, idx, {
                              rawValue: inp.rawValue >= 0.5 ? 0 : 1,
                            })
                          )
                        }
                        className={`px-2.5 py-0.5 rounded font-mono font-semibold text-[11px] border cursor-pointer ${
                          inp.rawValue >= 0.5
                            ? 'bg-good/15 border-good/45 text-good'
                            : 'bg-surface border-line text-muted'
                        }`}
                      >
                        Sample: {inp.rawValue >= 0.5 ? '1 (True)' : '0 (False)'}
                      </button>
                    ) : (
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <span className="text-faint text-[10px] shrink-0">Val:</span>
                        <input
                          type="range"
                          min={inp.min}
                          max={inp.max}
                          step={
                            Math.abs(inp.max - inp.min) > 20
                              ? 1
                              : Math.abs(inp.max - inp.min) > 2
                              ? 0.1
                              : 0.01
                          }
                          value={inp.rawValue}
                          onChange={(e) =>
                            onChange((prev) =>
                              updateInputNodeInConfig(prev, idx, {
                                rawValue: Number(e.target.value),
                              })
                            )
                          }
                          className="flex-1"
                        />
                        <input
                          type="number"
                          value={inp.rawValue}
                          step="any"
                          onChange={(e) => {
                            const v = Number(e.target.value);
                            if (!Number.isNaN(v))
                              onChange((prev) =>
                                updateInputNodeInConfig(prev, idx, { rawValue: v })
                              );
                          }}
                          className="tnum font-mono w-16 bg-surface border border-line rounded px-1.5 py-0.5 text-right text-ink"
                        />
                      </div>
                    )}

                    <span className="tnum font-mono text-[10.5px] px-1.5 py-0.5 rounded bg-accent-soft text-accent-strong font-semibold shrink-0">
                      x={normVal >= 0 ? `+${normVal.toFixed(2)}` : normVal.toFixed(2)}
                    </span>
                  </div>

                  {/* Line 4: Optional Description */}
                  <input
                    type="text"
                    value={inp.description}
                    onChange={(e) =>
                      onChange((prev) =>
                        updateInputNodeInConfig(prev, idx, {
                          description: e.target.value,
                        })
                      )
                    }
                    placeholder={`Note / source for ${inp.name}...`}
                    className="mt-2 w-full bg-surface border border-line rounded px-2 py-1 text-[11px] text-muted focus:text-ink focus:outline-none focus:border-accent"
                  />
                </div>
              );
            })}
          </div>
        </Card>

        {/* ---------------- COLUMN 2: HIDDEN LAYERS DESIGNER ---------------- */}
        <Card
          tag="02 · Hidden"
          title={`Hidden layer stack (${config.hiddenLayers.length})`}
          subtitle="Rename stages, tune widths/activations/norms, remove down to 1 or 0, or label neurons."
          actions={
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => onChange((prev) => addHiddenLayerToConfig(prev, 6))}
                disabled={config.hiddenLayers.length >= 6}
                className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-accent text-white text-[11.5px] font-semibold hover:bg-accent-strong transition-colors disabled:opacity-40 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>Add layer</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  onChange((prev) =>
                    removeHiddenLayerFromConfig(prev, prev.hiddenLayers.length - 1)
                  )
                }
                disabled={config.hiddenLayers.length === 0}
                title="Remove last hidden layer"
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-surface-3/70 text-[11.5px] font-medium text-muted hover:text-warm-strong transition-colors disabled:opacity-40 cursor-pointer"
              >
                <Minus className="w-3 h-3" />
              </button>
            </div>
          }
        >
          {config.hiddenLayers.length === 0 ? (
            <div className="rounded-xl border border-dashed border-line bg-surface-2 p-5 text-center space-y-2.5">
              <div className="text-[13px] font-semibold text-ink">
                0 hidden layers ({config.inputNodes} → {config.outputNodes})
              </div>
              <p className="text-[11.5px] text-muted">
                Direct linear projection from inputs to outputs. Add a hidden layer to
                model non-linear feature interactions.
              </p>
              <button
                type="button"
                onClick={() => onChange((prev) => addHiddenLayerToConfig(prev, 6))}
                className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-accent text-white text-[12px] font-semibold hover:bg-accent-strong transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add hidden layer</span>
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {config.hiddenLayers.map((width, hiddenIdx) => {
                const stageIdx = hiddenIdx + 1;
                const spec = resolvedSpecs[stageIdx];
                const summary = layerSummaries[hiddenIdx];
                const neuronsExpanded = openNeuronStage === spec.id;

                return (
                  <div
                    key={spec.id}
                    className={`rounded-xl border p-3 ${
                      spec.frozen
                        ? 'bg-surface-2/60 border-dashed border-line'
                        : 'bg-surface-2 border-line hover:border-accent/35'
                    }`}
                  >
                    {/* Header row */}
                    <div className="flex items-center gap-1.5">
                      <span className="px-1.5 py-0.5 rounded font-mono text-[10.5px] font-semibold bg-ink text-canvas shrink-0">
                        H{hiddenIdx + 1}
                      </span>
                      <input
                        type="text"
                        value={spec.name}
                        onChange={(e) =>
                          onChange((prev) =>
                            updateLayerSpecInConfig(prev, stageIdx, {
                              name: e.target.value,
                            })
                          )
                        }
                        aria-label={`Hidden layer ${hiddenIdx + 1} name`}
                        className="flex-1 min-w-0 bg-surface border border-line rounded-md px-2 py-1 text-[12.5px] font-semibold text-ink focus:outline-none focus:border-accent"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          onChange((prev) =>
                            updateLayerSpecInConfig(prev, stageIdx, {
                              frozen: !spec.frozen,
                            })
                          )
                        }
                        title={spec.frozen ? 'Unfreeze layer' : 'Freeze layer'}
                        className={`p-1 rounded border cursor-pointer ${
                          spec.frozen
                            ? 'bg-warm-soft border-warm/40 text-warm-strong'
                            : 'bg-surface border-line text-muted hover:text-ink'
                        }`}
                      >
                        {spec.frozen ? (
                          <Lock className="w-3 h-3" />
                        ) : (
                          <Unlock className="w-3 h-3" />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onChange((prev) =>
                            moveHiddenLayerInConfig(prev, hiddenIdx, -1)
                          )
                        }
                        disabled={hiddenIdx === 0}
                        title="Move layer earlier"
                        className="p-1 rounded border border-line bg-surface text-muted hover:text-ink disabled:opacity-35 cursor-pointer"
                      >
                        <ArrowUp className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onChange((prev) =>
                            moveHiddenLayerInConfig(prev, hiddenIdx, 1)
                          )
                        }
                        disabled={hiddenIdx === config.hiddenLayers.length - 1}
                        title="Move layer later"
                        className="p-1 rounded border border-line bg-surface text-muted hover:text-ink disabled:opacity-35 cursor-pointer"
                      >
                        <ArrowDown className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onChange((prev) =>
                            duplicateHiddenLayerInConfig(prev, hiddenIdx)
                          )
                        }
                        disabled={config.hiddenLayers.length >= 6}
                        title="Duplicate layer"
                        className="p-1 rounded border border-line bg-surface text-muted hover:text-ink disabled:opacity-35 cursor-pointer"
                      >
                        <CopyPlus className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onChange((prev) =>
                            removeHiddenLayerFromConfig(prev, hiddenIdx)
                          )
                        }
                        title={`Remove "${spec.name}"`}
                        className="p-1 rounded border border-line bg-surface text-muted hover:text-warm-strong cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>

                    {/* 2x2 Stage Hyperparameters */}
                    <div className="grid grid-cols-2 gap-2 mt-2.5 pt-2.5 border-t border-line">
                      <div>
                        <div className="flex items-center justify-between text-[10px] text-faint mb-1">
                          <span>NEURONS</span>
                          {summary && (
                            <span className="font-mono">{summary.params}p</span>
                          )}
                        </div>
                        <div className="flex items-center justify-between rounded-md border border-line bg-surface px-1.5 py-0.5">
                          <button
                            type="button"
                            onClick={() => setHiddenWidth(hiddenIdx, width - 1)}
                            className="p-1 text-muted hover:text-ink cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="tnum font-mono text-[12.5px] font-semibold text-ink">
                            {width}
                          </span>
                          <button
                            type="button"
                            onClick={() => setHiddenWidth(hiddenIdx, width + 1)}
                            className="p-1 text-muted hover:text-ink cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      <div>
                        <div className="micro text-faint mb-1">Activation</div>
                        <select
                          value={spec.activationOverride}
                          onChange={(e) =>
                            onChange((prev) =>
                              updateLayerSpecInConfig(prev, stageIdx, {
                                activationOverride: e.target
                                  .value as LayerActivationOverride,
                              })
                            )
                          }
                          className="w-full bg-surface border border-line rounded-md px-2 py-1 text-[11.5px] font-medium text-ink cursor-pointer"
                        >
                          <option value="inherit">
                            Default ({config.activation.toUpperCase()})
                          </option>
                          <option value="gelu">GELU</option>
                          <option value="relu">ReLU</option>
                          <option value="swish">Swish / SiLU</option>
                          <option value="tanh">Tanh</option>
                          <option value="sigmoid">Sigmoid</option>
                          <option value="linear">Linear</option>
                        </select>
                      </div>

                      <div>
                        <div className="micro text-faint mb-1">Norm</div>
                        <select
                          value={spec.norm}
                          onChange={(e) =>
                            onChange((prev) =>
                              updateLayerSpecInConfig(prev, stageIdx, {
                                norm: e.target.value as LayerNormType,
                              })
                            )
                          }
                          className="w-full bg-surface border border-line rounded-md px-2 py-1 text-[11.5px] font-medium text-ink cursor-pointer"
                        >
                          <option value="none">None</option>
                          <option value="layernorm">LayerNorm</option>
                          <option value="batchnorm">BatchNorm</option>
                          <option value="rmsnorm">RMSNorm</option>
                        </select>
                      </div>

                      <div>
                        <div className="micro text-faint mb-1">Dropout</div>
                        <select
                          value={spec.dropout}
                          onChange={(e) =>
                            onChange((prev) =>
                              updateLayerSpecInConfig(prev, stageIdx, {
                                dropout: Number(e.target.value),
                              })
                            )
                          }
                          className="w-full bg-surface border border-line rounded-md px-2 py-1 text-[11.5px] font-mono text-ink cursor-pointer"
                        >
                          {[0, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4].map((d) => (
                            <option key={d} value={d}>
                              {d.toFixed(2)}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Note + Collapsible Single-Neuron Labels */}
                    <div className="mt-2 flex items-center gap-1.5">
                      <input
                        type="text"
                        value={spec.notes}
                        onChange={(e) =>
                          onChange((prev) =>
                            updateLayerSpecInConfig(prev, stageIdx, {
                              notes: e.target.value,
                            })
                          )
                        }
                        placeholder={`Role note for ${spec.name}...`}
                        className="flex-1 min-w-0 bg-surface border border-line rounded px-2 py-1 text-[11px] text-muted focus:text-ink focus:outline-none focus:border-accent"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setOpenNeuronStage(neuronsExpanded ? null : spec.id)
                        }
                        className="inline-flex items-center gap-0.5 px-2 py-1 rounded border border-line bg-surface text-[10.5px] font-medium text-muted hover:text-ink shrink-0 cursor-pointer"
                      >
                        <span>Neurons</span>
                        {neuronsExpanded ? (
                          <ChevronUp className="w-3 h-3" />
                        ) : (
                          <ChevronDown className="w-3 h-3" />
                        )}
                      </button>
                    </div>

                    {neuronsExpanded && (
                      <div className="mt-2 pt-2 border-t border-line grid grid-cols-2 gap-1.5">
                        {Array.from({ length: width }).map((_, nIdx) => (
                          <div
                            key={`${spec.id}-n-${nIdx}`}
                            className="flex items-center gap-1"
                          >
                            <span className="tnum font-mono text-[9.5px] text-faint">
                              #{nIdx + 1}
                            </span>
                            <input
                              type="text"
                              value={spec.neuronLabels?.[nIdx] ?? ''}
                              onChange={(e) =>
                                setHiddenNeuronLabel(
                                  stageIdx,
                                  width,
                                  nIdx,
                                  e.target.value
                                )
                              }
                              placeholder={`unit_${nIdx + 1}`}
                              className="flex-1 min-w-0 bg-surface border border-line rounded px-1.5 py-0.5 text-[11px] font-mono text-ink focus:outline-none focus:border-accent"
                            />
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* ---------------- COLUMN 3: SINGLE OUTPUTS DESIGNER ---------------- */}
        <Card
          tag="03 · Outputs"
          title={`Output targets (${resolvedOutputSpecs.length})`}
          subtitle="Define every class score, probability, or continuous prediction."
          actions={
            <button
              type="button"
              onClick={() => onChange((prev) => addOutputNodeToConfig(prev))}
              disabled={resolvedOutputSpecs.length >= 10}
              className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-accent text-white text-[11.5px] font-semibold hover:bg-accent-strong transition-colors disabled:opacity-40 cursor-pointer"
            >
              <Plus className="w-3 h-3" />
              <span>Add output</span>
            </button>
          }
        >
          {/* Quick Bulk Comma Paste */}
          <div className="flex items-center gap-1.5 mb-3 p-2 rounded-lg bg-surface-2 border border-line">
            <input
              type="text"
              value={bulkOutputText}
              onChange={(e) => setBulkOutputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && bulkOutputText.trim()) {
                  onChange((prev) =>
                    addBulkOutputsFromList(prev, bulkOutputText, false)
                  );
                  setBulkOutputText('');
                }
              }}
              placeholder="Paste outputs: approve, block, review..."
              className="flex-1 min-w-0 bg-surface border border-line rounded px-2 py-1 text-[11.5px] font-mono text-ink focus:outline-none focus:border-accent"
            />
            <button
              type="button"
              disabled={!bulkOutputText.trim()}
              onClick={() => {
                onChange((prev) =>
                  addBulkOutputsFromList(prev, bulkOutputText, false)
                );
                setBulkOutputText('');
              }}
              className="px-2 py-1 rounded border border-line bg-surface text-[11px] font-medium text-ink hover:border-accent disabled:opacity-40 cursor-pointer shrink-0"
            >
              + Add
            </button>
            <button
              type="button"
              disabled={!bulkOutputText.trim()}
              onClick={() => {
                onChange((prev) =>
                  addBulkOutputsFromList(prev, bulkOutputText, true)
                );
                setBulkOutputText('');
              }}
              title="Replace current outputs with these names"
              className="px-2 py-1 rounded border border-line bg-surface text-[11px] font-medium text-warm-strong hover:border-warm/50 disabled:opacity-40 cursor-pointer shrink-0"
            >
              Replace
            </button>
          </div>

          <div className="space-y-2.5">
            {resolvedOutputSpecs.map((out, idx) => {
              const liveNode = outputNodes[idx];
              const barPct =
                out.mode === 'softmax_class'
                  ? Math.round((liveNode?.softmaxProb ?? 0) * 100)
                  : out.mode === 'sigmoid_prob'
                  ? Math.round(
                      (1 /
                        (1 +
                          Math.exp(
                            -Math.max(
                              -10,
                              Math.min(10, liveNode?.preActivation ?? 0)
                            )
                          ))) *
                        100
                    )
                  : Math.round(
                      Math.min(
                        100,
                        Math.max(8, Math.abs(liveNode?.activation ?? 0) * 100)
                      )
                    );

              return (
                <div
                  key={out.id}
                  className={`rounded-xl border p-3 transition-colors ${
                    liveNode?.isTopPrediction
                      ? 'bg-accent-soft/35 border-accent/45'
                      : 'bg-surface-2 border-line hover:border-accent/35'
                  }`}
                >
                  {/* Line 1: Index + Name + Mode + Reorder/Delete */}
                  <div className="flex items-center gap-1.5">
                    <span className="tnum font-mono text-[10px] px-1.5 py-0.5 rounded bg-surface border border-line text-muted shrink-0">
                      out[{idx}]
                    </span>
                    <input
                      type="text"
                      value={out.name}
                      onChange={(e) =>
                        onChange((prev) =>
                          updateOutputNodeInConfig(prev, idx, {
                            name: e.target.value,
                          })
                        )
                      }
                      aria-label={`Output ${idx + 1} name`}
                      className="flex-1 min-w-0 bg-surface border border-line rounded-md px-2 py-1 text-[12.5px] font-mono font-semibold text-ink focus:outline-none focus:border-accent"
                    />
                    <select
                      value={out.mode}
                      onChange={(e) =>
                        onChange((prev) =>
                          updateOutputNodeInConfig(prev, idx, {
                            mode: e.target.value as OutputHeadMode,
                          })
                        )
                      }
                      aria-label="Output mode"
                      className="bg-surface border border-line rounded-md px-1.5 py-1 text-[11px] font-medium text-ink cursor-pointer shrink-0"
                    >
                      <option value="softmax_class">Softmax</option>
                      <option value="sigmoid_prob">Prob 0..1</option>
                      <option value="tanh_axis">Axis -1..1</option>
                      <option value="linear_value">Scaled</option>
                    </select>
                    <button
                      type="button"
                      onClick={() =>
                        onChange((prev) => moveOutputNodeInConfig(prev, idx, -1))
                      }
                      disabled={idx === 0}
                      title="Move up"
                      className="p-1 rounded border border-line bg-surface text-muted hover:text-ink disabled:opacity-35 cursor-pointer"
                    >
                      <ArrowUp className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onChange((prev) => moveOutputNodeInConfig(prev, idx, 1))
                      }
                      disabled={idx === resolvedOutputSpecs.length - 1}
                      title="Move down"
                      className="p-1 rounded border border-line bg-surface text-muted hover:text-ink disabled:opacity-35 cursor-pointer"
                    >
                      <ArrowDown className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onChange((prev) => removeOutputNodeFromConfig(prev, idx))
                      }
                      disabled={resolvedOutputSpecs.length <= 1}
                      title={`Remove "${out.name}"`}
                      className="p-1 rounded border border-line bg-surface text-muted hover:text-warm-strong disabled:opacity-35 cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Live Prediction Bar */}
                  <div className="mt-2 flex items-center gap-2">
                    <div className="h-1.5 flex-1 rounded-full bg-surface-3 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          liveNode?.isTopPrediction ? 'bg-good' : 'bg-accent'
                        }`}
                        style={{ width: `${barPct}%` }}
                      />
                    </div>
                    {liveNode && (
                      <span
                        className={`tnum font-mono text-[11px] font-semibold shrink-0 ${
                          liveNode.isTopPrediction ? 'text-good' : 'text-ink'
                        }`}
                      >
                        {liveNode.interpretedDisplay}
                        {liveNode.isTopPrediction ? ' ★' : ''}
                      </span>
                    )}
                  </div>

                  {/* Mode options + Note */}
                  <div className="mt-2 pt-2 border-t border-line flex flex-wrap items-center gap-1.5 text-[11px]">
                    {out.mode === 'sigmoid_prob' && (
                      <div className="flex items-center gap-1 shrink-0">
                        <span className="text-faint text-[10px]">Trigger ≥</span>
                        <input
                          type="number"
                          min={0.05}
                          max={0.95}
                          step={0.05}
                          value={out.threshold}
                          onChange={(e) => {
                            const v = Number(e.target.value);
                            if (!Number.isNaN(v))
                              onChange((prev) =>
                                updateOutputNodeInConfig(prev, idx, {
                                  threshold: Math.max(0.05, Math.min(0.95, v)),
                                })
                              );
                          }}
                          className="tnum font-mono w-14 bg-surface border border-line rounded px-1.5 py-0.5 text-ink"
                        />
                      </div>
                    )}

                    {out.mode === 'linear_value' && (
                      <div className="flex items-center gap-1 shrink-0">
                        <input
                          type="number"
                          value={out.min}
                          onChange={(e) => {
                            const v = Number(e.target.value);
                            if (!Number.isNaN(v))
                              onChange((prev) =>
                                updateOutputNodeInConfig(prev, idx, { min: v })
                              );
                          }}
                          className="tnum font-mono w-14 bg-surface border border-line rounded px-1.5 py-0.5 text-ink"
                        />
                        <span className="text-faint">..</span>
                        <input
                          type="number"
                          value={out.max}
                          onChange={(e) => {
                            const v = Number(e.target.value);
                            if (!Number.isNaN(v))
                              onChange((prev) =>
                                updateOutputNodeInConfig(prev, idx, { max: v })
                              );
                          }}
                          className="tnum font-mono w-14 bg-surface border border-line rounded px-1.5 py-0.5 text-ink"
                        />
                        <input
                          type="text"
                          value={out.unit}
                          onChange={(e) =>
                            onChange((prev) =>
                              updateOutputNodeInConfig(prev, idx, {
                                unit: e.target.value,
                              })
                            )
                          }
                          placeholder="unit"
                          className="font-mono w-12 bg-surface border border-line rounded px-1.5 py-0.5 text-muted"
                        />
                      </div>
                    )}

                    <input
                      type="text"
                      value={out.description}
                      onChange={(e) =>
                        onChange((prev) =>
                          updateOutputNodeInConfig(prev, idx, {
                            description: e.target.value,
                          })
                        )
                      }
                      placeholder={`Meaning of ${out.name}...`}
                      className="flex-1 min-w-[130px] bg-surface border border-line rounded px-2 py-0.5 text-[11px] text-muted focus:text-ink focus:outline-none focus:border-accent"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* ===================================================================== */}
      {/* BOTTOM DOCK: CHECKS + PINNED DRAFTS (LEFT) & CODE / SPEC EXPORT       */}
      {/* ===================================================================== */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 items-start">
        <div className="xl:col-span-5 space-y-4">
          <Card
            tag="Validation"
            title="Architecture checks"
            subtitle="Automated checks on output modes, parameter budgets, and depth."
          >
            <div className="space-y-2">
              {diagnostics.map((d, i) => (
                <div
                  key={`${d.title}-${i}`}
                  className="flex items-start gap-2.5 p-2.5 rounded-lg bg-surface-2 border border-line"
                >
                  {d.level === 'good' ? (
                    <CheckCircle2 className="w-4 h-4 text-good shrink-0 mt-0.5" />
                  ) : d.level === 'warn' ? (
                    <TriangleAlert className="w-4 h-4 text-warm-strong shrink-0 mt-0.5" />
                  ) : (
                    <Info className="w-4 h-4 text-accent shrink-0 mt-0.5" />
                  )}
                  <div className="min-w-0">
                    <div className="text-[12px] font-semibold text-ink">
                      {d.title}
                    </div>
                    <p className="text-[11px] text-muted leading-relaxed mt-0.5">
                      {d.body}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card
            tag="Pinned"
            title="Saved blueprint snapshots"
            subtitle="Compare pinned designs side by side."
            actions={
              <button
                type="button"
                onClick={onSaveDraft}
                className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-accent text-white text-[11.5px] font-semibold hover:bg-accent-strong transition-colors cursor-pointer"
              >
                <Bookmark className="w-3 h-3" />
                <span>Pin current</span>
              </button>
            }
          >
            <div className="space-y-2">
              {drafts.map((d) => (
                <div
                  key={d.id}
                  className="flex items-center justify-between gap-2 p-2.5 rounded-lg bg-surface-2 border border-line"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[12px] font-semibold text-ink truncate">
                        {d.label}
                      </span>
                      <span className="tnum font-mono text-[10.5px] text-accent-strong">
                        [{d.topology}]
                      </span>
                    </div>
                    <div className="text-[10.5px] font-mono text-muted truncate">
                      {d.stageSummary}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => onLoadDraft(d.config)}
                      className="px-2.5 py-1 rounded bg-surface border border-line text-[11px] font-medium text-ink hover:border-accent cursor-pointer"
                    >
                      Load
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteDraft(d.id)}
                      title="Delete draft"
                      className="p-1 rounded text-faint hover:text-warm-strong cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="xl:col-span-7">
          <Card
            tag="Export"
            title="Blueprint specification & code"
            subtitle="Auto-generated from your planned input ranges, layer names, and output heads."
            actions={
              <div className="flex items-center gap-1.5">
                <div className="inline-flex rounded-lg bg-surface-3 p-0.5 text-[11px] font-medium border border-line/60">
                  {(
                    [
                      ['markdown', 'Spec .md'],
                      ['pytorch', 'PyTorch .py'],
                      ['typescript', 'Types .ts'],
                    ] as const
                  ).map(([id, lbl]) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setExportFormat(id)}
                      className={`px-2 py-0.5 rounded-[5px] cursor-pointer ${
                        exportFormat === id
                          ? 'bg-surface text-ink shadow-2xs'
                          : 'text-muted hover:text-ink'
                      }`}
                    >
                      {lbl}
                    </button>
                  ))}
                </div>
                <button
                  type="button"
                  onClick={handleCopySpec}
                  title="Copy"
                  className="p-1.5 rounded-lg border border-line bg-surface-2 text-muted hover:text-ink cursor-pointer"
                >
                  {copied ? (
                    <Check className="w-3.5 h-3.5 text-good" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={handleDownloadSpec}
                  title="Download"
                  className="p-1.5 rounded-lg border border-line bg-surface-2 text-muted hover:text-ink cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            }
          >
            <pre className="bg-surface-2 border border-line rounded-lg p-3.5 text-[11.5px] font-mono leading-relaxed text-ink overflow-auto max-h-[420px]">
              <code>{specText}</code>
            </pre>
          </Card>
        </div>
      </div>
    </div>
  );
};
