import React, { useState } from 'react';
import {
  GeneratedNetwork,
  NetworkConfig,
  ScenarioRow,
  TrainingPlan as TrainingPlanType,
  activationLabel,
  generateMarkdownSpec,
  generatePyTorchCode,
  generateTypeScriptCode,
} from '../lib/neuralEngine';
import { Card } from './ui';
import { Check, Copy, DownloadIcon, ArrowUpRight } from 'lucide-react';

/* ------------------------------------------------------------------ */
/* Forward pass trace — the arithmetic, layer by layer                  */
/* ------------------------------------------------------------------ */
export const ForwardTrace: React.FC<{ network: GeneratedNetwork }> = ({
  network,
}) => {
  const [active, setActive] = useState(0);

  const layers = network.nodes.reduce<Record<number, typeof network.nodes>>(
    (acc, n) => {
      acc[n.layerIndex] = acc[n.layerIndex] || [];
      acc[n.layerIndex].push(n);
      return acc;
    },
    {}
  );

  const layerIdx = Object.keys(layers)
    .map(Number)
    .sort((a, b) => a - b);

  const safeActive = Math.min(active, Math.max(0, layerIdx.length - 1));
  const step = layerIdx[safeActive] ?? 0;
  const nodes = layers[step] ?? [];
  const transition = network.layerSummaries[step - 1];
  const inputNodes = layers[0] ?? [];

  return (
    <Card
      tag="Forward pass"
      title="Layer-by-layer arithmetic"
      subtitle="Step-by-step matrix evaluation across your named stages."
    >
      <div className="flex flex-wrap gap-1.5 mb-3.5">
        {layerIdx.map((l, i) => {
          const isOn = i === safeActive;
          const label =
            network.resolvedSpecs[l]?.name ||
            (l === 0 ? 'Inputs' : l === layerIdx.length - 1 ? 'Outputs' : `Hidden ${l}`);
          return (
            <button
              key={l}
              type="button"
              onClick={() => setActive(i)}
              className={`px-3 py-1 rounded-full text-[11.5px] font-medium transition-colors cursor-pointer ${
                isOn
                  ? 'bg-accent text-white'
                  : 'bg-surface-3/60 text-muted hover:text-ink'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      <div className="bg-surface-2 border border-line rounded-lg p-3.5 font-mono text-[12px] leading-relaxed">
        {step === 0 ? (
          <div>
            <div className="text-faint text-[10.5px] mb-1.5">
              stage 0 — normalized input vector x ∈ ℝ^{inputNodes.length}
            </div>
            <div className="text-ink break-words">
              x = [
              {inputNodes
                .map((n, idx) => `${network.inputNames[idx]}=${n.activation.toFixed(2)}`)
                .join(', ')}
              ]
            </div>
            <div className="text-muted mt-2 text-[11px]">
              Next matrix projection: shape{' '}
              {transition ? `${transition.shapeFrom}×${transition.shapeTo}` : '—'}.
            </div>
          </div>
        ) : (
          <div>
            <div className="text-faint text-[10.5px] mb-1.5">
              stage {step} — {transition?.activationUsed} transformation
            </div>
            <div className="text-ink">
              z({step}) = W({step}) · a({step - 1}) + b({step})
            </div>
            <div className="text-ink">
              a({step}) = {transition?.activationUsed}(z({step}))
            </div>
            <div className="text-muted mt-2 text-[11px]">
              matrix {transition?.shapeFrom}×{transition?.shapeTo} ·{' '}
              {transition?.params.toLocaleString()} params · mean |a| ={' '}
              {transition?.meanActivation.toFixed(3)} · ‖W‖₂ ={' '}
              {transition?.weightL2Norm.toFixed(3)}
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {nodes.slice(0, 12).map((n) => (
                <span
                  key={n.id}
                  className={`px-1.5 py-0.5 rounded text-[10.5px] tnum ${
                    n.activation < 0
                      ? 'bg-warm-soft text-warm-strong'
                      : 'bg-accent-soft text-accent-strong'
                  }`}
                >
                  {n.featureName ? `${n.featureName}: ` : ''}
                  {n.activation.toFixed(3)}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};

/* ------------------------------------------------------------------ */
/* Architecture notes — teaching the shape of the net                   */
/* ------------------------------------------------------------------ */
export const ArchitectureNotes: React.FC<{
  network: GeneratedNetwork;
  insights: { kind: string; headline: string; detail: string; delta: number }[];
}> = ({ network, insights }) => {
  const kindColor = (kind: string) =>
    kind === 'expand'
      ? 'text-accent-strong'
      : kind === 'compress' || kind === 'bottleneck'
      ? 'text-warm-strong'
      : 'text-muted';

  return (
    <Card
      tag="Stage guide"
      title="How each stage transforms the signal"
      subtitle="Role of each stage and its computational footprint."
    >
      <ol className="space-y-3">
        {insights.map((ins, i) => (
          <li key={i} className="flex gap-2.5">
            <div className="shrink-0 w-5 h-5 rounded-full bg-surface-3 text-faint text-[10px] font-mono font-semibold flex items-center justify-center tnum mt-0.5">
              {i}
            </div>
            <div>
              <div className="flex items-baseline gap-2 flex-wrap">
                <span className="text-[12.5px] font-semibold text-ink">
                  {ins.headline}
                </span>
                <span
                  className={`text-[10px] font-mono uppercase tracking-wider ${kindColor(
                    ins.kind
                  )}`}
                >
                  {ins.kind}
                </span>
                {ins.delta !== 0 && (
                  <span className="tnum font-mono text-[10.5px] text-faint">
                    ({ins.delta > 0 ? '+' : ''}
                    {ins.delta})
                  </span>
                )}
              </div>
              <p className="text-[11.5px] leading-relaxed text-muted mt-0.5">
                {ins.detail}
              </p>
            </div>
          </li>
        ))}
      </ol>

      <div className="mt-4 pt-3 border-t border-line grid grid-cols-4 gap-2 text-center sm:text-left">
        <div>
          <div className="tnum font-mono text-[13.5px] font-semibold text-ink">
            {network.metrics.totalParams.toLocaleString()}
          </div>
          <div className="text-[10.5px] text-muted">params</div>
        </div>
        <div>
          <div className="tnum font-mono text-[13.5px] font-semibold text-ink">
            {network.metrics.trainableParams.toLocaleString()}
          </div>
          <div className="text-[10.5px] text-muted">trainable</div>
        </div>
        <div>
          <div className="tnum font-mono text-[13.5px] font-semibold text-ink">
            {network.metrics.totalFlops.toLocaleString()}
          </div>
          <div className="text-[10.5px] text-muted">FLOPs</div>
        </div>
        <div>
          <div className="tnum font-mono text-[13.5px] font-semibold text-ink">
            {network.metrics.memoryKB.toFixed(2)} KB
          </div>
          <div className="text-[10.5px] text-muted">FP32 size</div>
        </div>
      </div>
    </Card>
  );
};

/* ------------------------------------------------------------------ */
/* Training plan                                                       */
/* ------------------------------------------------------------------ */
export const TrainingPlanCard: React.FC<{
  network: GeneratedNetwork;
  plan: TrainingPlanType;
}> = ({ network, plan }) => {
  const total = plan.phases.reduce((a, p) => a + p.epochs, 0);

  return (
    <Card
      tag="Training"
      title="Recommended schedule"
      subtitle="4-phase learning rate & batch curriculum matched to model capacity."
      actions={
        <span className="tnum font-mono text-[11px] text-muted">
          ≈ {plan.estTrainMinutes.toFixed(1)} min / 200k rows
        </span>
      }
    >
      <div className="flex h-7 rounded-lg overflow-hidden border border-line mb-3.5">
        {plan.phases.map((p) => (
          <div
            key={p.name}
            title={`${p.name} — ${p.epochs} epochs @ lr ${p.lr.toFixed(5)}`}
            className="relative"
            style={{
              width: `${(p.epochs / total) * 100}%`,
              background: `color-mix(in srgb, var(--color-accent) ${
                100 - plan.phases.indexOf(p) * 20
              }%, var(--color-surface-3))`,
            }}
          >
            <span className="absolute inset-0 flex items-center justify-center text-[10px] font-semibold text-white/95 truncate px-1">
              {p.name}
            </span>
          </div>
        ))}
      </div>

      <div className="space-y-2">
        {plan.phases.map((p) => (
          <div key={p.name} className="flex gap-3">
            <div className="w-20 shrink-0">
              <div className="text-[12px] font-semibold text-ink">{p.name}</div>
              <div className="tnum font-mono text-[10px] text-faint">
                {p.epochs}ep · {p.lr.toFixed(4)}
              </div>
            </div>
            <p className="text-[11.5px] leading-relaxed text-muted border-l border-line pl-3">
              {p.note}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-3.5 pt-3 border-t border-line grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          ['Batch size', plan.recommendedBatch],
          ['Dropout', plan.dropout],
          ['Weight decay', plan.weightDecay],
          ['Optimizer', `AdamW (${activationLabel(network.config.activation)})`],
        ].map(([k, v]) => (
          <div key={String(k)}>
            <div className="micro text-faint">{k}</div>
            <div className="tnum font-mono text-[13px] font-semibold text-ink mt-1 truncate">
              {v}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

/* ------------------------------------------------------------------ */
/* Scenario comparison (what-if planning with 1-click Apply!)          */
/* ------------------------------------------------------------------ */
export const ScenarioTable: React.FC<{
  rows: ScenarioRow[];
  onApplyScenario: (cfg: NetworkConfig) => void;
}> = ({ rows, onApplyScenario }) => {
  const [hover, setHover] = useState<string | null>(null);

  return (
    <Card
      tag="What-if"
      title="Architecture mutation comparison"
      subtitle="Live re-simulations of structural changes — click Apply on any row to adopt it."
    >
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="text-[10px] uppercase tracking-wider text-faint border-b border-line">
              <th className="pb-2 font-semibold">Candidate mutation</th>
              <th className="pb-2 font-semibold">Topology</th>
              <th className="pb-2 text-right font-semibold">Live params</th>
              <th className="pb-2 text-right font-semibold">Δ</th>
              <th className="pb-2 text-right font-semibold">Latency</th>
              <th className="pb-2 text-right font-semibold">Accuracy</th>
              <th className="pb-2 text-right font-semibold">Δ</th>
              <th className="pb-2 text-right font-semibold">Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const good = r.dAccuracy >= 0;
              return (
                <tr
                  key={r.id}
                  onMouseEnter={() => setHover(r.id)}
                  onMouseLeave={() => setHover(null)}
                  className={`border-b border-line-soft transition-colors ${
                    r.isCurrent
                      ? 'bg-accent-soft/45'
                      : hover === r.id
                      ? 'bg-surface-2'
                      : ''
                  }`}
                >
                  <td className="py-2.5 pr-3 text-[12px] font-medium text-ink whitespace-nowrap">
                    {r.label}
                  </td>
                  <td className="py-2.5 pr-3 font-mono text-[11.5px] text-muted whitespace-nowrap">
                    [{r.topology}]
                  </td>
                  <td className="py-2.5 pr-3 text-right tnum font-mono text-[12px] text-ink">
                    {r.params.toLocaleString()}
                  </td>
                  <td
                    className={`py-2.5 pr-3 text-right tnum font-mono text-[11.5px] ${
                      r.dParams === 0
                        ? 'text-faint'
                        : r.dParams > 0
                        ? 'text-warm-strong'
                        : 'text-good'
                    }`}
                  >
                    {r.dParams === 0 ? '—' : `${r.dParams > 0 ? '+' : ''}${r.dParams}`}
                  </td>
                  <td className="py-2.5 pr-3 text-right tnum font-mono text-[12px] text-ink">
                    {r.latencyMs.toFixed(2)} ms
                  </td>
                  <td className="py-2.5 pr-3 text-right tnum font-mono text-[12px] text-ink">
                    {r.accuracy.toFixed(2)}%
                  </td>
                  <td
                    className={`py-2.5 pr-3 text-right tnum font-mono text-[11.5px] ${
                      r.dAccuracy === 0
                        ? 'text-faint'
                        : good
                        ? 'text-good'
                        : 'text-warm-strong'
                    }`}
                  >
                    {r.dAccuracy === 0
                      ? '—'
                      : `${r.dAccuracy > 0 ? '+' : ''}${r.dAccuracy.toFixed(2)}%`}
                  </td>
                  <td className="py-2.5 text-right">
                    {r.isCurrent ? (
                      <span className="text-[10.5px] font-mono text-accent-strong font-semibold">
                        active
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onApplyScenario(r.config)}
                        className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded border border-line bg-surface text-[11px] font-medium text-ink hover:border-accent hover:text-accent-strong cursor-pointer"
                      >
                        <span>Apply</span>
                        <ArrowUpRight className="w-3 h-3" />
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
};

/* ------------------------------------------------------------------ */
/* Code & Specification Exporter Panel                                 */
/* ------------------------------------------------------------------ */
export const CodePanel: React.FC<{
  network: GeneratedNetwork;
  plan: TrainingPlanType;
}> = ({ network, plan }) => {
  const [lang, setLang] = useState<'pytorch' | 'typescript' | 'markdown'>(
    'pytorch'
  );
  const [copied, setCopied] = useState(false);

  const code =
    lang === 'pytorch'
      ? generatePyTorchCode(network)
      : lang === 'typescript'
      ? generateTypeScriptCode(network)
      : generateMarkdownSpec(network, plan);

  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const download = () => {
    const ext = lang === 'pytorch' ? 'py' : lang === 'typescript' ? 'ts' : 'md';
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${network.config.name.toLowerCase().replace(/\s+/g, '-')}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card
      tag="Export"
      title="Synthesized code & specification"
      subtitle="Synchronized live with your planned inputs, layer names, normalization, and outputs."
      actions={
        <div className="flex items-center gap-1.5">
          <div className="inline-flex rounded-lg bg-surface-3 p-0.5 text-[11px] font-medium border border-line/60">
            {(
              [
                ['pytorch', 'PyTorch .py'],
                ['typescript', 'Types .ts'],
                ['markdown', 'Spec .md'],
              ] as const
            ).map(([l, label]) => (
              <button
                key={l}
                type="button"
                onClick={() => setLang(l)}
                className={`px-2.5 py-1 rounded-[5px] transition-colors cursor-pointer ${
                  lang === l
                    ? 'bg-surface text-ink shadow-[0_1px_2px_rgba(0,0,0,0.08)]'
                    : 'text-muted hover:text-ink'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={copy}
            className="p-1.5 rounded-lg border border-line bg-surface-2 text-muted hover:text-ink cursor-pointer"
            title="Copy code"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-good" />
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
          </button>
          <button
            type="button"
            onClick={download}
            className="p-1.5 rounded-lg border border-line bg-surface-2 text-muted hover:text-ink cursor-pointer"
            title="Download file"
          >
            <DownloadIcon className="w-3.5 h-3.5" />
          </button>
        </div>
      }
    >
      <pre className="bg-surface-2 border border-line rounded-lg p-3.5 text-[11.5px] font-mono leading-relaxed text-ink overflow-auto max-h-[380px]">
        <code>{code}</code>
      </pre>
    </Card>
  );
};
