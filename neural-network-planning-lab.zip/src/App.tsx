import { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  BookOpen,
  Compass,
  Moon,
  Sun,
  Terminal,
  Workflow,
} from 'lucide-react';
import {
  NETWORK_PRESETS,
  NetworkConfig,
  PresetItem,
  addInputNodeToConfig,
  addOutputNodeToConfig,
  buildNeuralNetwork,
  buildScenarios,
  buildTrainingPlan,
  describeLayers,
  generateDefaultInputs,
  removeHiddenLayerFromConfig,
  removeInputNodeFromConfig,
  removeOutputNodeFromConfig,
} from './lib/neuralEngine';
import { NetworkCanvas } from './components/NetworkCanvas';
import {
  ConvergenceChart,
  LayerCapacityChart,
  WeightGradientChart,
  WeightMatrixCard,
} from './components/Charts';
import {
  ArchitectureNotes,
  CodePanel,
  ForwardTrace,
  ScenarioTable,
  TrainingPlanCard,
} from './components/Analysis';
import {
  NetworkPlanner,
  SavedPlanDraft,
} from './components/NetworkPlanner';
import { SectionHeader } from './components/ui';

type WorkspaceTab = 'workbench' | 'planner';

const LAB_SECTIONS = [
  { id: 'console', label: 'Console' },
  { id: 'telemetry', label: 'Telemetry' },
  { id: 'trace', label: 'Arithmetic' },
  { id: 'scenarios', label: 'What-if' },
  { id: 'code', label: 'Code' },
];

function clonePresetToConfig(preset: PresetItem): NetworkConfig {
  const base = preset.config;
  return {
    ...base,
    hiddenLayers: [...base.hiddenLayers],
    inputSpecs: base.inputSpecs?.map((s) => ({ ...s })),
    outputSpecs: base.outputSpecs?.map((s) => ({ ...s })),
    layerSpecs: base.layerSpecs?.map((s) => ({ ...s })),
    inputFeatureNames: base.inputSpecs
      ? base.inputSpecs.map((s) => s.name)
      : base.inputFeatureNames
      ? [...base.inputFeatureNames]
      : undefined,
    outputClassNames: base.outputSpecs
      ? base.outputSpecs.map((s) => s.name)
      : base.outputClassNames
      ? [...base.outputClassNames]
      : undefined,
    planConstraints: base.planConstraints
      ? { ...base.planConstraints }
      : undefined,
    inputVector: generateDefaultInputs(base.inputNodes, base.seed, base.inputSpecs),
  };
}

function makeDraftFromPreset(preset: PresetItem, id: string): SavedPlanDraft {
  const cfg = clonePresetToConfig(preset);
  const net = buildNeuralNetwork(cfg);
  return {
    id,
    savedAt: 'preset',
    label: cfg.name,
    topology: net.layerSizes.join(' → '),
    stageSummary: `${net.inputNames.join(', ')} → [${cfg.hiddenLayers.join(',')}] → ${net.outputNames.join(', ')}`,
    totalParams: net.metrics.totalParams,
    trainableParams: net.metrics.trainableParams,
    latencyMs: net.metrics.estimatedLatencyMs,
    accuracyPct: net.metrics.valAccuracyPct,
    config: cfg,
  };
}

export function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('workbench');
  const [config, setConfig] = useState<NetworkConfig>(() =>
    clonePresetToConfig(NETWORK_PRESETS[0])
  );

  const [drafts, setDrafts] = useState<SavedPlanDraft[]>(() => [
    makeDraftFromPreset(NETWORK_PRESETS[0], 'draft-fraud-2l'),
    makeDraftFromPreset(NETWORK_PRESETS[1], 'draft-game-agent'),
    makeDraftFromPreset(NETWORK_PRESETS[2], 'draft-house-price'),
  ]);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', darkMode);
  }, [darkMode]);

  const network = useMemo(() => buildNeuralNetwork(config), [config]);
  const plan = useMemo(() => buildTrainingPlan(network), [network]);
  const insights = useMemo(() => describeLayers(network), [network]);
  const scenarios = useMemo(
    () => buildScenarios(network, buildNeuralNetwork),
    [network]
  );

  const handleSelectPreset = (preset: PresetItem) => {
    setConfig(clonePresetToConfig(preset));
  };

  const handleAdjustLayerSize = (layerIdx: number, delta: number) => {
    setConfig((prev) => {
      const lastLayer = prev.hiddenLayers.length + 1;
      if (layerIdx === 0) {
        return delta > 0
          ? addInputNodeToConfig(prev)
          : removeInputNodeFromConfig(prev, prev.inputNodes - 1);
      }
      if (layerIdx === lastLayer) {
        return delta > 0
          ? addOutputNodeToConfig(prev)
          : removeOutputNodeFromConfig(prev, prev.outputNodes - 1);
      }
      const hidden = [...prev.hiddenLayers];
      hidden[layerIdx - 1] = Math.max(1, Math.min(12, hidden[layerIdx - 1] + delta));
      return { ...prev, hiddenLayers: hidden };
    });
  };

  const handleRemoveHiddenLayer = (hiddenIdx: number) => {
    setConfig((prev) => removeHiddenLayerFromConfig(prev, hiddenIdx));
  };

  const handleSaveDraft = () => {
    const clonedCfg: NetworkConfig = {
      ...config,
      hiddenLayers: [...config.hiddenLayers],
      inputVector: [...config.inputVector],
      inputSpecs: network.resolvedInputSpecs.map((s) => ({ ...s })),
      outputSpecs: network.resolvedOutputSpecs.map((s) => ({ ...s })),
      layerSpecs: network.resolvedSpecs.map((s) => ({
        ...s,
        neuronLabels: s.neuronLabels ? [...s.neuronLabels] : undefined,
      })),
      inputFeatureNames: [...network.inputNames],
      outputClassNames: [...network.outputNames],
      planConstraints: config.planConstraints
        ? { ...config.planConstraints }
        : undefined,
    };
    const nextDraft: SavedPlanDraft = {
      id: `draft-${Date.now()}`,
      savedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      label: `${config.name} (#${drafts.length + 1})`,
      topology: network.layerSizes.join(' → '),
      stageSummary: `${network.inputNames.join(', ')} → [${config.hiddenLayers.join(',')}] → ${network.outputNames.join(', ')}`,
      totalParams: network.metrics.totalParams,
      trainableParams: network.metrics.trainableParams,
      latencyMs: network.metrics.estimatedLatencyMs,
      accuracyPct: network.metrics.valAccuracyPct,
      config: clonedCfg,
    };
    setDrafts((prev) => [nextDraft, ...prev]);
  };

  const handleLoadDraft = (cfg: NetworkConfig) => {
    setConfig({
      ...cfg,
      hiddenLayers: [...cfg.hiddenLayers],
      inputVector: [...cfg.inputVector],
      inputSpecs: cfg.inputSpecs?.map((s) => ({ ...s })),
      outputSpecs: cfg.outputSpecs?.map((s) => ({ ...s })),
      layerSpecs: cfg.layerSpecs?.map((s) => ({
        ...s,
        neuronLabels: s.neuronLabels ? [...s.neuronLabels] : undefined,
      })),
      inputFeatureNames: cfg.inputFeatureNames ? [...cfg.inputFeatureNames] : undefined,
      outputClassNames: cfg.outputClassNames ? [...cfg.outputClassNames] : undefined,
      planConstraints: cfg.planConstraints ? { ...cfg.planConstraints } : undefined,
    });
  };

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="min-h-screen bg-canvas text-ink">
      {/* =================================================================== */}
      {/* PRECISION TOP LAB COMMAND BAR                                       */}
      {/* =================================================================== */}
      <header className="sticky top-0 z-30 bg-canvas/80 backdrop-blur-xl border-b border-line/70">
        <div className="max-w-[1480px] mx-auto px-4 sm:px-6 h-[58px] flex items-center justify-between gap-3">
          {/* Left: Brand Mark + Lab Tabs + Inline Editable Model Identifier */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex items-center gap-2 shrink-0">
              <div className="w-7 h-7 rounded-[7px] bg-ink flex items-center justify-center">
                <svg
                  className="w-4 h-4 text-surface"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                >
                  <circle cx="6" cy="7" r="2.2" />
                  <circle cx="6" cy="17" r="2.2" />
                  <circle cx="18" cy="12" r="2.5" />
                  <path d="M8 7.8L15.6 11.2M8 16.2L15.6 12.8" />
                </svg>
              </div>
              <span className="text-[13.5px] font-bold tracking-[-0.02em] text-ink">
                SynapseLab
              </span>
            </div>

            <span className="hidden sm:inline w-px h-5 bg-line" />

            {/* Primary Mode Tabs */}
            <nav
              aria-label="Primary lab tabs"
              className="inline-flex rounded-full bg-surface-3/80 p-1"
            >
              <button
                type="button"
                onClick={() => setActiveTab('workbench')}
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[12px] font-medium transition-all cursor-pointer ${
                  activeTab === 'workbench'
                    ? 'bg-surface text-ink shadow-[0_1px_4px_rgba(0,0,0,0.1)]'
                    : 'text-muted hover:text-ink'
                }`}
              >
                <Workflow className="w-3.5 h-3.5 text-accent" />
                <span>Live Lab</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('planner')}
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[12px] font-medium transition-all cursor-pointer ${
                  activeTab === 'planner'
                    ? 'bg-surface text-ink shadow-[0_1px_4px_rgba(0,0,0,0.1)]'
                    : 'text-muted hover:text-ink'
                }`}
              >
                <Compass className="w-3.5 h-3.5 text-accent" />
                <span>I/O &amp; Layer Planner</span>
              </button>
            </nav>

            {/* Inline Editable Model Name + Live Shape Pill */}
            <div className="hidden md:flex items-center gap-2 pl-1 min-w-0">
              <input
                type="text"
                value={config.name}
                onChange={(e) =>
                  setConfig((prev) => ({ ...prev, name: e.target.value }))
                }
                aria-label="Model name"
                title="Click to rename active model"
                className="font-mono text-[12px] font-semibold text-ink bg-surface border border-line/70 rounded-[9px] px-2.5 py-1 w-40 focus:outline-none focus:border-accent/60"
              />
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-surface-2 border border-line text-[11px] font-mono text-muted shrink-0">
                <Activity className="w-3 h-3 text-good" />
                <span>[{network.layerSizes.join(' → ')}]</span>
              </span>
            </div>
          </div>

          {/* Right: Section Jumps + Theme Toggle */}
          <div className="flex items-center gap-1.5 shrink-0">
            {activeTab === 'workbench' && (
              <div className="hidden xl:flex items-center gap-0.5 pr-1.5">
                {LAB_SECTIONS.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => scrollTo(s.id)}
                    className="px-2 py-1 rounded-md text-[11.5px] font-medium text-muted hover:text-ink hover:bg-surface-2 transition-colors cursor-pointer"
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            )}
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              className="p-2 rounded-full bg-surface border border-line/70 text-muted hover:text-ink transition-colors cursor-pointer"
              title="Toggle theme"
              aria-label="Toggle colour theme"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* =================================================================== */}
      {/* MAIN LAB WORKSPACE                                                  */}
      {/* =================================================================== */}
      <main className="max-w-[1480px] mx-auto px-4 sm:px-6 py-5 sm:py-7 space-y-7">
        {activeTab === 'planner' ? (
          <NetworkPlanner
            network={network}
            plan={plan}
            onChange={setConfig}
            onSelectPreset={handleSelectPreset}
            drafts={drafts}
            onSaveDraft={handleSaveDraft}
            onLoadDraft={handleLoadDraft}
            onDeleteDraft={(id) =>
              setDrafts((prev) => prev.filter((d) => d.id !== id))
            }
            onSwitchToWorkbench={() => setActiveTab('workbench')}
          />
        ) : (
          <>
            {/* HERO UNIFIED LAB CONSOLE (Telemetry + Chain + Inputs + Graph + Outputs + Knobs) */}
            <div id="console" className="scroll-mt-16">
              <NetworkCanvas
                network={network}
                onChangeConfig={setConfig}
                onSelectPreset={handleSelectPreset}
                onAdjustLayerSize={handleAdjustLayerSize}
                onRemoveHiddenLayer={handleRemoveHiddenLayer}
                onOpenPlanner={() => setActiveTab('planner')}
              />
            </div>

            {/* BAY 01: SIGNAL DYNAMICS & WEIGHT MATRICES */}
            <section id="telemetry" className="scroll-mt-16 space-y-3">
              <SectionHeader
                index="01"
                title="Signal telemetry & weight matrices"
                description="Epoch convergence trajectory, gradient norms, matrix cell weights, and stage capacity."
              />
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
                <div className="xl:col-span-7">
                  <ConvergenceChart network={network} />
                </div>
                <div className="xl:col-span-5">
                  <WeightGradientChart network={network} />
                </div>
              </div>
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
                <div className="xl:col-span-6">
                  <WeightMatrixCard network={network} />
                </div>
                <div className="xl:col-span-6">
                  <LayerCapacityChart network={network} />
                </div>
              </div>
            </section>

            {/* BAY 02: LAYER ARITHMETIC & ARCHITECTURE GUIDE */}
            <section id="trace" className="scroll-mt-16 space-y-3">
              <SectionHeader
                index="02"
                title="Forward arithmetic & structural notes"
                description="Exact matrix equations evaluated at each named stage."
              />
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
                <div className="xl:col-span-6">
                  <ForwardTrace network={network} />
                </div>
                <div className="xl:col-span-6">
                  <ArchitectureNotes network={network} insights={insights} />
                </div>
              </div>
            </section>

            {/* BAY 03: MUTATION COMPARISON, TRAINING SCHEDULE & CODE SYNTHESIS */}
            <section id="scenarios" className="scroll-mt-16 space-y-3">
              <SectionHeader
                index="03"
                title="Mutation benchmarks, training schedule & code synthesis"
                description="Test candidate structural mutations and export self-documenting code."
              />
              <ScenarioTable
                rows={scenarios}
                onApplyScenario={(nextCfg) => handleLoadDraft(nextCfg)}
              />
              <div id="code" className="scroll-mt-16 grid grid-cols-1 xl:grid-cols-12 gap-4">
                <div className="xl:col-span-5">
                  <TrainingPlanCard network={network} plan={plan} />
                </div>
                <div className="xl:col-span-7">
                  <CodePanel network={network} plan={plan} />
                </div>
              </div>
            </section>
          </>
        )}

        {/* Lab Footer */}
        <footer className="pt-2 pb-5 flex flex-wrap items-center justify-between gap-3 text-[11.5px] text-faint border-t border-line">
          <span>
            SynapseLab — unified neural network design, signal visualization &amp; I/O
            specification workbench.
          </span>
          <span className="flex items-center gap-4 font-mono">
            <span className="inline-flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5" />
              z = W·a + b · a = σ(z)
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5" />
              client-side · zero latency
            </span>
          </span>
        </footer>
      </main>
    </div>
  );
}

export default App;
