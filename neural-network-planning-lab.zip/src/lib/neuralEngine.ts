export type ActivationType = 'relu' | 'gelu' | 'sigmoid' | 'tanh' | 'swish';
export type LayerActivationOverride = 'inherit' | ActivationType | 'linear';
export type LayerNormType = 'none' | 'layernorm' | 'batchnorm' | 'rmsnorm';
export type InitStrategy = 'xavier' | 'he' | 'lecun' | 'sparse';
export type TaskKind = 'classification' | 'regression' | 'embedding' | 'control';

export type InputSignalKind = 'continuous' | 'bounded01' | 'binary' | 'signed';
export type OutputHeadMode =
  | 'softmax_class'
  | 'sigmoid_prob'
  | 'tanh_axis'
  | 'linear_value';

export interface InputNodeSpec {
  id: string;
  name: string;
  kind: InputSignalKind;
  unit: string;
  min: number;
  max: number;
  rawValue: number;
  description: string;
}

export interface OutputNodeSpec {
  id: string;
  name: string;
  mode: OutputHeadMode;
  unit: string;
  min: number;
  max: number;
  threshold: number;
  description: string;
}

export interface LayerSpec {
  id: string;
  name: string;
  notes: string;
  dropout: number; // 0.0 to 0.5
  norm: LayerNormType;
  activationOverride: LayerActivationOverride;
  frozen: boolean;
  neuronLabels?: string[];
}

export interface PlanConstraints {
  taskKind: TaskKind;
  objectiveNote: string;
  maxParamsBudget: number;
  maxLatencyMs: number;
}

export interface NetworkConfig {
  name: string;
  inputNodes: number;
  hiddenLayers: number[];
  outputNodes: number;
  activation: ActivationType;
  initStrategy: InitStrategy;
  weightScale: number; // 0.4 to 2.2
  pruneThreshold: number; // 0.0 to 0.45
  learningRate: number;
  seed: number;
  inputVector: number[];
  inputSpecs?: InputNodeSpec[];
  outputSpecs?: OutputNodeSpec[];
  layerSpecs?: LayerSpec[];
  inputFeatureNames?: string[];
  outputClassNames?: string[];
  planConstraints?: PlanConstraints;
}

export interface NeuronNode {
  id: string;
  layerIndex: number;
  neuronIndex: number;
  layerLabel: string;
  featureName?: string;
  unitLabel?: string;
  interpretedDisplay?: string;
  isTopPrediction?: boolean;
  layerType: 'input' | 'hidden' | 'output';
  bias: number;
  preActivation: number; // z
  activation: number; // a = sigma(z)
  softmaxProb?: number;
  gradient: number; // dL/dz
  incomingActive: number;
  outgoingActive: number;
  frozen: boolean;
}

export interface SynapseEdge {
  id: string;
  sourceId: string;
  targetId: string;
  layerIndex: number; // connects layerIndex -> layerIndex + 1
  fromIndex: number;
  toIndex: number;
  weight: number;
  rawWeight: number;
  signal: number; // sourceActivation * weight
  gradient: number; // dL/dw
  pruned: boolean;
  frozen: boolean;
}

export interface LayerSummary {
  index: number;
  name: string;
  fromName: string;
  toName: string;
  opType: string;
  activationUsed: string;
  norm: LayerNormType;
  dropout: number;
  frozen: boolean;
  notes: string;
  shapeFrom: number;
  shapeTo: number;
  tensorShape: string;
  params: number;
  trainableParams: number;
  weightsCount: number;
  biasesCount: number;
  normParams: number;
  activeEdges: number;
  totalEdges: number;
  flops: number;
  weightL2Norm: number;
  gradL2Norm: number;
  meanActivation: number;
  paramSharePct: number;
}

export interface EpochPoint {
  label: string;
  epoch: number;
  currentScore: number;
  baselineScore: number;
  trainLoss: number;
  baselineLoss: number;
  valAccuracy: number;
}

export interface GeneratedNetwork {
  config: NetworkConfig;
  resolvedSpecs: LayerSpec[];
  resolvedInputSpecs: InputNodeSpec[];
  resolvedOutputSpecs: OutputNodeSpec[];
  inputNames: string[];
  outputNames: string[];
  layerSizes: number[];
  nodes: NeuronNode[];
  edges: SynapseEdge[];
  layerSummaries: LayerSummary[];
  epochSeries: EpochPoint[];
  metrics: {
    totalParams: number;
    trainableParams: number;
    frozenParams: number;
    activeParams: number;
    sparsityPct: number;
    activeDensityPct: number;
    totalFlops: number;
    estimatedLatencyMs: number;
    valAccuracyPct: number;
    finalLoss: number;
    globalGradNorm: number;
    memoryKB: number;
  };
}

export interface PresetItem {
  id: string;
  title: string;
  badge: string;
  description: string;
  domain: string;
  config: Omit<NetworkConfig, 'inputVector'>;
}

let specCounter = 200;
export function nextSpecId(prefix = 'item'): string {
  specCounter += 1;
  return `${prefix}-${specCounter}`;
}

/* ---------------------------------------------------------------------------
 * Normalization & Output Interpretation Math
 * ------------------------------------------------------------------------- */

export function normalizeInputRawValue(spec: InputNodeSpec): number {
  if (spec.kind === 'binary') {
    return spec.rawValue >= 0.5 ? 1 : 0;
  }
  if (spec.kind === 'bounded01') {
    return Math.round(Math.max(0, Math.min(1, spec.rawValue)) * 100) / 100;
  }
  if (spec.kind === 'signed') {
    return Math.round(Math.max(-1, Math.min(1, spec.rawValue)) * 100) / 100;
  }
  const span = spec.max - spec.min;
  if (Math.abs(span) < 1e-9) return 0;
  // Map [min, max] cleanly to [-1, 1] centered representation
  const ratio = (spec.rawValue - spec.min) / span;
  const clamped = Math.max(-1, Math.min(1, ratio * 2 - 1));
  return Math.round(clamped * 100) / 100;
}

export function denormalizeToRawValue(
  normalized: number,
  spec: InputNodeSpec
): number {
  if (spec.kind === 'binary') {
    return normalized >= 0.5 ? 1 : 0;
  }
  if (spec.kind === 'bounded01') {
    return Math.round(Math.max(0, Math.min(1, normalized)) * 100) / 100;
  }
  if (spec.kind === 'signed') {
    return Math.round(Math.max(-1, Math.min(1, normalized)) * 100) / 100;
  }
  const ratio = (Math.max(-1, Math.min(1, normalized)) + 1) / 2;
  const raw = spec.min + ratio * (spec.max - spec.min);
  const span = Math.abs(spec.max - spec.min);
  const decimals = span >= 100 ? 0 : span >= 10 ? 1 : 2;
  const factor = Math.pow(10, decimals);
  return Math.round(raw * factor) / factor;
}

export function defaultInputSpec(
  index: number,
  overrides: Partial<InputNodeSpec> = {}
): InputNodeSpec {
  const kind = overrides.kind ?? 'continuous';
  const min =
    overrides.min ??
    (kind === 'binary' || kind === 'bounded01' ? 0 : kind === 'signed' ? -1 : 0);
  const max =
    overrides.max ??
    (kind === 'binary' || kind === 'bounded01' || kind === 'signed' ? 1 : 100);
  const rawValue =
    overrides.rawValue ??
    (kind === 'binary' ? 1 : Math.round(((min + max) * 0.62) * 100) / 100);

  return {
    id: overrides.id ?? `in-${index}`,
    name: overrides.name ?? `input_${index + 1}`,
    kind,
    unit: overrides.unit ?? '',
    min,
    max,
    rawValue,
    description: overrides.description ?? '',
  };
}

export function defaultOutputSpec(
  index: number,
  overrides: Partial<OutputNodeSpec> = {}
): OutputNodeSpec {
  const mode = overrides.mode ?? 'softmax_class';
  return {
    id: overrides.id ?? `out-${index}`,
    name: overrides.name ?? `output_${index + 1}`,
    mode,
    unit: overrides.unit ?? '',
    min: overrides.min ?? 0,
    max: overrides.max ?? 100,
    threshold: overrides.threshold ?? 0.5,
    description: overrides.description ?? '',
  };
}

export function defaultLayerSpec(
  role: 'input' | 'hidden' | 'output',
  hiddenIndex = 1,
  overrides: Partial<LayerSpec> = {}
): LayerSpec {
  const defaultName =
    role === 'input'
      ? 'Inputs'
      : role === 'output'
      ? 'Outputs'
      : `Hidden ${hiddenIndex}`;
  return {
    id: overrides.id ?? `${role}-${hiddenIndex}`,
    name: overrides.name ?? defaultName,
    notes: overrides.notes ?? '',
    dropout: overrides.dropout ?? 0,
    norm: overrides.norm ?? 'none',
    activationOverride: overrides.activationOverride ?? 'inherit',
    frozen: overrides.frozen ?? false,
    neuronLabels: overrides.neuronLabels,
  };
}

export function resolveInputSpecs(config: NetworkConfig): InputNodeSpec[] {
  const existing = config.inputSpecs ?? [];
  return Array.from({ length: config.inputNodes }, (_, i) => {
    if (existing[i]) return existing[i];
    const fallbackName = config.inputFeatureNames?.[i]?.trim() || `input_${i + 1}`;
    const normVal = config.inputVector?.[i] ?? 0.4;
    const spec = defaultInputSpec(i, {
      id: `in-auto-${i}`,
      name: fallbackName,
      kind: 'signed',
      min: -1,
      max: 1,
      rawValue: normVal,
    });
    return spec;
  });
}

export function resolveOutputSpecs(config: NetworkConfig): OutputNodeSpec[] {
  const existing = config.outputSpecs ?? [];
  const defaultMode: OutputHeadMode =
    config.planConstraints?.taskKind === 'regression'
      ? 'linear_value'
      : config.outputNodes === 1
      ? 'sigmoid_prob'
      : 'softmax_class';

  return Array.from({ length: config.outputNodes }, (_, i) => {
    if (existing[i]) return existing[i];
    const fallbackName = config.outputClassNames?.[i]?.trim() || `output_${i + 1}`;
    return defaultOutputSpec(i, {
      id: `out-auto-${i}`,
      name: fallbackName,
      mode: defaultMode,
    });
  });
}

export function resolveLayerSpecs(config: NetworkConfig): LayerSpec[] {
  const expected = 2 + config.hiddenLayers.length;
  const existing = config.layerSpecs ?? [];
  if (existing.length === expected) {
    return existing;
  }

  const inputSpec = existing[0] ?? defaultLayerSpec('input', 0);
  const outputSpec =
    existing.length >= 2
      ? existing[existing.length - 1]
      : defaultLayerSpec('output', 99);
  const middleExisting = existing.slice(1, Math.max(1, existing.length - 1));

  const middle: LayerSpec[] = config.hiddenLayers.map((_, i) => {
    if (middleExisting[i]) return middleExisting[i];
    return defaultLayerSpec('hidden', i + 1, { id: nextSpecId('hidden') });
  });

  return [inputSpec, ...middle, outputSpec];
}

/* ---------------------------------------------------------------------------
 * Single-Input, Single-Output & Hidden-Layer Mutation Helpers
 * ------------------------------------------------------------------------- */

export function addInputNodeToConfig(
  prev: NetworkConfig,
  partial: Partial<InputNodeSpec> = {}
): NetworkConfig {
  if (prev.inputNodes >= 12) return prev;
  const currentInputs = resolveInputSpecs(prev);
  const newSpec = defaultInputSpec(currentInputs.length, {
    id: nextSpecId('in'),
    ...partial,
  });
  const norm = normalizeInputRawValue(newSpec);
  const nextInputs = [...currentInputs, newSpec];
  return {
    ...prev,
    inputNodes: nextInputs.length,
    inputSpecs: nextInputs,
    inputFeatureNames: nextInputs.map((s) => s.name),
    inputVector: [...prev.inputVector.slice(0, currentInputs.length), norm],
  };
}

export function removeInputNodeFromConfig(
  prev: NetworkConfig,
  index: number
): NetworkConfig {
  if (prev.inputNodes <= 1) return prev;
  const currentInputs = resolveInputSpecs(prev);
  const target = Math.max(0, Math.min(currentInputs.length - 1, index));
  const nextInputs = currentInputs.filter((_, i) => i !== target);
  const nextVec = prev.inputVector
    .slice(0, currentInputs.length)
    .filter((_, i) => i !== target);
  return {
    ...prev,
    inputNodes: nextInputs.length,
    inputSpecs: nextInputs,
    inputFeatureNames: nextInputs.map((s) => s.name),
    inputVector: nextVec,
  };
}

export function moveInputNodeInConfig(
  prev: NetworkConfig,
  index: number,
  direction: -1 | 1
): NetworkConfig {
  const currentInputs = resolveInputSpecs(prev);
  const target = index + direction;
  if (target < 0 || target >= currentInputs.length) return prev;
  const nextInputs = [...currentInputs];
  const nextVec = [...prev.inputVector.slice(0, currentInputs.length)];
  [nextInputs[index], nextInputs[target]] = [nextInputs[target], nextInputs[index]];
  [nextVec[index], nextVec[target]] = [nextVec[target], nextVec[index]];
  return {
    ...prev,
    inputSpecs: nextInputs,
    inputFeatureNames: nextInputs.map((s) => s.name),
    inputVector: nextVec,
  };
}

export function updateInputNodeInConfig(
  prev: NetworkConfig,
  index: number,
  patch: Partial<InputNodeSpec>
): NetworkConfig {
  const currentInputs = resolveInputSpecs(prev);
  const nextInputs = currentInputs.map((item, i) => {
    if (i !== index) return item;
    const updated = { ...item, ...patch };
    if (patch.kind && patch.kind !== item.kind) {
      if (patch.kind === 'binary') {
        updated.min = 0;
        updated.max = 1;
        updated.rawValue = updated.rawValue >= 0.5 ? 1 : 0;
      } else if (patch.kind === 'bounded01') {
        updated.min = 0;
        updated.max = 1;
        updated.rawValue = Math.max(0, Math.min(1, updated.rawValue));
      } else if (patch.kind === 'signed') {
        updated.min = -1;
        updated.max = 1;
        updated.rawValue = Math.max(-1, Math.min(1, updated.rawValue));
      } else if (item.min === 0 && item.max === 1) {
        updated.min = 0;
        updated.max = 100;
        updated.rawValue = Math.round(updated.rawValue * 100);
      }
    }
    return updated;
  });

  const nextVec = [...prev.inputVector.slice(0, nextInputs.length)];
  if (nextInputs[index]) {
    nextVec[index] = normalizeInputRawValue(nextInputs[index]);
  }

  return {
    ...prev,
    inputSpecs: nextInputs,
    inputFeatureNames: nextInputs.map((s) => s.name),
    inputVector: nextVec,
  };
}

export function addBulkInputsFromList(
  prev: NetworkConfig,
  rawList: string,
  replaceExisting = false
): NetworkConfig {
  const names = rawList
    .split(/[\n,;]+/)
    .map((s) => s.trim())
    .filter(Boolean);
  if (names.length === 0) return prev;

  const base = replaceExisting ? [] : resolveInputSpecs(prev);
  const baseVec = replaceExisting ? [] : prev.inputVector.slice(0, base.length);
  const available = Math.max(0, 12 - base.length);
  const toAdd = names.slice(0, available);

  const created = toAdd.map((name, i) =>
    defaultInputSpec(base.length + i, {
      id: nextSpecId('in'),
      name,
      kind: 'continuous',
      min: 0,
      max: 100,
      rawValue: 50,
    })
  );

  const combined = [...base, ...created];
  if (combined.length === 0) return prev;

  return {
    ...prev,
    inputNodes: combined.length,
    inputSpecs: combined,
    inputFeatureNames: combined.map((s) => s.name),
    inputVector: [...baseVec, ...created.map((c) => normalizeInputRawValue(c))],
  };
}

export function addOutputNodeToConfig(
  prev: NetworkConfig,
  partial: Partial<OutputNodeSpec> = {}
): NetworkConfig {
  if (prev.outputNodes >= 10) return prev;
  const currentOutputs = resolveOutputSpecs(prev);
  const inheritedMode =
    currentOutputs[currentOutputs.length - 1]?.mode ?? 'softmax_class';
  const newSpec = defaultOutputSpec(currentOutputs.length, {
    id: nextSpecId('out'),
    mode: inheritedMode,
    ...partial,
  });
  const nextOutputs = [...currentOutputs, newSpec];
  return {
    ...prev,
    outputNodes: nextOutputs.length,
    outputSpecs: nextOutputs,
    outputClassNames: nextOutputs.map((s) => s.name),
  };
}

export function removeOutputNodeFromConfig(
  prev: NetworkConfig,
  index: number
): NetworkConfig {
  if (prev.outputNodes <= 1) return prev;
  const currentOutputs = resolveOutputSpecs(prev);
  const target = Math.max(0, Math.min(currentOutputs.length - 1, index));
  const nextOutputs = currentOutputs.filter((_, i) => i !== target);
  return {
    ...prev,
    outputNodes: nextOutputs.length,
    outputSpecs: nextOutputs,
    outputClassNames: nextOutputs.map((s) => s.name),
  };
}

export function moveOutputNodeInConfig(
  prev: NetworkConfig,
  index: number,
  direction: -1 | 1
): NetworkConfig {
  const currentOutputs = resolveOutputSpecs(prev);
  const target = index + direction;
  if (target < 0 || target >= currentOutputs.length) return prev;
  const nextOutputs = [...currentOutputs];
  [nextOutputs[index], nextOutputs[target]] = [
    nextOutputs[target],
    nextOutputs[index],
  ];
  return {
    ...prev,
    outputSpecs: nextOutputs,
    outputClassNames: nextOutputs.map((s) => s.name),
  };
}

export function updateOutputNodeInConfig(
  prev: NetworkConfig,
  index: number,
  patch: Partial<OutputNodeSpec>
): NetworkConfig {
  const currentOutputs = resolveOutputSpecs(prev);
  const nextOutputs = currentOutputs.map((item, i) =>
    i === index ? { ...item, ...patch } : item
  );
  return {
    ...prev,
    outputSpecs: nextOutputs,
    outputClassNames: nextOutputs.map((s) => s.name),
  };
}

export function addBulkOutputsFromList(
  prev: NetworkConfig,
  rawList: string,
  replaceExisting = false
): NetworkConfig {
  const names = rawList
    .split(/[\n,;]+/)
    .map((s) => s.trim())
    .filter(Boolean);
  if (names.length === 0) return prev;

  const currentOutputs = resolveOutputSpecs(prev);
  const defaultMode = currentOutputs[0]?.mode ?? 'softmax_class';
  const base = replaceExisting ? [] : currentOutputs;
  const available = Math.max(0, 10 - base.length);
  const created = names.slice(0, available).map((name, i) =>
    defaultOutputSpec(base.length + i, {
      id: nextSpecId('out'),
      name,
      mode: defaultMode,
    })
  );
  const combined = [...base, ...created];
  if (combined.length === 0) return prev;

  return {
    ...prev,
    outputNodes: combined.length,
    outputSpecs: combined,
    outputClassNames: combined.map((s) => s.name),
  };
}

export function addHiddenLayerToConfig(
  prev: NetworkConfig,
  neurons = 5,
  insertAtIndex?: number
): NetworkConfig {
  if (prev.hiddenLayers.length >= 6) return prev;
  const specs = resolveLayerSpecs(prev);
  const idx =
    insertAtIndex !== undefined
      ? Math.max(0, Math.min(prev.hiddenLayers.length, insertAtIndex))
      : prev.hiddenLayers.length;

  const nextHidden = [...prev.hiddenLayers];
  nextHidden.splice(idx, 0, Math.max(1, Math.min(12, neurons)));

  const newSpec = defaultLayerSpec('hidden', idx + 1, {
    id: nextSpecId('hidden'),
    name: `Hidden ${nextHidden.length}`,
  });

  const middleSpecs = specs.slice(1, specs.length - 1);
  middleSpecs.splice(idx, 0, newSpec);

  return {
    ...prev,
    hiddenLayers: nextHidden,
    layerSpecs: [specs[0], ...middleSpecs, specs[specs.length - 1]],
  };
}

export function removeHiddenLayerFromConfig(
  prev: NetworkConfig,
  hiddenIndex: number
): NetworkConfig {
  if (prev.hiddenLayers.length === 0) return prev;
  const target = Math.max(0, Math.min(prev.hiddenLayers.length - 1, hiddenIndex));
  const specs = resolveLayerSpecs(prev);

  const nextHidden = prev.hiddenLayers.filter((_, i) => i !== target);
  const middleSpecs = specs
    .slice(1, specs.length - 1)
    .filter((_, i) => i !== target);

  return {
    ...prev,
    hiddenLayers: nextHidden,
    layerSpecs: [specs[0], ...middleSpecs, specs[specs.length - 1]],
  };
}

export function moveHiddenLayerInConfig(
  prev: NetworkConfig,
  hiddenIndex: number,
  direction: -1 | 1
): NetworkConfig {
  const target = hiddenIndex + direction;
  if (target < 0 || target >= prev.hiddenLayers.length) return prev;
  const specs = resolveLayerSpecs(prev);
  const nextHidden = [...prev.hiddenLayers];
  const middleSpecs = specs.slice(1, specs.length - 1);

  [nextHidden[hiddenIndex], nextHidden[target]] = [
    nextHidden[target],
    nextHidden[hiddenIndex],
  ];
  [middleSpecs[hiddenIndex], middleSpecs[target]] = [
    middleSpecs[target],
    middleSpecs[hiddenIndex],
  ];

  return {
    ...prev,
    hiddenLayers: nextHidden,
    layerSpecs: [specs[0], ...middleSpecs, specs[specs.length - 1]],
  };
}

export function duplicateHiddenLayerInConfig(
  prev: NetworkConfig,
  hiddenIndex: number
): NetworkConfig {
  if (prev.hiddenLayers.length >= 6) return prev;
  const specs = resolveLayerSpecs(prev);
  const middleSpecs = specs.slice(1, specs.length - 1);
  const sourceSpec = middleSpecs[hiddenIndex];
  const sourceSize = prev.hiddenLayers[hiddenIndex];
  if (sourceSize === undefined || !sourceSpec) return prev;

  const clonedSpec: LayerSpec = {
    ...sourceSpec,
    id: nextSpecId('hidden'),
    name: `${sourceSpec.name}_copy`,
    neuronLabels: sourceSpec.neuronLabels ? [...sourceSpec.neuronLabels] : undefined,
  };

  const nextHidden = [...prev.hiddenLayers];
  nextHidden.splice(hiddenIndex + 1, 0, sourceSize);
  middleSpecs.splice(hiddenIndex + 1, 0, clonedSpec);

  return {
    ...prev,
    hiddenLayers: nextHidden,
    layerSpecs: [specs[0], ...middleSpecs, specs[specs.length - 1]],
  };
}

export function updateLayerSpecInConfig(
  prev: NetworkConfig,
  layerIndex: number,
  patch: Partial<LayerSpec>
): NetworkConfig {
  const specs = resolveLayerSpecs(prev).map((s, idx) =>
    idx === layerIndex ? { ...s, ...patch } : s
  );
  return {
    ...prev,
    layerSpecs: specs,
  };
}

/* ---------------------------------------------------------------------------
 * Presets with Concrete Single-Input & Single-Output Definitions
 * ------------------------------------------------------------------------- */

export const NETWORK_PRESETS: PresetItem[] = [
  {
    id: 'fraud-mlp',
    title: 'Fraud Detection MLP',
    badge: '4 in → 7 → 6 → 3 out',
    description:
      'Card authorization scorer mapping 4 real transaction signals into 3 action classes.',
    domain: 'FinTech Risk Scoring',
    config: {
      name: 'FraudNet_v4',
      inputNodes: 4,
      hiddenLayers: [7, 6],
      outputNodes: 3,
      activation: 'gelu',
      initStrategy: 'he',
      weightScale: 1.05,
      pruneThreshold: 0.12,
      learningRate: 0.0015,
      seed: 42,
      inputSpecs: [
        {
          id: 'fr-in-0',
          name: 'tx_amount',
          kind: 'continuous',
          unit: '$',
          min: 0,
          max: 5000,
          rawValue: 1420,
          description: 'Card transaction amount in USD',
        },
        {
          id: 'fr-in-1',
          name: 'velocity_24h',
          kind: 'continuous',
          unit: 'tx',
          min: 0,
          max: 30,
          rawValue: 9,
          description: 'Number of charges in rolling 24h window',
        },
        {
          id: 'fr-in-2',
          name: 'device_trust',
          kind: 'bounded01',
          unit: '',
          min: 0,
          max: 1,
          rawValue: 0.82,
          description: 'Browser/device fingerprint trust score [0..1]',
        },
        {
          id: 'fr-in-3',
          name: 'card_present',
          kind: 'binary',
          unit: 'bool',
          min: 0,
          max: 1,
          rawValue: 0,
          description: '1 = chip/tap physical card, 0 = online CNP',
        },
      ],
      outputSpecs: [
        {
          id: 'fr-out-0',
          name: 'approve',
          mode: 'softmax_class',
          unit: '',
          min: 0,
          max: 1,
          threshold: 0.5,
          description: 'Allow charge immediately',
        },
        {
          id: 'fr-out-1',
          name: 'block_fraud',
          mode: 'softmax_class',
          unit: '',
          min: 0,
          max: 1,
          threshold: 0.5,
          description: 'Decline charge & flag card',
        },
        {
          id: 'fr-out-2',
          name: 'step_up_2fa',
          mode: 'softmax_class',
          unit: '',
          min: 0,
          max: 1,
          threshold: 0.5,
          description: 'Request SMS/biometric challenge',
        },
      ],
      planConstraints: {
        taskKind: 'classification',
        objectiveNote: 'Real-time card authorization scoring under 2.5 ms p95 budget.',
        maxParamsBudget: 220,
        maxLatencyMs: 2.5,
      },
      layerSpecs: [
        defaultLayerSpec('input', 0, {
          id: 'p1-in',
          name: 'Transaction Inputs',
          notes: 'Normalized payment, velocity & device signals.',
        }),
        defaultLayerSpec('hidden', 1, {
          id: 'p1-h1',
          name: 'Feature Interactions',
          notes: 'Crosses amount × velocity × device trust.',
          norm: 'layernorm',
          dropout: 0.1,
        }),
        defaultLayerSpec('hidden', 2, {
          id: 'p1-h2',
          name: 'Risk Context',
          notes: 'Non-linear fraud pattern combinations.',
          dropout: 0.05,
        }),
        defaultLayerSpec('output', 99, {
          id: 'p1-out',
          name: 'Auth Decision',
          notes: '3 mutually exclusive Softmax classes.',
        }),
      ],
    },
  },
  {
    id: 'game-agent',
    title: 'Game AI / RL Controller',
    badge: '5 sensors → 8 → 4 actions',
    description:
      '2D character controller mapping raycast & health sensors into multi-action probabilities.',
    domain: 'Game AI / Robotics',
    config: {
      name: 'BotController_MLP',
      inputNodes: 5,
      hiddenLayers: [8],
      outputNodes: 4,
      activation: 'tanh',
      initStrategy: 'xavier',
      weightScale: 1.1,
      pruneThreshold: 0.08,
      learningRate: 0.002,
      seed: 91,
      inputSpecs: [
        {
          id: 'gm-in-0',
          name: 'player_hp',
          kind: 'continuous',
          unit: 'hp',
          min: 0,
          max: 100,
          rawValue: 72,
          description: 'Agent remaining health points',
        },
        {
          id: 'gm-in-1',
          name: 'enemy_dist',
          kind: 'continuous',
          unit: 'm',
          min: 0,
          max: 50,
          rawValue: 14,
          description: 'Euclidean distance to nearest target',
        },
        {
          id: 'gm-in-2',
          name: 'aim_angle',
          kind: 'signed',
          unit: 'rad',
          min: -1,
          max: 1,
          rawValue: 0.25,
          description: 'Normalized angle offset to target [-1..1]',
        },
        {
          id: 'gm-in-3',
          name: 'ammo_ratio',
          kind: 'bounded01',
          unit: '',
          min: 0,
          max: 1,
          rawValue: 0.6,
          description: 'Remaining magazine fraction [0..1]',
        },
        {
          id: 'gm-in-4',
          name: 'on_ground',
          kind: 'binary',
          unit: 'bool',
          min: 0,
          max: 1,
          rawValue: 1,
          description: 'Physics ground contact flag',
        },
      ],
      outputSpecs: [
        {
          id: 'gm-out-0',
          name: 'move_forward',
          mode: 'sigmoid_prob',
          unit: '',
          min: 0,
          max: 1,
          threshold: 0.5,
          description: 'Advance toward target when > 0.50',
        },
        {
          id: 'gm-out-1',
          name: 'jump',
          mode: 'sigmoid_prob',
          unit: '',
          min: 0,
          max: 1,
          threshold: 0.6,
          description: 'Trigger jump impulse when > 0.60',
        },
        {
          id: 'gm-out-2',
          name: 'dash_evade',
          mode: 'sigmoid_prob',
          unit: '',
          min: 0,
          max: 1,
          threshold: 0.65,
          description: 'Dodge roll cooldown action',
        },
        {
          id: 'gm-out-3',
          name: 'fire_weapon',
          mode: 'sigmoid_prob',
          unit: '',
          min: 0,
          max: 1,
          threshold: 0.55,
          description: 'Primary attack trigger',
        },
      ],
      planConstraints: {
        taskKind: 'control',
        objectiveNote: '60 FPS frame-budget NPC controller (< 1.5 ms inference).',
        maxParamsBudget: 140,
        maxLatencyMs: 1.5,
      },
      layerSpecs: [
        defaultLayerSpec('input', 0, { id: 'gm-l0', name: 'State Sensors' }),
        defaultLayerSpec('hidden', 1, {
          id: 'gm-l1',
          name: 'Tactical Policy',
          notes: 'Single fast hidden layer mapping state to simultaneous actions.',
        }),
        defaultLayerSpec('output', 99, { id: 'gm-l2', name: 'Action Triggers' }),
      ],
    },
  },
  {
    id: 'house-price',
    title: 'House Price Regressor',
    badge: '5 inputs → 8 → 4 → 1 USD',
    description:
      'Continuous tabular regressor predicting property market value in real dollars.',
    domain: 'Tabular Regression',
    config: {
      name: 'HomeValuation_MLP',
      inputNodes: 5,
      hiddenLayers: [8, 4],
      outputNodes: 1,
      activation: 'gelu',
      initStrategy: 'he',
      weightScale: 1.0,
      pruneThreshold: 0.06,
      learningRate: 0.0015,
      seed: 128,
      inputSpecs: [
        {
          id: 'hp-in-0',
          name: 'living_sqft',
          kind: 'continuous',
          unit: 'sqft',
          min: 400,
          max: 5000,
          rawValue: 2150,
          description: 'Interior heated square footage',
        },
        {
          id: 'hp-in-1',
          name: 'bedrooms',
          kind: 'continuous',
          unit: 'bd',
          min: 1,
          max: 6,
          rawValue: 3,
          description: 'Total bedroom count',
        },
        {
          id: 'hp-in-2',
          name: 'school_score',
          kind: 'continuous',
          unit: '/10',
          min: 1,
          max: 10,
          rawValue: 8.2,
          description: 'District school rating 1–10',
        },
        {
          id: 'hp-in-3',
          name: 'building_age',
          kind: 'continuous',
          unit: 'yr',
          min: 0,
          max: 100,
          rawValue: 18,
          description: 'Age of structure in years',
        },
        {
          id: 'hp-in-4',
          name: 'waterfront',
          kind: 'binary',
          unit: 'bool',
          min: 0,
          max: 1,
          rawValue: 0,
          description: '1 = waterfront lot',
        },
      ],
      outputSpecs: [
        {
          id: 'hp-out-0',
          name: 'estimated_price',
          mode: 'linear_value',
          unit: '$k',
          min: 120,
          max: 1400,
          threshold: 500,
          description: 'Predicted property value in thousands USD ($k)',
        },
      ],
      planConstraints: {
        taskKind: 'regression',
        objectiveNote: 'Predict continuous property valuation ($k) with smooth GELU features.',
        maxParamsBudget: 160,
        maxLatencyMs: 2.0,
      },
      layerSpecs: [
        defaultLayerSpec('input', 0, { id: 'hp-l0', name: 'Property Attributes' }),
        defaultLayerSpec('hidden', 1, { id: 'hp-l1', name: 'Spatial Valuation Mix', norm: 'layernorm' }),
        defaultLayerSpec('hidden', 2, { id: 'hp-l2', name: 'Comp Compression' }),
        defaultLayerSpec('output', 99, {
          id: 'hp-l3',
          name: 'Valuation Output',
          activationOverride: 'sigmoid',
        }),
      ],
    },
  },
  {
    id: 'churn-single',
    title: 'Customer Churn (1-Output)',
    badge: '4 inputs → 6 → 1 prob',
    description:
      'Minimal 1-hidden-layer binary classifier outputting a single 0–100% risk score.',
    domain: 'SaaS Retention',
    config: {
      name: 'ChurnRisk_v1',
      inputNodes: 4,
      hiddenLayers: [6],
      outputNodes: 1,
      activation: 'relu',
      initStrategy: 'he',
      weightScale: 1.0,
      pruneThreshold: 0.08,
      learningRate: 0.002,
      seed: 64,
      inputSpecs: [
        {
          id: 'ch-in-0',
          name: 'active_days_30d',
          kind: 'continuous',
          unit: 'd',
          min: 0,
          max: 30,
          rawValue: 8,
          description: 'Days logged in during past month',
        },
        {
          id: 'ch-in-1',
          name: 'seat_utilization',
          kind: 'bounded01',
          unit: '',
          min: 0,
          max: 1,
          rawValue: 0.35,
          description: 'Fraction of paid seats active',
        },
        {
          id: 'ch-in-2',
          name: 'open_tickets',
          kind: 'continuous',
          unit: '#',
          min: 0,
          max: 15,
          rawValue: 4,
          description: 'Unresolved support tickets',
        },
        {
          id: 'ch-in-3',
          name: 'annual_plan',
          kind: 'binary',
          unit: 'bool',
          min: 0,
          max: 1,
          rawValue: 0,
          description: '1 = annual contract, 0 = monthly',
        },
      ],
      outputSpecs: [
        {
          id: 'ch-out-0',
          name: 'churn_30d_prob',
          mode: 'sigmoid_prob',
          unit: '',
          min: 0,
          max: 1,
          threshold: 0.5,
          description: 'Probability user cancels within 30 days',
        },
      ],
      planConstraints: {
        taskKind: 'classification',
        objectiveNote: 'Simple interpretable churn risk trigger.',
        maxParamsBudget: 80,
        maxLatencyMs: 1.2,
      },
      layerSpecs: [
        defaultLayerSpec('input', 0, { id: 'ch-l0', name: 'Usage Signals' }),
        defaultLayerSpec('hidden', 1, { id: 'ch-l1', name: 'Health Encoder' }),
        defaultLayerSpec('output', 99, { id: 'ch-l2', name: 'Churn Score' }),
      ],
    },
  },
  {
    id: 'blank-scratchpad',
    title: 'Blank Custom Scratchpad',
    badge: '2 inputs → 4 → 1 output',
    description:
      'Clean starter blueprint — define your own inputs, hidden layers, and outputs from scratch.',
    domain: 'Custom Blueprint',
    config: {
      name: 'MyCustomNet',
      inputNodes: 2,
      hiddenLayers: [4],
      outputNodes: 1,
      activation: 'gelu',
      initStrategy: 'he',
      weightScale: 1.0,
      pruneThreshold: 0.0,
      learningRate: 0.0015,
      seed: 19,
      inputSpecs: [
        {
          id: 'bl-in-0',
          name: 'input_1',
          kind: 'continuous',
          unit: '',
          min: 0,
          max: 100,
          rawValue: 65,
          description: '',
        },
        {
          id: 'bl-in-1',
          name: 'input_2',
          kind: 'continuous',
          unit: '',
          min: 0,
          max: 100,
          rawValue: 30,
          description: '',
        },
      ],
      outputSpecs: [
        {
          id: 'bl-out-0',
          name: 'prediction',
          mode: 'sigmoid_prob',
          unit: '',
          min: 0,
          max: 1,
          threshold: 0.5,
          description: '',
        },
      ],
      planConstraints: {
        taskKind: 'classification',
        objectiveNote: 'Custom neural network plan.',
        maxParamsBudget: 150,
        maxLatencyMs: 2.0,
      },
      layerSpecs: [
        defaultLayerSpec('input', 0, { id: 'bl-l0', name: 'Inputs' }),
        defaultLayerSpec('hidden', 1, { id: 'bl-l1', name: 'Hidden 1' }),
        defaultLayerSpec('output', 99, { id: 'bl-l2', name: 'Outputs' }),
      ],
    },
  },
];

// Deterministic PRNG (Mulberry32)
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    let t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function gaussianRandom(rng: () => number): number {
  let u = 0,
    v = 0;
  while (u === 0) u = rng();
  while (v === 0) v = rng();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

export function applyActivation(
  z: number,
  type: ActivationType | 'linear'
): number {
  if (type === 'linear') return z;
  switch (type) {
    case 'relu':
      return Math.max(0, z);
    case 'sigmoid':
      return 1 / (1 + Math.exp(-Math.max(-12, Math.min(12, z))));
    case 'tanh':
      return Math.tanh(z);
    case 'swish': {
      const sig = 1 / (1 + Math.exp(-Math.max(-12, Math.min(12, z))));
      return z * sig;
    }
    case 'gelu': {
      const c = Math.sqrt(2 / Math.PI) * (z + 0.044715 * z * z * z);
      return 0.5 * z * (1 + Math.tanh(c));
    }
  }
}

export function activationDerivative(
  z: number,
  type: ActivationType | 'linear'
): number {
  if (type === 'linear') return 1;
  switch (type) {
    case 'relu':
      return z > 0 ? 1 : 0.01;
    case 'sigmoid': {
      const s = applyActivation(z, 'sigmoid');
      return s * (1 - s);
    }
    case 'tanh': {
      const t = Math.tanh(z);
      return 1 - t * t;
    }
    case 'swish': {
      const s = applyActivation(z, 'sigmoid');
      return s + z * s * (1 - s);
    }
    case 'gelu': {
      const eps = 1e-3;
      return (
        (applyActivation(z + eps, 'gelu') - applyActivation(z - eps, 'gelu')) /
        (2 * eps)
      );
    }
  }
}

export function generateDefaultInputs(
  count: number,
  seed: number,
  specs?: InputNodeSpec[]
): number[] {
  if (specs && specs.length === count) {
    return specs.map((s) => normalizeInputRawValue(s));
  }
  const rng = mulberry32(seed + 991);
  return Array.from({ length: count }, (_, i) => {
    const val =
      Math.round((rng() * 1.8 - 0.5 + (i % 2 === 0 ? 0.35 : -0.15)) * 100) / 100;
    return Math.max(-1, Math.min(1, val));
  });
}

export function resolveEffectiveActivation(
  spec: LayerSpec,
  globalActivation: ActivationType,
  isOutput: boolean
): ActivationType | 'linear' {
  if (spec.activationOverride && spec.activationOverride !== 'inherit') {
    return spec.activationOverride;
  }
  if (isOutput) {
    return globalActivation === 'relu' ? 'sigmoid' : globalActivation;
  }
  return globalActivation;
}

export function formatInterpretedOutput(
  node: NeuronNode,
  outSpec: OutputNodeSpec
): string {
  if (outSpec.mode === 'softmax_class') {
    const pct = ((node.softmaxProb ?? 0) * 100).toFixed(1);
    return `${pct}%`;
  }
  if (outSpec.mode === 'sigmoid_prob') {
    const prob = 1 / (1 + Math.exp(-Math.max(-10, Math.min(10, node.preActivation))));
    return `${(prob * 100).toFixed(1)}%`;
  }
  if (outSpec.mode === 'tanh_axis') {
    const v = Math.tanh(node.preActivation);
    return v >= 0 ? `+${v.toFixed(2)}` : v.toFixed(2);
  }
  // linear_value mapped across [min..max] via sigmoid squash for bounded real range display
  const sig = 1 / (1 + Math.exp(-Math.max(-10, Math.min(10, node.preActivation))));
  const scaled = outSpec.min + sig * (outSpec.max - outSpec.min);
  const unit = outSpec.unit ? ` ${outSpec.unit}` : '';
  return `${scaled.toFixed(scaled >= 100 ? 0 : 1)}${unit}`;
}

export function buildNeuralNetwork(config: NetworkConfig): GeneratedNetwork {
  const rng = mulberry32(config.seed);
  const layerSizes = [config.inputNodes, ...config.hiddenLayers, config.outputNodes];
  const resolvedSpecs = resolveLayerSpecs(config);
  const resolvedInputSpecs = resolveInputSpecs(config);
  const resolvedOutputSpecs = resolveOutputSpecs(config);
  const inputNames = resolvedInputSpecs.map((s) => s.name);
  const outputNames = resolvedOutputSpecs.map((s) => s.name);
  const numLayers = layerSizes.length;

  const nodesByLayer: NeuronNode[][] = [];
  const edges: SynapseEdge[] = [];

  // Initialize Input Layer Nodes
  const inputLayerNodes: NeuronNode[] = [];
  for (let i = 0; i < config.inputNodes; i++) {
    const inSpec = resolvedInputSpecs[i];
    const xVal =
      config.inputVector[i] !== undefined
        ? config.inputVector[i]
        : normalizeInputRawValue(inSpec);
    const rawStr = inSpec.unit
      ? `${inSpec.rawValue}${inSpec.unit}`
      : `${inSpec.rawValue}`;
    inputLayerNodes.push({
      id: `L0-N${i}`,
      layerIndex: 0,
      neuronIndex: i,
      layerLabel: resolvedSpecs[0]?.name || 'Inputs',
      featureName: inSpec.name,
      unitLabel: rawStr,
      layerType: 'input',
      bias: 0,
      preActivation: xVal,
      activation: xVal,
      gradient: 0,
      incomingActive: 0,
      outgoingActive: 0,
      frozen: false,
    });
  }
  nodesByLayer.push(inputLayerNodes);

  // Build subsequent layers & forward propagate
  const edgesByLayer: SynapseEdge[][][] = [];

  for (let l = 1; l < numLayers; l++) {
    const fanIn = layerSizes[l - 1];
    const fanOut = layerSizes[l];
    const isOutput = l === numLayers - 1;
    const targetSpec =
      resolvedSpecs[l] ?? defaultLayerSpec(isOutput ? 'output' : 'hidden', l);
    const effAct = resolveEffectiveActivation(
      targetSpec,
      config.activation,
      isOutput
    );

    let std = Math.sqrt(2 / (fanIn + fanOut));
    if (config.initStrategy === 'he') {
      std = Math.sqrt(2 / fanIn);
    } else if (config.initStrategy === 'lecun') {
      std = Math.sqrt(1 / fanIn);
    } else if (config.initStrategy === 'sparse') {
      std = Math.sqrt(2 / fanIn) * 0.92;
    }
    std *= config.weightScale;

    const currentNodes: NeuronNode[] = [];
    const layerMatrix: SynapseEdge[][] = [];

    for (let j = 0; j < fanOut; j++) {
      const bias =
        Math.round(gaussianRandom(rng) * 0.18 * config.weightScale * 1000) / 1000;
      let z = bias;
      const rowEdges: SynapseEdge[] = [];

      for (let i = 0; i < fanIn; i++) {
        let rawW = gaussianRandom(rng) * std;
        if (config.initStrategy === 'sparse' && rng() < 0.25) {
          rawW *= 0.18;
        }
        rawW = Math.max(-2.4, Math.min(2.4, rawW));
        const pruned = Math.abs(rawW) < config.pruneThreshold;
        const effectiveW = pruned ? 0 : rawW;
        const srcAct = nodesByLayer[l - 1][i].activation;
        const signal = srcAct * effectiveW;
        z += signal;

        const edge: SynapseEdge = {
          id: `E-L${l - 1}_${i}-L${l}_${j}`,
          sourceId: `L${l - 1}-N${i}`,
          targetId: `L${l}-N${j}`,
          layerIndex: l - 1,
          fromIndex: i,
          toIndex: j,
          weight: Math.round(effectiveW * 1000) / 1000,
          rawWeight: Math.round(rawW * 1000) / 1000,
          signal: Math.round(signal * 1000) / 1000,
          gradient: 0,
          pruned,
          frozen: targetSpec.frozen,
        };
        edges.push(edge);
        rowEdges.push(edge);

        if (!pruned) {
          nodesByLayer[l - 1][i].outgoingActive += 1;
        }
      }

      layerMatrix.push(rowEdges);

      const act = applyActivation(z, effAct);
      const customHiddenNeuronLabel = !isOutput
        ? targetSpec.neuronLabels?.[j]?.trim()
        : undefined;

      currentNodes.push({
        id: `L${l}-N${j}`,
        layerIndex: l,
        neuronIndex: j,
        layerLabel: targetSpec.name || (isOutput ? 'Outputs' : `Hidden ${l}`),
        featureName: isOutput
          ? outputNames[j]
          : customHiddenNeuronLabel || undefined,
        layerType: isOutput ? 'output' : 'hidden',
        bias,
        preActivation: Math.round(z * 1000) / 1000,
        activation: Math.round(act * 1000) / 1000,
        gradient: 0,
        incomingActive: rowEdges.filter((e) => !e.pruned).length,
        outgoingActive: 0,
        frozen: targetSpec.frozen,
      });
    }

    edgesByLayer.push(layerMatrix);
    nodesByLayer.push(currentNodes);
  }

  // Compute Softmax & interpreted display strings on Output layer
  const outputLayer = nodesByLayer[numLayers - 1];
  const maxLogit = Math.max(...outputLayer.map((n) => n.preActivation));
  const exps = outputLayer.map((n) => Math.exp(n.preActivation - maxLogit));
  const sumExps = exps.reduce((a, b) => a + b, 0) || 1;
  let bestOutIdx = 0;
  outputLayer.forEach((n, idx) => {
    n.softmaxProb = exps[idx] / sumExps;
    if ((n.softmaxProb ?? 0) > (outputLayer[bestOutIdx].softmaxProb ?? 0)) {
      bestOutIdx = idx;
    }
  });
  outputLayer.forEach((n, idx) => {
    const outSpec = resolvedOutputSpecs[idx];
    n.interpretedDisplay = formatInterpretedOutput(n, outSpec);
    if (outSpec.mode === 'softmax_class') {
      n.isTopPrediction = idx === bestOutIdx && outputLayer.length > 1;
    } else if (outSpec.mode === 'sigmoid_prob') {
      const prob =
        1 / (1 + Math.exp(-Math.max(-10, Math.min(10, n.preActivation))));
      n.isTopPrediction = prob >= outSpec.threshold;
    }
  });

  // Simulated Backpropagation pass
  const outActType = resolveEffectiveActivation(
    resolvedSpecs[numLayers - 1],
    config.activation,
    true
  );
  for (let j = 0; j < outputLayer.length; j++) {
    const target = j === 0 ? 0.92 : 0.12;
    const err = outputLayer[j].activation - target;
    const deriv = activationDerivative(outputLayer[j].preActivation, outActType);
    outputLayer[j].gradient = Math.round(err * deriv * 10000) / 10000;
  }

  for (let l = numLayers - 2; l >= 0; l--) {
    const nextNodes = nodesByLayer[l + 1];
    const currNodes = nodesByLayer[l];
    const matrix = edgesByLayer[l];
    const targetSpec = resolvedSpecs[l + 1];

    for (let i = 0; i < currNodes.length; i++) {
      let gradSum = 0;
      for (let j = 0; j < nextNodes.length; j++) {
        const edge = matrix[j][i];
        const dW = nextNodes[j].gradient * currNodes[i].activation;
        edge.gradient =
          edge.pruned || targetSpec?.frozen ? 0 : Math.round(dW * 10000) / 10000;
        if (!edge.pruned) {
          gradSum += nextNodes[j].gradient * edge.weight;
        }
      }
      if (l > 0) {
        const currActType = resolveEffectiveActivation(
          resolvedSpecs[l],
          config.activation,
          false
        );
        const deriv = activationDerivative(currNodes[i].preActivation, currActType);
        currNodes[i].gradient = Math.round(gradSum * deriv * 10000) / 10000;
      } else {
        currNodes[i].gradient = Math.round(gradSum * 10000) / 10000;
      }
    }
  }

  // Summarize per layer transition
  let totalParams = 0;
  let trainableParams = 0;
  let activeParams = 0;
  let totalFlops = 0;
  let globalGradSq = 0;

  const rawSummaries: Omit<LayerSummary, 'paramSharePct'>[] = [];
  for (let l = 0; l < numLayers - 1; l++) {
    const nIn = layerSizes[l];
    const nOut = layerSizes[l + 1];
    const fromSpec = resolvedSpecs[l];
    const toSpec = resolvedSpecs[l + 1];
    const isOut = l === numLayers - 2;

    const weightsCount = nIn * nOut;
    const biasesCount = nOut;
    const normParams =
      toSpec.norm === 'layernorm' || toSpec.norm === 'batchnorm'
        ? nOut * 2
        : toSpec.norm === 'rmsnorm'
        ? nOut
        : 0;
    const params = weightsCount + biasesCount + normParams;
    const layerTrainable = toSpec.frozen ? 0 : params;

    const layerEdges = edges.filter((e) => e.layerIndex === l);
    const activeEdges = layerEdges.filter((e) => !e.pruned).length;
    const normFlops = toSpec.norm === 'none' ? 0 : nOut * 4;
    const flops = 2 * activeEdges + nOut * 3 + normFlops;

    let wSq = 0;
    let gSq = 0;
    for (const e of layerEdges) {
      wSq += e.weight * e.weight;
      gSq += e.gradient * e.gradient;
    }
    globalGradSq += gSq;

    const targetNodes = nodesByLayer[l + 1];
    const meanAct =
      targetNodes.reduce((acc, n) => acc + Math.abs(n.activation), 0) /
      Math.max(1, targetNodes.length);

    totalParams += params;
    trainableParams += layerTrainable;
    activeParams += activeEdges + biasesCount + normParams;
    totalFlops += flops;

    const effAct = resolveEffectiveActivation(toSpec, config.activation, isOut);
    const actLabelStr = effAct === 'linear' ? 'Linear' : effAct.toUpperCase();

    rawSummaries.push({
      index: l,
      name: toSpec.name || (isOut ? `Output_Proj_${l + 1}` : `Linear_Block_${l + 1}`),
      fromName: fromSpec.name,
      toName: toSpec.name,
      opType:
        isOut && toSpec.activationOverride === 'inherit'
          ? 'Linear + Readout'
          : `Linear + ${actLabelStr}`,
      activationUsed: actLabelStr,
      norm: toSpec.norm,
      dropout: toSpec.dropout,
      frozen: toSpec.frozen,
      notes: toSpec.notes,
      shapeFrom: nIn,
      shapeTo: nOut,
      tensorShape: `[B, ${nIn}] → [B, ${nOut}]`,
      params,
      trainableParams: layerTrainable,
      weightsCount,
      biasesCount,
      normParams,
      activeEdges,
      totalEdges: layerEdges.length,
      flops,
      weightL2Norm: Math.round(Math.sqrt(wSq) * 100) / 100,
      gradL2Norm: Math.round(Math.sqrt(gSq) * 1000) / 1000,
      meanActivation: Math.round(meanAct * 1000) / 1000,
    });
  }

  const layerSummaries: LayerSummary[] = rawSummaries.map((s) => ({
    ...s,
    paramSharePct: Math.round((s.params / Math.max(1, totalParams)) * 1000) / 10,
  }));

  const totalEdgesCount = edges.length;
  const prunedCount = edges.filter((e) => e.pruned).length;
  const sparsityPct =
    Math.round((prunedCount / Math.max(1, totalEdgesCount)) * 1000) / 10;
  const activeDensityPct = Math.round((100 - sparsityPct) * 10) / 10;

  const capacityFactor = Math.min(1.0, Math.log2(totalParams + 4) / 8.2);
  const activationBonus =
    config.activation === 'gelu' || config.activation === 'swish'
      ? 1.4
      : config.activation === 'relu'
      ? 0.9
      : 0.35;
  const depthBonus = config.hiddenLayers.length === 0 ? -4.2 : 0;
  const normBonus = resolvedSpecs.some((s) => s.norm !== 'none') ? 0.45 : 0;
  const prunePenalty =
    sparsityPct > 42 ? (sparsityPct - 42) * 0.16 : sparsityPct * 0.015;
  const scalePenalty = Math.abs(config.weightScale - 1.08) * 2.8;

  const valAccuracyPct = Math.min(
    99.4,
    Math.max(
      72.0,
      Math.round(
        (86.5 +
          capacityFactor * 11.2 +
          activationBonus +
          depthBonus +
          normBonus -
          prunePenalty -
          scalePenalty) *
          100
      ) / 100
    )
  );

  const estimatedLatencyMs =
    Math.round(
      (0.42 + totalFlops * 0.0048 + Math.max(0, numLayers - 2) * 0.19) * 100
    ) / 100;

  const epochMilestones = [
    { label: 'Ep 05', epoch: 5, progress: 0.15 },
    { label: 'Ep 12', epoch: 12, progress: 0.34 },
    { label: 'Ep 20', epoch: 20, progress: 0.52 },
    { label: 'Ep 30', epoch: 30, progress: 0.68 },
    { label: 'Ep 42', epoch: 42, progress: 0.81 },
    { label: 'Ep 52', epoch: 52, progress: 0.92 },
    { label: 'Ep 60', epoch: 60, progress: 1.0 },
  ];

  const lrSpeed = Math.min(1.35, Math.max(0.65, config.learningRate / 0.0015));
  const basePeak =
    3850 +
    Math.round(capacityFactor * 820 + activationBonus * 140 - prunePenalty * 35);

  const epochSeries: EpochPoint[] = epochMilestones.map((m, idx) => {
    const wave = Math.sin(idx * 1.4 + config.seed * 0.1) * 145;
    const baseWave = Math.cos(idx * 1.2 + 0.8) * 120;
    const curve = 1 - Math.exp(-3.1 * m.progress * lrSpeed);
    const baseCurve = 1 - Math.exp(-2.2 * m.progress);

    const currentScore = Math.round(1450 + curve * (basePeak - 1450) + wave);
    const baselineScore = Math.round(1280 + baseCurve * (3120 - 1280) + baseWave);

    const trainLoss = Math.max(
      0.032,
      Math.round(
        (1.42 * Math.exp(-2.85 * m.progress * lrSpeed) +
          0.055 +
          scalePenalty * 0.01) *
          1000
      ) / 1000
    );
    const baselineLoss = Math.max(
      0.085,
      Math.round((1.55 * Math.exp(-1.95 * m.progress) + 0.14) * 1000) / 1000
    );

    const valAcc = Math.min(
      valAccuracyPct,
      Math.round((58.0 + curve * (valAccuracyPct - 58.0)) * 10) / 10
    );

    return {
      label: m.label,
      epoch: m.epoch,
      currentScore,
      baselineScore,
      trainLoss,
      baselineLoss,
      valAccuracy: valAcc,
    };
  });

  return {
    config,
    resolvedSpecs,
    resolvedInputSpecs,
    resolvedOutputSpecs,
    inputNames,
    outputNames,
    layerSizes,
    nodes: nodesByLayer.flat(),
    edges,
    layerSummaries,
    epochSeries,
    metrics: {
      totalParams,
      trainableParams,
      frozenParams: totalParams - trainableParams,
      activeParams,
      sparsityPct,
      activeDensityPct,
      totalFlops,
      estimatedLatencyMs,
      valAccuracyPct,
      finalLoss: epochSeries[epochSeries.length - 1].trainLoss,
      globalGradNorm: Math.round(Math.sqrt(globalGradSq) * 1000) / 1000,
      memoryKB: Math.round(((totalParams * 4) / 1024) * 100) / 100,
    },
  };
}

/* ---------------------------------------------------------------------------
 * Learning, diagnostics & planning helpers
 * ------------------------------------------------------------------------- */

export type LayerKind = 'input' | 'expand' | 'compress' | 'bottleneck' | 'output';

export interface LayerInsight {
  kind: LayerKind;
  name: string;
  headline: string;
  detail: string;
  delta: number;
}

export interface TrainingPhase {
  name: string;
  epochs: number;
  lr: number;
  focus: string;
  note: string;
}

export interface TrainingPlan {
  totalEpochs: number;
  batchSize: number;
  phases: TrainingPhase[];
  milestones: { epoch: number; label: string }[];
  estTrainMinutes: number;
  recommendedBatch: number;
  dropout: number;
  weightDecay: number;
  warmupEpochs: number;
}

export interface PlanDiagnostic {
  level: 'good' | 'warn' | 'info';
  title: string;
  body: string;
}

export function activationLabel(type: ActivationType | 'linear'): string {
  switch (type) {
    case 'relu':
      return 'ReLU';
    case 'gelu':
      return 'GELU';
    case 'sigmoid':
      return 'Sigmoid';
    case 'tanh':
      return 'Tanh';
    case 'swish':
      return 'Swish / SiLU';
    case 'linear':
      return 'Linear (Identity)';
  }
}

export function describeLayers(net: GeneratedNetwork): LayerInsight[] {
  const sizes = net.layerSizes;
  const specs = net.resolvedSpecs;
  const last = sizes.length - 1;
  const smallest = Math.min(...sizes);

  return sizes.map((size, idx) => {
    const spec = specs[idx];
    const prevSize = idx > 0 ? sizes[idx - 1] : size;
    const delta = idx > 0 ? size - prevSize : 0;

    if (idx === 0) {
      return {
        kind: 'input' as LayerKind,
        name: spec.name,
        headline: `${spec.name} · ${size} ${size === 1 ? 'input' : 'inputs'}`,
        detail:
          spec.notes ||
          `Signals (${net.inputNames.join(', ')}) are normalized and fed into the first matrix.`,
        delta: 0,
      };
    }

    if (idx === last) {
      return {
        kind: 'output' as LayerKind,
        name: spec.name,
        headline: `${spec.name} · ${size} ${size === 1 ? 'output' : 'outputs'}`,
        detail:
          spec.notes ||
          `Produces predictions for (${net.outputNames.join(', ')}).`,
        delta: 0,
      };
    }

    const isBottleneck = delta < 0 && size <= smallest * 0.6;
    const kind: LayerKind = isBottleneck
      ? 'bottleneck'
      : delta > 0
      ? 'expand'
      : 'compress';

    const autoDetail =
      kind === 'expand'
        ? `Widens ${prevSize} → ${size} neurons (+${delta}). Extra width lets the layer combine multiple inputs into richer features.`
        : kind === 'compress'
        ? `Narrows ${prevSize} → ${size} neurons (${delta}). Distills features toward the final decision.`
        : `Strong compression ${prevSize} → ${size}. Forces the network through a compact latent representation.`;

    return {
      kind,
      name: spec.name,
      headline: `${spec.name} · ${size} neurons`,
      detail: spec.notes ? `${spec.notes} (${prevSize} → ${size})` : autoDetail,
      delta,
    };
  });
}

export function evaluatePlanDiagnostics(net: GeneratedNetwork): PlanDiagnostic[] {
  const out: PlanDiagnostic[] = [];
  const { config, metrics, resolvedOutputSpecs } = net;
  const constraints = config.planConstraints;

  // Check output head mode consistency
  const modes = new Set(resolvedOutputSpecs.map((o) => o.mode));
  if (resolvedOutputSpecs.length === 1 && resolvedOutputSpecs[0].mode === 'softmax_class') {
    out.push({
      level: 'warn',
      title: 'Softmax on a single output always equals 100%',
      body: `With only 1 output ("${resolvedOutputSpecs[0].name}"), switch its mode to "Probability (0–1 Sigmoid)" or "Continuous Value" instead of Softmax.`,
    });
  } else if (modes.size > 1 && modes.has('softmax_class')) {
    out.push({
      level: 'info',
      title: 'Mixed output head types detected',
      body: 'Combining Softmax classes with independent Sigmoid/Linear heads usually requires split loss functions (CrossEntropy + BCE/MSE).',
    });
  }

  if (constraints) {
    if (metrics.totalParams <= constraints.maxParamsBudget) {
      out.push({
        level: 'good',
        title: 'Within parameter budget',
        body: `${metrics.totalParams.toLocaleString()} / ${constraints.maxParamsBudget.toLocaleString()} params used (${Math.round(
          (metrics.totalParams / Math.max(1, constraints.maxParamsBudget)) * 100
        )}%).`,
      });
    } else {
      out.push({
        level: 'warn',
        title: 'Exceeds parameter budget',
        body: `Planned network uses ${metrics.totalParams.toLocaleString()} params vs ${constraints.maxParamsBudget.toLocaleString()} target.`,
      });
    }

    if (metrics.estimatedLatencyMs <= constraints.maxLatencyMs) {
      out.push({
        level: 'good',
        title: 'Meets latency target',
        body: `Estimated p95 ${metrics.estimatedLatencyMs.toFixed(2)} ms fits inside ${constraints.maxLatencyMs.toFixed(2)} ms ceiling.`,
      });
    } else {
      out.push({
        level: 'warn',
        title: 'Above latency ceiling',
        body: `Estimated ${metrics.estimatedLatencyMs.toFixed(2)} ms exceeds ${constraints.maxLatencyMs.toFixed(2)} ms target.`,
      });
    }
  }

  if (config.hiddenLayers.length === 0) {
    out.push({
      level: 'info',
      title: 'Direct linear model (0 hidden layers)',
      body: 'Inputs connect straight to outputs — cannot learn XOR/interaction terms without at least 1 hidden layer.',
    });
  }

  return out;
}

export function buildTrainingPlan(net: GeneratedNetwork): TrainingPlan {
  const { config, metrics } = net;
  const totalEpochs = 60;
  const depth = net.layerSizes.length - 1;

  const phases: TrainingPhase[] = [
    {
      name: 'Warmup',
      epochs: Math.round(totalEpochs * 0.12),
      lr: config.learningRate * 0.25,
      focus: 'stabilise',
      note: 'Low learning rate lets normalization statistics settle before the model commits to a basin.',
    },
    {
      name: 'Plateau',
      epochs: Math.round(totalEpochs * 0.38),
      lr: config.learningRate,
      focus: 'fit',
      note: 'Main fitting phase at the base learning rate — where the loss curve bends hardest.',
    },
    {
      name: 'Anneal',
      epochs: Math.round(totalEpochs * 0.33),
      lr: config.learningRate * 0.35,
      focus: 'refine',
      note: 'Stepping down learning rate stabilises the valley floor and reduces gradient noise.',
    },
    {
      name: 'Finetune',
      epochs: totalEpochs - Math.round(totalEpochs * 0.83),
      lr: config.learningRate * 0.1,
      focus: 'polish',
      note: 'Small final updates to lock in validation generalisation.',
    },
  ];

  phases[0].epochs =
    totalEpochs - (phases[1].epochs + phases[2].epochs + phases[3].epochs);

  const recommendedBatch =
    metrics.totalParams > 4000 ? 64 : metrics.totalParams > 1500 ? 128 : 256;

  const datasetSize = 200_000;
  const stepsPerEpoch = Math.ceil(datasetSize / recommendedBatch);
  const msPerStep = 1.4;
  const estTrainMinutes =
    Math.round(((stepsPerEpoch * totalEpochs * msPerStep) / 60_000) * 10) / 10;

  return {
    totalEpochs,
    batchSize: recommendedBatch,
    phases,
    milestones: [
      { epoch: 5, label: 'Warmup complete — full LR active' },
      { epoch: 18, label: 'LR decay ×0.35 scheduled' },
      { epoch: 34, label: 'Validation plateau checkpoint' },
      { epoch: 52, label: 'Converged — early-stop window' },
    ],
    estTrainMinutes,
    recommendedBatch,
    dropout: depth >= 4 ? 0.25 : depth >= 3 ? 0.15 : 0.05,
    weightDecay: config.activation === 'relu' ? 0.0001 : 0.01,
    warmupEpochs: phases[0].epochs,
  };
}

export interface ScenarioRow {
  id: string;
  label: string;
  topology: string;
  params: number;
  flops: number;
  latencyMs: number;
  accuracy: number;
  dParams: number;
  dAccuracy: number;
  dLatency: number;
  isCurrent: boolean;
  config: NetworkConfig;
}

export function buildScenarios(
  current: GeneratedNetwork,
  build: (cfg: NetworkConfig) => GeneratedNetwork
): ScenarioRow[] {
  const cfg = current.config;
  const hasHidden = cfg.hiddenLayers.length > 0;

  const candidates: { id: string; label: string; cfg: NetworkConfig }[] = [
    {
      id: 'current',
      label: 'Current architecture',
      cfg: { ...cfg, hiddenLayers: [...cfg.hiddenLayers] },
    },
    {
      id: 'wider',
      label: hasHidden
        ? 'Widen first hidden layer (+2)'
        : 'Add a wide hidden layer (6)',
      cfg: hasHidden
        ? {
            ...cfg,
            layerSpecs: undefined,
            hiddenLayers: [cfg.hiddenLayers[0] + 2, ...cfg.hiddenLayers.slice(1)],
          }
        : addHiddenLayerToConfig(cfg, 6),
    },
    {
      id: 'deeper',
      label: 'Add a hidden layer (+1)',
      cfg: addHiddenLayerToConfig(
        cfg,
        hasHidden
          ? Math.max(3, cfg.hiddenLayers[cfg.hiddenLayers.length - 1])
          : Math.max(4, cfg.inputNodes)
      ),
    },
    ...(hasHidden
      ? [
          {
            id: 'shallower',
            label:
              cfg.hiddenLayers.length === 1
                ? 'Remove hidden layer (linear 0-hidden)'
                : 'Remove last hidden layer (−1)',
            cfg: removeHiddenLayerFromConfig(cfg, cfg.hiddenLayers.length - 1),
          },
        ]
      : []),
    {
      id: 'pruned',
      label: 'Prune harder (τ × 1.6)',
      cfg: {
        ...cfg,
        pruneThreshold: Math.min(0.44, cfg.pruneThreshold * 1.6 + 0.02),
      },
    },
    ...(hasHidden
      ? [
          {
            id: 'narrow',
            label: 'Narrow all hidden layers (−1)',
            cfg: {
              ...cfg,
              hiddenLayers: cfg.hiddenLayers.map((h) => Math.max(1, h - 1)),
            },
          },
        ]
      : []),
  ];

  const base = current.metrics;

  return candidates.map((c) => {
    const net = build(c.cfg);
    const m = net.metrics;
    return {
      id: c.id,
      label: c.label,
      topology: net.layerSizes.join(' → '),
      params: m.activeParams,
      flops: m.totalFlops,
      latencyMs: m.estimatedLatencyMs,
      accuracy: m.valAccuracyPct,
      dParams: c.id === 'current' ? 0 : m.activeParams - base.activeParams,
      dAccuracy:
        c.id === 'current'
          ? 0
          : Math.round((m.valAccuracyPct - base.valAccuracyPct) * 100) / 100,
      dLatency:
        c.id === 'current'
          ? 0
          : Math.round((m.estimatedLatencyMs - base.estimatedLatencyMs) * 100) /
            100,
      isCurrent: c.id === 'current',
      config: c.cfg,
    };
  });
}

function toSafeIdentifier(raw: string, fallback: string): string {
  const cleaned = raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_]+/g, '_')
    .replace(/^_+|_+$/g, '');
  if (!cleaned) return fallback;
  return /^[0-9]/.test(cleaned) ? `_${cleaned}` : cleaned;
}

export function generatePyTorchCode(net: GeneratedNetwork): string {
  const { config, layerSizes, resolvedSpecs, resolvedInputSpecs, resolvedOutputSpecs } = net;
  const actMap: Record<ActivationType, string> = {
    relu: 'nn.ReLU()',
    gelu: 'nn.GELU()',
    sigmoid: 'nn.Sigmoid()',
    tanh: 'nn.Tanh()',
    swish: 'nn.SiLU()',
  };

  const normMap: Record<Exclude<LayerNormType, 'none'>, (dim: number) => string> = {
    layernorm: (d) => `nn.LayerNorm(${d})`,
    batchnorm: (d) => `nn.BatchNorm1d(${d})`,
    rmsnorm: (d) => `nn.RMSNorm(${d})`,
  };

  const usedKeys = new Set<string>();
  const stageEntries: string[] = [];
  const frozenKeys: string[] = [];

  for (let i = 0; i < layerSizes.length - 1; i++) {
    const isLast = i === layerSizes.length - 2;
    const targetSpec = resolvedSpecs[i + 1];
    let key = toSafeIdentifier(targetSpec.name, `stage_${i + 1}`);
    if (usedKeys.has(key)) key = `${key}_${i + 1}`;
    usedKeys.add(key);

    if (targetSpec.frozen) frozenKeys.push(key);

    const subOps: string[] = [`nn.Linear(${layerSizes[i]}, ${layerSizes[i + 1]})`];
    if (targetSpec.norm !== 'none') {
      subOps.push(normMap[targetSpec.norm](layerSizes[i + 1]));
    }
    const effAct = resolveEffectiveActivation(targetSpec, config.activation, isLast);
    if (!isLast && effAct !== 'linear') {
      subOps.push(actMap[effAct]);
    } else if (
      isLast &&
      targetSpec.activationOverride !== 'inherit' &&
      effAct !== 'linear'
    ) {
      subOps.push(actMap[effAct]);
    }
    if (!isLast && targetSpec.dropout > 0) {
      subOps.push(`nn.Dropout(p=${targetSpec.dropout.toFixed(2)})`);
    }

    const comment = targetSpec.notes ? `  # ${targetSpec.notes}` : '';
    if (subOps.length === 1) {
      stageEntries.push(`            ("${key}", ${subOps[0]}),${comment}`);
    } else {
      stageEntries.push(
        `            ("${key}", nn.Sequential(\n                ${subOps.join(',\n                ')}\n            )),${comment}`
      );
    }
  }

  const className =
    config.name.replace(/[^a-zA-Z0-9_]/g, '_') || 'PlannedNetwork';

  const inputSchemaLines = resolvedInputSpecs
    .map(
      (s, idx) =>
        `    # [${idx}] ${s.name} (${s.kind}${s.unit ? `, ${s.unit}` : ''}, range=[${s.min}, ${s.max}])${
          s.description ? ` — ${s.description}` : ''
        }`
    )
    .join('\n');

  const outputSchemaLines = resolvedOutputSpecs
    .map(
      (s, idx) =>
        `    # [${idx}] ${s.name} (${s.mode}${s.unit ? `, ${s.unit}` : ''})${
          s.description ? ` — ${s.description}` : ''
        }`
    )
    .join('\n');

  const mins = resolvedInputSpecs.map((s) => s.min).join(', ');
  const maxs = resolvedInputSpecs.map((s) => s.max).join(', ');
  const sampleRawDict = resolvedInputSpecs
    .map((s) => `"${s.name}": ${s.rawValue}`)
    .join(', ');

  return `from collections import OrderedDict
import torch
import torch.nn as nn

INPUT_NAMES = ${JSON.stringify(resolvedInputSpecs.map((s) => s.name))}
OUTPUT_NAMES = ${JSON.stringify(resolvedOutputSpecs.map((s) => s.name))}

class ${className}(nn.Module):
    """
    Planned with SynapseLab Workbench
    Topology: [${layerSizes.join(' -> ')}] (${resolvedSpecs.map((s) => s.name).join(' -> ')})
    Total Params: ${net.metrics.totalParams.toLocaleString()} | Trainable: ${net.metrics.trainableParams.toLocaleString()}

    Planned Inputs:
${inputSchemaLines}

    Planned Outputs:
${outputSchemaLines}
    """
    def __init__(self):
        super().__init__()
        self.register_buffer("in_min", torch.tensor([${mins}], dtype=torch.float32))
        self.register_buffer("in_max", torch.tensor([${maxs}], dtype=torch.float32))
        self.stages = nn.Sequential(OrderedDict([
${stageEntries.join('\n')}
        ]))${
          frozenKeys.length > 0
            ? `\n        for name in [${frozenKeys
                .map((k) => `"${k}"`)
                .join(', ')}]:\n            for p in self.stages[name].parameters():\n                p.requires_grad = False`
            : ''
        }

    def encode_inputs(self, raw_x: torch.Tensor) -> torch.Tensor:
        span = (self.in_max - self.in_min).clamp(min=1e-6)
        return ((raw_x - self.in_min) / span) * 2.0 - 1.0

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.stages(x)

if __name__ == "__main__":
    model = ${className}()
    sample_raw = {${sampleRawDict}}
    raw_tensor = torch.tensor([[sample_raw[k] for k in INPUT_NAMES]], dtype=torch.float32)
    logits = model(model.encode_inputs(raw_tensor))
    mapped = dict(zip(OUTPUT_NAMES, logits[0].tolist()))
    print("Predictions:", mapped)`;
}

export function generateTypeScriptCode(net: GeneratedNetwork): string {
  const { config, layerSizes, resolvedSpecs, resolvedInputSpecs, resolvedOutputSpecs } = net;
  const inputInterfaceFields = resolvedInputSpecs
    .map(
      (s, i) =>
        `  /** [${i}] range [${s.min}..${s.max}]${s.unit ? ` ${s.unit}` : ''}${
          s.description ? ` — ${s.description}` : ''
        } */\n  ${toSafeIdentifier(s.name, `input_${i}`) }: number;`
    )
    .join('\n');

  const outputNamesUnion = resolvedOutputSpecs
    .map((s, i) => `'${toSafeIdentifier(s.name, `output_${i}`)}'`)
    .join(' | ');

  return `// Typed Inference Blueprint — ${config.name}
// Stages: ${resolvedSpecs.map((s, i) => `${s.name}(${layerSizes[i]})`).join(' -> ')}

export interface PlannedInputs {
${inputInterfaceFields}
}

export type PlannedOutputKey = ${outputNamesUnion};

export const INPUT_ORDER = ${JSON.stringify(
    resolvedInputSpecs.map((s, i) => ({
      key: toSafeIdentifier(s.name, `input_${i}`),
      min: s.min,
      max: s.max,
    }))
  )} as const;

export const OUTPUT_ORDER: PlannedOutputKey[] = [${resolvedOutputSpecs
    .map((s, i) => `'${toSafeIdentifier(s.name, `output_${i}`)}'`)
    .join(', ')}];
`;
}

export function generateMarkdownSpec(
  net: GeneratedNetwork,
  plan: TrainingPlan
): string {
  const {
    config,
    resolvedInputSpecs,
    resolvedOutputSpecs,
    layerSizes,
    layerSummaries,
    metrics,
  } = net;
  const objective =
    config.planConstraints?.objectiveNote ||
    'Feed-forward neural network planned in SynapseLab.';

  const inRows = resolvedInputSpecs
    .map(
      (s, i) =>
        `| \`in[${i}]\` | **${s.name}** | ${s.kind} | \`[${s.min} .. ${s.max}]${
          s.unit ? ` ${s.unit}` : ''
        }\` | \`${s.rawValue}\` → \`${normalizeInputRawValue(s).toFixed(2)}\` | ${
          s.description || '—'
        } |`
    )
    .join('\n');

  const outRows = resolvedOutputSpecs
    .map(
      (s, i) =>
        `| \`out[${i}]\` | **${s.name}** | ${s.mode} | ${
          s.mode === 'linear_value'
            ? `\`[${s.min}..${s.max}] ${s.unit}\``
            : s.mode === 'sigmoid_prob'
            ? `threshold \`${s.threshold}\``
            : 'argmax / softmax'
        } | ${s.description || '—'} |`
    )
    .join('\n');

  const stageRows = layerSummaries
    .map(
      (s, idx) =>
        `| ${idx + 1} | **${s.fromName}** → **${s.toName}** | \`${s.tensorShape}\` | ${
          s.activationUsed
        } | ${s.norm === 'none' ? '—' : s.norm} | ${
          s.params.toLocaleString()
        }${s.frozen ? ' *(frozen)*' : ''} | ${s.notes || '—'} |`
    )
    .join('\n');

  return `# Neural Network Specification: ${config.name}

> ${objective}

## 1. Planned Inputs (${resolvedInputSpecs.length})
| Index | Signal Name | Kind | Domain Range | Sample → Normalized | Description |
|---|---|---|---|---|---|
${inRows}

## 2. Planned Outputs (${resolvedOutputSpecs.length})
| Index | Target Name | Readout Mode | Decision Rule / Range | Description |
|---|---|---|---|---|
${outRows}

## 3. Layer Stack (${layerSizes.join(' → ')})
- **Parameters:** ${metrics.totalParams.toLocaleString()} (${metrics.trainableParams.toLocaleString()} trainable) · **FLOPs:** ${metrics.totalFlops.toLocaleString()} · **Latency (p95):** ~${metrics.estimatedLatencyMs.toFixed(
    2
  )} ms · **Batch Size:** ${plan.recommendedBatch}

| # | Stage Transition | Shape | Activation | Norm | Params | Notes |
|---|---|---|---|---|---:|---|
${stageRows}
`;
}
